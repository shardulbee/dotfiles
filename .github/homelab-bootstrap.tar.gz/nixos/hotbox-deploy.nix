{ lib, pkgs, ... }:

let
  hostScript = pkgs.replaceVars ../dotfiles/scripts/deploy-nixos-host.py {
    host = "hotbox";
    nix = "${pkgs.nix}/bin/nix";
    nixEnv = "${pkgs.nix}/bin/nix-env";
    path = lib.makeBinPath [
      pkgs.bash
      pkgs.coreutils
      pkgs.git
      pkgs.nix
      pkgs.systemd
    ];
  };
  host = pkgs.writeShellScriptBin "deploy-hotbox-host" ''
    exec ${pkgs.python3}/bin/python3 -I ${hostScript} "$@"
  '';
  dispatch = pkgs.writeShellScript "hotbox-deploy-ssh" ''
    set -euo pipefail
    if [[ ! "''${SSH_ORIGINAL_COMMAND:-}" =~ ^deploy\ ([0-9a-f]{40})$ ]]; then
      echo 'Only: deploy <40-character commit ID>' >&2
      exit 1
    fi
    exec /run/wrappers/bin/sudo -n ${host}/bin/deploy-hotbox-host "''${BASH_REMATCH[1]}"
  '';
in
{
  users.groups.dotfiles-deploy = { };
  users.users.dotfiles-deploy = {
    isSystemUser = true;
    group = "dotfiles-deploy";
    home = "/var/empty";
    createHome = false;
    shell = pkgs.bash;
    openssh.authorizedKeys.keys = [
      ''restrict,command="${dispatch}" ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIND86kvCEtDqTqmFzn3RpwZIhRhKaz7/VEYd/VCzEMJL homelab-deploy''
    ];
  };
  security.sudo.extraRules = [
    {
      users = [ "dotfiles-deploy" ];
      runAs = "root";
      commands = [
        {
          command = "${host}/bin/deploy-hotbox-host";
          options = [ "NOPASSWD" ];
        }
      ];
    }
  ];
  services.openssh.extraConfig = ''
    Match User dotfiles-deploy
      ForceCommand ${dispatch}
      DisableForwarding yes
      PermitTTY no
      PermitUserRC no
    Match all
  '';
}
