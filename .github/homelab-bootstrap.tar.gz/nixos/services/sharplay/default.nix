{
  config,
  lib,
  pkgs,
  ...
}:

let
  cfg = config.services.sharplay;

  pywebostv = pkgs.python312Packages.buildPythonPackage rec {
    pname = "pywebostv";
    version = "0.8.9";
    format = "setuptools";
    src = pkgs.fetchPypi {
      inherit pname version;
      hash = "sha256-bkTJxlXG1uBpFipEepkhrJwMSUhdZ2V0E2V38Pw2mHg=";
    };
    propagatedBuildInputs = with pkgs.python312Packages; [
      future
      requests
      ws4py
    ];
    doCheck = false;
    pythonImportsCheck = [ "pywebostv" ];
  };

  python = pkgs.python312.withPackages (packages: [
    packages.pyscard
    pywebostv
  ]);

  package = pkgs.stdenvNoCC.mkDerivation {
    pname = "sharplay";
    version = "0.1.0-9c9441c";
    src = ./source;
    nativeBuildInputs = [ pkgs.makeWrapper ];
    installPhase = ''
      runHook preInstall
      mkdir -p "$out/bin" "$out/share/sharplay"
      cp -R . "$out/share/sharplay"
      makeWrapper ${python}/bin/python "$out/bin/sharplay" \
        --add-flags "$out/share/sharplay/nfc_tv_daemon.py" \
        --prefix PATH : ${
          lib.makeBinPath [
            pkgs.ffmpeg
            pkgs.mpv
          ]
        }
      runHook postInstall
    '';
  };

  preflight = pkgs.writeShellScript "sharplay-preflight" ''
    set -eu

    test -d /srv/sharplay/media/Movies
    test -d /srv/sharplay/media/Shows
    test -c ${lib.escapeShellArg cfg.drmDevice}

    card="$(${pkgs.coreutils}/bin/basename "$(${pkgs.coreutils}/bin/readlink -f ${lib.escapeShellArg cfg.drmDevice})")"
    connected=0
    for status in /sys/class/drm/"$card"-HDMI-*/status; do
      [ -e "$status" ] || continue
      [ "$(cat "$status")" != connected ] || connected=$((connected + 1))
    done
    [ "$connected" -eq 1 ]

    reader=false
    for device in /sys/bus/usb/devices/*; do
      [ -r "$device/idVendor" ] && [ -r "$device/idProduct" ] || continue
      if [ "$(cat "$device/idVendor")" = 072f ] && [ "$(cat "$device/idProduct")" = 2200 ]; then
        reader=true
        break
      fi
    done
    "$reader"

    ${python}/bin/python -c 'from smartcard.System import readers; assert readers()'
    ${pkgs.mpv}/bin/mpv --no-config --audio-device=help 2>&1 \
      | ${pkgs.gnugrep}/bin/grep -F -- ${lib.escapeShellArg cfg.audioDevice} >/dev/null
  '';
in
{
  options.services.sharplay = {
    enable = lib.mkEnableOption "the native Sharplay appliance service";
    publish = lib.mkEnableOption "Sharplay in the existing Sharbox Cloudflare tunnel";
    drmDevice = lib.mkOption {
      type = lib.types.str;
      default = "";
      example = "/dev/dri/by-path/pci-0000:00:02.0-card";
      description = "Verified stable DRM card path; required at cutover.";
    };
    audioDevice = lib.mkOption {
      type = lib.types.str;
      default = "";
      example = "alsa/hdmi:CARD=PCH,DEV=0";
      description = "Verified stable mpv ALSA device; required at cutover.";
    };
  };

  config = lib.mkIf cfg.enable {
    assertions = [
      {
        assertion = cfg.drmDevice != "";
        message = "services.sharplay.drmDevice must be set to an inspected stable path";
      }
      {
        assertion = cfg.audioDevice != "";
        message = "services.sharplay.audioDevice must be set to an inspected stable ALSA name";
      }
    ];

    boot = {
      blacklistedKernelModules = [
        "pn533"
        "pn533_usb"
      ];
      consoleLogLevel = 3;
      kernelParams = [
        "quiet"
        "vt.global_cursor_default=0"
      ];
    };

    hardware.graphics = {
      enable = true;
      extraPackages = [ pkgs.intel-media-driver ];
    };

    services.pcscd = {
      enable = true;
      plugins = [ pkgs.ccid ];
    };

    security.polkit = {
      enable = true;
      extraConfig = ''
        polkit.addRule(function(action, subject) {
          if ((action.id == "org.debian.pcsc-lite.access_pcsc" ||
               action.id == "org.debian.pcsc-lite.access_card") &&
              subject.user == "sharplay") {
            return polkit.Result.YES;
          }
        });
      '';
    };

    users = {
      groups.sharplay = { };
      users.sharplay = {
        isSystemUser = true;
        group = "sharplay";
        home = "/var/lib/nfc-tv";
        extraGroups = [
          "audio"
          "render"
          "video"
        ];
      };
    };

    systemd = {
      tmpfiles.rules = [
        "d /var/lib/nfc-tv 0770 sharplay sharplay -"
        "d /var/lib/sharplay 0750 root root -"
        "d /var/lib/sharplay/secrets 0700 root root -"
        "d /srv/sharplay 0755 root root -"
        "d /srv/sharplay/media 0750 root sharplay -"
      ];

      services = {
        "autovt@tty1".enable = false;
        "getty@tty1".enable = false;

        sharplay = {
          description = "Sharplay NFC media appliance";
          wantedBy = [ "multi-user.target" ];
          after = [
            "network-online.target"
            "pcscd.socket"
          ];
          wants = [
            "network-online.target"
            "pcscd.socket"
          ];
          unitConfig.ConditionPathExists = [
            "/srv/sharplay/media/.migration-complete"
            "/var/lib/sharplay/secrets/webos.json"
          ];
          environment = {
            HOME = "/var/lib/nfc-tv";
            SHARPLAY_APP_DIR = "${package}/share/sharplay/app";
            SHARPLAY_BLOCKED_IMAGE = "${package}/share/sharplay/feedback/access-blocked.jpg";
            SHARPLAY_DRM_DEVICE = cfg.drmDevice;
            SHARPLAY_FFMPEG = "${pkgs.ffmpeg}/bin/ffmpeg";
            SHARPLAY_FFPROBE = "${pkgs.ffmpeg}/bin/ffprobe";
            SHARPLAY_HOST = "127.0.0.1";
            SHARPLAY_LIMIT_IMAGE = "${package}/share/sharplay/feedback/limit-reached.jpg";
            SHARPLAY_MEDIA_ROOT = "/srv/sharplay/media";
            SHARPLAY_MPV_AUDIO_DEVICE = cfg.audioDevice;
            SHARPLAY_MPV_HWDEC = "vaapi";
            SHARPLAY_MPV_VIDEO_OUTPUT = "gpu-next";
            SHARPLAY_SESSION_IMAGE = "${package}/share/sharplay/feedback/session-break.jpg";
            SHARPLAY_STATE_DIR = "/var/lib/nfc-tv";
          };
          path = [
            pkgs.ffmpeg
            pkgs.mpv
          ];
          serviceConfig = {
            Type = "simple";
            User = "sharplay";
            Group = "sharplay";
            SupplementaryGroups = [
              "audio"
              "render"
              "video"
            ];
            BindReadOnlyPaths = [ "/srv/sharplay/media" ];
            LoadCredential = "webos.json:/var/lib/sharplay/secrets/webos.json";
            ExecStartPre = preflight;
            ExecStart = "${package}/bin/sharplay";
            Restart = "on-failure";
            RestartSec = "3s";
            RuntimeDirectory = "nfc-tv";
            RuntimeDirectoryMode = "0770";
            UMask = "0007";
            CapabilityBoundingSet = "";
            LockPersonality = true;
            NoNewPrivileges = true;
            PrivateTmp = true;
            ProtectClock = true;
            ProtectControlGroups = true;
            ProtectHome = true;
            ProtectHostname = true;
            ProtectKernelLogs = true;
            ProtectKernelModules = true;
            ProtectKernelTunables = true;
            ProtectProc = "invisible";
            ProtectSystem = "strict";
            ReadWritePaths = [ "/var/lib/nfc-tv" ];
            RestrictAddressFamilies = [
              "AF_INET"
              "AF_INET6"
              "AF_UNIX"
            ];
            RestrictNamespaces = true;
            RestrictRealtime = true;
            RestrictSUIDSGID = true;
            SystemCallArchitectures = "native";
          };
        };
      };
    };
  };
}
