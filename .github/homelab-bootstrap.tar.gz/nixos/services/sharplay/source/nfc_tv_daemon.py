#!/usr/bin/env python3
import json
import math
import os
import shlex
import signal
import socket
import subprocess
import time
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from web_backend import notify_refresh, safe_media_path, start_backend

CONFIG = Path(os.environ.get("CREDENTIALS_DIRECTORY", "/etc/nfc-tv"))
STATE = Path("/var/lib/nfc-tv")
CARDS = STATE / "cards.json"
MODE = STATE / "mode.json"
SCAN = STATE / "last-scan.json"
STATUS = STATE / "status.json"
SETTINGS = STATE / "settings.json"
ACCESS = STATE / "access.json"
USAGE = STATE / "usage.json"
RESUME = STATE / "resume.json"
SESSION = STATE / "session.json"
COMMAND = STATE / "command.json"
COMMAND_IN_PROGRESS = STATE / "command.processing.json"
MPV_SOCKET = Path("/run/nfc-tv/mpv.sock")
DRM_DEVICE = Path(os.environ.get("SHARPLAY_DRM_DEVICE", "/dev/dri/card1"))
DRM_SYSFS = Path(os.environ.get("SHARPLAY_DRM_SYSFS", "/sys/class/drm"))
MPV_VIDEO_OUTPUT = os.environ.get("SHARPLAY_MPV_VIDEO_OUTPUT", "gpu-next")
MPV_HWDEC = os.environ.get("SHARPLAY_MPV_HWDEC", "vaapi")
MPV_AUDIO_DEVICE = os.environ.get("SHARPLAY_MPV_AUDIO_DEVICE", "alsa/hw:0,3")
MPV_DRM_MODE = os.environ.get("SHARPLAY_MPV_DRM_MODE", "")
MPV_DIRECT_VIDEO = os.environ.get("SHARPLAY_MPV_DIRECT_VIDEO", "") == "1"
MPV_EXTRA_ARGS = shlex.split(os.environ.get("SHARPLAY_MPV_EXTRA_ARGS", ""))
LIMIT_IMAGE = Path(os.environ.get("SHARPLAY_LIMIT_IMAGE", "/opt/nfc-tv/limit-reached.jpg"))
SESSION_IMAGE = Path(os.environ.get("SHARPLAY_SESSION_IMAGE", "/opt/nfc-tv/session-break.jpg"))
BLOCKED_IMAGE = Path(os.environ.get("SHARPLAY_BLOCKED_IMAGE", "/opt/nfc-tv/access-blocked.jpg"))
DAILY_LIMIT_HOURS = tuple(quarter / 4 for quarter in range(1, 13))
TV_IP = "192.168.1.145"
TV_MAC = "64:95:6c:17:9e:7a"
TV_PLAYBACK_VOLUME = int(os.environ.get("SHARPLAY_TV_PLAYBACK_VOLUME", "25"))
assert 0 <= TV_PLAYBACK_VOLUME <= 100, "invalid TV playback volume"
TORONTO = ZoneInfo("America/Toronto")
DEFAULT_SETTINGS = {"weekdayHours": 1, "weekendHours": 2}
SESSION_SECONDS = float(os.environ.get("NFC_TV_SESSION_SECONDS", "1500"))
SESSION_COOLDOWN_SECONDS = float(os.environ.get("NFC_TV_SESSION_COOLDOWN_SECONDS", "1500"))
LIMIT_FEEDBACK_SECONDS = float(os.environ.get("NFC_TV_LIMIT_FEEDBACK_SECONDS", "60"))
POLL_SECONDS = 0.2
STABLE_SECONDS = 0.15
WATCH_REMOVAL_SECONDS = 1.0
USAGE_WRITE_SECONDS = 1.0


def fsync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_json(path, value):
    """Atomically replace a JSON file, including the data and directory entry."""
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("w") as output:
            json.dump(value, output, indent=2)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
        fsync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def read_json(path):
    return json.loads(path.read_text())


def toronto_date(timestamp=None):
    return datetime.fromtimestamp(time.time() if timestamp is None else timestamp, TORONTO).date()


def validate_settings(value):
    assert type(value) is dict and set(value) == {"weekdayHours", "weekendHours"}, "invalid settings.json shape"
    assert all(
        type(value[key]) in (int, float) and value[key] in DAILY_LIMIT_HOURS
        for key in value
    ), "hours must use 15-minute intervals from 0.25 through 3"
    return value


def load_settings(path=SETTINGS):
    if not path.exists():
        write_json(path, DEFAULT_SETTINGS)
    return validate_settings(read_json(path))


def load_access(path=ACCESS):
    if not path.exists():
        write_json(path, {"blocked": False, "updatedAt": time.time()})
    value = read_json(path)
    assert type(value) is dict and set(value) == {"blocked", "updatedAt"}, "invalid access.json shape"
    assert type(value["blocked"]) is bool, "blocked must be boolean"
    assert type(value["updatedAt"]) in (int, float) and math.isfinite(value["updatedAt"]), "invalid access timestamp"
    return value["blocked"]


def validate_usage(value):
    assert type(value) is dict and set(value) == {"date", "seconds"}, "invalid usage.json shape"
    assert type(value["date"]) is str and date.fromisoformat(value["date"]).isoformat() == value["date"], "invalid usage date"
    assert type(value["seconds"]) in (int, float) and math.isfinite(value["seconds"]) and value["seconds"] >= 0, "invalid usage seconds"
    return {"date": value["date"], "seconds": float(value["seconds"])}


def load_usage(day, path=USAGE):
    if not path.exists():
        write_json(path, {"date": day.isoformat(), "seconds": 0.0})
    value = validate_usage(read_json(path))
    if value["date"] != day.isoformat():
        value = {"date": day.isoformat(), "seconds": 0.0}
        write_json(path, value)
    return value


def daily_limit_seconds(settings, day):
    return settings["weekendHours" if day.weekday() >= 5 else "weekdayHours"] * 3600


def fresh_session():
    return {"usedSeconds": 0.0, "cooldownUntil": None}


def validate_session(value):
    assert type(value) is dict and set(value) == {"usedSeconds", "cooldownUntil"}, "invalid session.json shape"
    used = value["usedSeconds"]
    cooldown = value["cooldownUntil"]
    assert type(used) in (int, float) and math.isfinite(used) and 0 <= used <= SESSION_SECONDS, "invalid session usage"
    assert cooldown is None or type(cooldown) in (int, float) and math.isfinite(cooldown) and cooldown >= 0, "invalid cooldown"
    assert cooldown is None or used == SESSION_SECONDS, "cooldown needs a completed session"
    assert used < SESSION_SECONDS or cooldown is not None, "completed session needs a cooldown"
    return {"usedSeconds": float(used), "cooldownUntil": None if cooldown is None else float(cooldown)}


def load_session(path=SESSION):
    if not path.exists():
        write_json(path, fresh_session())
    stored = read_json(path)
    legacy = type(stored) is dict and set(stored) == {"usedSeconds", "lastPlaybackAt", "cooldownUntil"}
    value = validate_session({key: stored[key] for key in ("usedSeconds", "cooldownUntil")} if legacy else stored)
    if legacy:
        write_json(path, value)
    return value


def refresh_session(value, now):
    """Start a fresh session when a completed session's cooldown expires."""
    if value["cooldownUntil"] is not None:
        return (fresh_session(), True) if now >= value["cooldownUntil"] else (value, False)
    return value, False


def skip_cooldown(value):
    if value["cooldownUntil"] is None:
        return value, False
    return fresh_session(), True


def begin_cooldown(value, completed_at):
    if value["usedSeconds"] < SESSION_SECONDS or value["cooldownUntil"] is not None:
        return False
    value["usedSeconds"] = SESSION_SECONDS
    value["cooldownUntil"] = completed_at + SESSION_COOLDOWN_SECONDS
    return True


def account_playback(used, session_used, elapsed, daily_limit):
    """Count one known-playing wall-clock interval and choose the first cutoff."""
    assert all(type(value) in (int, float) and math.isfinite(value) for value in (used, session_used, elapsed, daily_limit))
    assert used >= 0 and session_used >= 0 and elapsed >= 0 and daily_limit > 0
    daily_remaining = max(0.0, daily_limit - used)
    session_remaining = max(0.0, SESSION_SECONDS - session_used)
    daily_hit = daily_remaining <= elapsed
    session_hit = session_remaining <= elapsed
    reason = None
    if daily_hit or session_hit:
        reason = "daily" if daily_hit and (not session_hit or daily_remaining <= session_remaining) else "session"
    new_used = used if used >= daily_limit else min(float(daily_limit), used + elapsed)
    return new_used, min(float(SESSION_SECONDS), session_used + elapsed), reason


def validate_resume(value):
    assert type(value) is dict, "invalid resume.json shape"
    for media, position in value.items():
        assert type(media) is str and media, "invalid resume media"
        assert type(position) in (int, float) and math.isfinite(position) and position >= 0, "invalid resume position"
    return {media: float(position) for media, position in value.items()}


def load_resume(path=RESUME):
    return validate_resume(read_json(path)) if path.exists() else {}


def load_options(media, resumes):
    """Start from Sharplay's saved position, or from the beginning."""
    return {
        "pause": "no",
        "sub-visibility": "no",
        "start": f"{resumes.get(media, 0.0):.3f}",
    }


def load_cards():
    if not CARDS.exists():
        write_json(CARDS, {})
    value = read_json(CARDS)
    assert type(value) is dict, "invalid cards.json shape"
    for uid, item in value.items():
        assert type(uid) is str and type(item) is dict, "invalid card assignment"
        assert type(item.get("title")) is str and type(item.get("media")) is str, "card assignment needs title and media"
        assert type(item.get("subtitle", "")) is str, "invalid card subtitle"
    return value


def current_mode():
    value = read_json(MODE)
    assert type(value) is dict and set(value) == {"mode", "updatedAt"}, "invalid mode.json shape"
    assert value["mode"] in ("watch", "assign"), "invalid mode"
    assert type(value["updatedAt"]) in (int, float) and math.isfinite(value["updatedAt"]), "invalid mode timestamp"
    if value["mode"] == "assign" and time.time() - value["updatedAt"] > 600:
        value = {"mode": "watch", "updatedAt": time.time()}
        write_json(MODE, value)
        print("Assign mode expired; returning to Watch mode", flush=True)
    return value["mode"]


def record_scan(uid):
    item = load_cards().get(uid)
    write_json(SCAN, {"uid": uid, "scannedAt": time.time(), "assignment": item})
    return item


class NfcReader:
    def __init__(self, readers_fn=None, absent_codes=None):
        if readers_fn is None:
            from smartcard.System import readers

            readers_fn = readers
        if absent_codes is None:
            from smartcard.scard import SCARD_E_NO_SMARTCARD, SCARD_W_REMOVED_CARD

            absent_codes = {SCARD_E_NO_SMARTCARD, SCARD_W_REMOVED_CARD}
        self.readers = readers_fn
        self.absent_codes = absent_codes
        self.connection = None
        self.card_connected = False

    def _disconnect_card(self):
        if self.connection is not None and self.card_connected:
            try:
                self.connection.disconnect()
            except Exception:
                pass
            finally:
                self.card_connected = False

    def _reset_connection(self):
        if self.connection is not None:
            try:
                self.connection.release()
            except Exception:
                pass
            self.connection = None
            self.card_connected = False

    def card_uid(self):
        try:
            if self.connection is None:
                available = self.readers()
                if not available:
                    return None
                self.connection = available[0].createConnection()
            if not self.card_connected:
                self.connection.connect()
                self.card_connected = True
            data, sw1, sw2 = self.connection.transmit([0xFF, 0xCA, 0x00, 0x00, 0x00])
            if (sw1, sw2) == (0x90, 0x00):
                return "".join(f"{byte:02X}" for byte in data)
        except Exception as error:
            if getattr(error, "hresult", None) in self.absent_codes:
                self._disconnect_card()
            else:
                # Reader/service churn invalidates the context. Recreate it on
                # the next sample, while ordinary card removal retains it.
                self._reset_connection()
        return None


_nfc_reader = NfcReader()


def card_uid():
    return _nfc_reader.card_uid()


def connect_tv():
    from pywebostv.connection import WebOSClient

    store = read_json(CONFIG / "webos.json")
    for attempt in range(3):
        client = WebOSClient(TV_IP)
        try:
            client.connect()
            for _ in client.register(store):
                pass
            return client
        except ConnectionError:
            if attempt == 2:
                raise
            print(f"TV control connection reset; retrying ({attempt + 1}/2)", flush=True)
            time.sleep(0.5)


def wake_tv():
    # LG Quick Start can leave webOS reachable while the panel is still off, so
    # TCP reachability is not proof that WOL can be skipped.
    started = time.monotonic()
    packet = b"\xff" * 6 + bytes.fromhex(TV_MAC.replace(":", "")) * 16
    packets_sent = 0
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as wake:
        wake.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        # Let the kernel choose the current LAN address; DHCP may change it.
        wake.bind(("", 0))
        for address in ("192.168.1.255", "255.255.255.255"):
            wake.sendto(packet, (address, 9))
            packets_sent += 1
        try:
            with socket.create_connection((TV_IP, 3000), timeout=0.25):
                print("TV control port was already reachable; sent precautionary WOL", flush=True)
                return
        except OSError:
            pass

        print("TV control port was unreachable; continuing WOL", flush=True)
        for attempt in range(90):
            if attempt < 16 and attempt % 2 == 0:
                for address in ("192.168.1.255", "255.255.255.255"):
                    wake.sendto(packet, (address, 9))
                    packets_sent += 1
            try:
                with socket.create_connection((TV_IP, 3000), timeout=0.25):
                    elapsed = time.monotonic() - started
                    print(f"TV control port became reachable after {elapsed:.2f}s and {packets_sent} WOL packet(s)", flush=True)
                    return
            except OSError:
                time.sleep(0.25)
    elapsed = time.monotonic() - started
    raise RuntimeError(f"TV did not wake after {elapsed:.2f}s and {packets_sent} WOL packet(s)")


def prepare_tv():
    from pywebostv.controls import MediaControl, SourceControl

    started = time.monotonic()
    print("Preparing TV for playback", flush=True)
    wake_tv()
    client = connect_tv()
    print("Connected to TV control API", flush=True)
    sources = SourceControl(client)
    hdmi = next(source for source in sources.list_sources() if source["id"] == "HDMI_4")
    sources.set_source(hdmi)
    media = MediaControl(client)
    media.set_volume(TV_PLAYBACK_VOLUME)
    try:
        media.mute(False)
    except Exception as error:
        print(f"Could not clear TV mute: {error}", flush=True)
    time.sleep(0.5)
    print(f"TV prepared on HDMI 4 at volume {TV_PLAYBACK_VOLUME} in {time.monotonic() - started:.2f}s", flush=True)


def turn_tv_off():
    from pywebostv.controls import SystemControl

    print("Returning output to black and turning TV off", flush=True)
    try:
        SystemControl(connect_tv()).power_off()
    except Exception as error:
        print(f"Could not turn TV off: {error}", flush=True)


def mpv_request(commands, properties=False):
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
        connection.settimeout(2.0)
        connection.connect(str(MPV_SOCKET))
        for request_id, command in enumerate(commands, 1):
            connection.sendall((json.dumps({"command": command, "request_id": request_id}) + "\n").encode())

        pending = set(range(1, len(commands) + 1))
        results = {}
        buffered = b""
        while pending:
            chunk = connection.recv(65536)
            if not chunk:
                raise ConnectionError("mpv IPC closed before replying")
            buffered += chunk
            while b"\n" in buffered:
                raw, buffered = buffered.split(b"\n", 1)
                if not raw:
                    continue
                message = json.loads(raw)
                request_id = message.get("request_id")
                if request_id not in pending:
                    continue
                if message.get("error") != "success" and not properties:
                    raise RuntimeError(f"mpv command failed: {message.get('error')}: {commands[request_id - 1]}")
                results[request_id] = message.get("data") if message.get("error") == "success" else None
                pending.remove(request_id)
        return [results[index] for index in range(1, len(commands) + 1)]


def mpv_command(command):
    return mpv_request([command])[0]


def show_time_up_image(image=None):
    image = image or LIMIT_IMAGE
    if not image.is_file():
        raise FileNotFoundError(image)
    mpv_command(["set_property", "background", "color"])
    mpv_command(["loadfile", str(image), "replace", -1, {"image-display-duration": f"{LIMIT_FEEDBACK_SECONDS:g}", "pause": "no", "sub-visibility": "no"}])
    mpv_command(["set_property", "sub-visibility", False])
    mpv_command(["set_property", "pause", False])


def playback_snapshot():
    names = ("path", "time-pos", "duration", "pause", "speed", "paused-for-cache", "core-idle", "seeking", "eof-reached", "sub-visibility", "aid", "current-ao")
    values = mpv_request([["get_property", name] for name in names], properties=True)
    return dict(zip(names, values))


def audio_retry_position(current, snapshot):
    position = snapshot["time-pos"]
    if current.get("audioRetried") or snapshot["aid"] is not False:
        return None
    if type(position) not in (int, float) or not math.isfinite(position) or position < 0:
        return None
    return float(position)


def choose_drm_connector(card_name=DRM_DEVICE.resolve().name, sysfs_root=DRM_SYSFS):
    prefix = f"{card_name}-"
    connected = []
    for status_path in sorted(sysfs_root.glob(f"{card_name}-HDMI-*/status")):
        if status_path.read_text().strip() == "connected":
            connected.append(status_path.parent.name.removeprefix(prefix))
    if len(connected) != 1:
        raise RuntimeError(f"expected exactly one connected HDMI connector on {card_name}, found {connected}")
    return connected[0]


def source_drm_mode(media):
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,avg_frame_rate", "-of", "json", str(media)],
        check=True, capture_output=True, text=True, timeout=10,
    )
    streams = json.loads(probe.stdout).get("streams", [])
    if len(streams) != 1:
        raise RuntimeError(f"expected one video stream in {media}")
    stream = streams[0]
    width, height = int(stream["width"]), int(stream["height"])
    numerator, denominator = (int(value) for value in stream["avg_frame_rate"].split("/", 1))
    if denominator == 0:
        raise RuntimeError(f"invalid frame rate for {media}")
    fps = numerator / denominator
    if width > 3840 or height > 2160:
        raise RuntimeError(f"video exceeds HDMI-A-2 limits: {width}x{height}")
    if width > 1920 or height > 1080:
        resolution = "3840x2160"
        rates = ((24000 / 1001, "23.98"), (24, "24"), (25, "25"), (30000 / 1001, "29.97"), (30, "30"))
    else:
        resolution = "1920x1080"
        rates = ((24000 / 1001, "23.98"), (24, "24"), (25, "50"), (30000 / 1001, "59.94"), (30, "60"), (50, "50"), (60000 / 1001, "59.94"), (60, "60"))
    source_rate, display_rate = min(rates, key=lambda candidate: abs(fps - candidate[0]))
    if abs(fps - source_rate) > 0.05:
        raise RuntimeError(f"unsupported frame rate {fps:.3f} for {media}")
    return f"{resolution}@{display_rate}"


def start_mpv(drm_mode=None):
    MPV_SOCKET.unlink(missing_ok=True)
    connector = choose_drm_connector()
    command = [
        "mpv", "--no-config", "--no-terminal", "--really-quiet", "--idle=yes",
        "--force-window=immediate", "--keep-open=no", "--background=color",
        "--background-color=#000000", f"--vo={MPV_VIDEO_OUTPUT}", "--gpu-context=drm",
        f"--hwdec={MPV_HWDEC}", "--hwdec-codecs=all",
        f"--drm-device={DRM_DEVICE}", f"--drm-connector={connector}",
        f"--audio-device={MPV_AUDIO_DEVICE}", "--fullscreen", "--no-osc", "--osd-level=0",
        "--no-input-default-bindings", "--sub-visibility=no",
        *MPV_EXTRA_ARGS,
    ]
    if drm_mode:
        command.append(f"--drm-mode={drm_mode}")
    command.append(f"--input-ipc-server={MPV_SOCKET}")
    player = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(50):
        if player.poll() is not None:
            raise RuntimeError(f"mpv exited during startup with status {player.returncode}")
        if MPV_SOCKET.exists():
            try:
                mpv_request([["get_property", "idle-active"]], properties=True)
                return player
            except OSError:
                pass
        time.sleep(0.1)
    terminate_mpv(player)
    raise RuntimeError("mpv IPC did not become ready")


def terminate_mpv(player):
    if player.poll() is not None:
        return
    player.terminate()
    try:
        player.wait(timeout=3)
    except subprocess.TimeoutExpired:
        player.kill()
        player.wait()


def prepare_video_output():
    mpv_command(["set_property", "background", "none" if MPV_DIRECT_VIDEO else "color"])


def stop_to_black():
    mpv_command(["set_property", "background", "color"])
    mpv_command(["set_property", "sub-visibility", False])
    mpv_command(["stop"])


def capture_resume(current, playback, resumes):
    """Save only a confirmed loaded-file position; never replace a good resume with loading-time zero."""
    if not current or not current.get("loaded"):
        return False
    exact = playback_snapshot()["time-pos"]
    if type(exact) not in (int, float) or not math.isfinite(exact) or exact < 0:
        return False
    playback["position"] = float(exact)
    resumes[current["media"]] = playback["position"]
    write_json(RESUME, resumes)
    return True


def checkpoint_resume(current, playback, resumes, path=RESUME):
    if not current or not current.get("loaded") or not playback["positionConfirmed"] or resumes.get(current["media"]) == playback["position"]:
        return False
    resumes[current["media"]] = playback["position"]
    write_json(path, resumes)
    return True


def clear_finished_media(current, resumes, path=RESUME):
    """Forget resume state so the next card tap starts at the beginning."""
    if current["media"] in resumes:
        del resumes[current["media"]]
        write_json(path, resumes)


def claim_command():
    if COMMAND_IN_PROGRESS.exists():
        return COMMAND_IN_PROGRESS
    if not COMMAND.exists():
        return None
    os.replace(COMMAND, COMMAND_IN_PROGRESS)
    fsync_directory(STATE)
    return COMMAND_IN_PROGRESS


def validate_command(value):
    assert type(value) is dict and type(value.get("action")) is str, "invalid command.json"
    if value["action"] in ("stop", "skipCooldown"):
        assert set(value) == {"action"}, f"{value['action']} command only accepts action"
    elif value["action"] == "play":
        assert set(value) == {"action", "media"} and type(value["media"]) is str and value["media"], "play command needs media"
    elif value["action"] == "finish":
        assert set(value) == {"action", "playbackId"}, "finish command needs playbackId"
    elif value["action"] == "pause":
        assert set(value) == {"action", "playbackId", "paused"} and type(value["paused"]) is bool, "pause command needs playbackId and boolean paused"
    elif value["action"] == "subtitles":
        assert set(value) == {"action", "playbackId", "visible"} and type(value["visible"]) is bool, "subtitles command needs playbackId and boolean visible"
    elif value["action"] == "seek":
        absolute = type(value.get("position")) in (int, float) and math.isfinite(value["position"]) and 0 <= value["position"] <= 86400
        relative = type(value.get("seconds")) in (int, float) and math.isfinite(value["seconds"]) and abs(value["seconds"]) <= 60
        assert type(value.get("playbackId")) is str and bool(value["playbackId"]), "seek command needs playbackId"
        assert absolute != relative and set(value) == ({"action", "playbackId", "position"} if absolute else {"action", "playbackId", "seconds"}), "seek command needs one valid target"
    elif value["action"] == "speed":
        assert set(value) == {"action", "playbackId", "value"} and type(value["value"]) in (int, float) and value["value"] in (0.75, 1, 1.25, 1.5, 2), "speed command needs playbackId and valid value"
    else:
        raise AssertionError("unknown command action")
    if "playbackId" in value:
        assert type(value["playbackId"]) is str and value["playbackId"], "invalid playbackId"
    return value


def blank_playback_state():
    return {
        "position": 0.0, "positionConfirmed": False, "duration": 0.0, "paused": False, "loading": False,
        "playing": False, "subtitlesVisible": False, "speed": 1.0,
    }


def publish_status(mode, current, limit_feedback, playback, session, usage, settings, force, last_write):
    now = time.monotonic()
    if not force and (current is None and not limit_feedback or now - last_write < 1.0):
        return last_write
    wall_now = time.time()
    limit = daily_limit_seconds(settings, date.fromisoformat(usage["date"]))
    cooldown_remaining = max(0.0, (session["cooldownUntil"] or 0) - wall_now)
    if limit_feedback:
        state = "limit"
    elif cooldown_remaining > 0 and current is None:
        state = "cooldown"
    elif current is None:
        state = "idle"
    elif playback["playing"]:
        state = "playing"
    elif playback["paused"]:
        state = "paused"
    else:
        state = "loading"
    write_json(STATUS, {
        "state": state,
        "active": current is not None,
        "mode": mode,
        "playbackId": current["id"] if current else "",
        "media": current["media"] if current else "",
        "title": current["title"] if current else "",
        "position": round(playback["position"], 3) if current else 0,
        "duration": round(playback["duration"], 3) if current else 0,
        "paused": bool(current and playback["paused"]),
        "speed": playback["speed"] if current else 1.0,
        "subtitlesVisible": bool(current and playback["subtitlesVisible"]),
        "override": bool(current and current.get("override")),
        "sessionUsedSeconds": round(session["usedSeconds"], 3),
        "sessionRemainingSeconds": round(max(0.0, SESSION_SECONDS - session["usedSeconds"]), 3),
        "cooldownUntil": session["cooldownUntil"],
        "cooldownRemainingSeconds": round(cooldown_remaining, 3),
        "date": usage["date"],
        "dailyUsedSeconds": round(usage["seconds"], 3),
        "dailyLimitSeconds": limit,
        "dailyRemainingSeconds": round(max(0.0, limit - usage["seconds"]), 3),
        "updatedAt": wall_now,
    })
    notify_refresh()
    return now


def main():
    STATE.mkdir(exist_ok=True)
    settings = load_settings()
    access_blocked = load_access()
    usage = load_usage(toronto_date())
    session = load_session()
    resumes = load_resume()
    cards = load_cards()
    write_json(MODE, {"mode": "watch", "updatedAt": time.time()})
    SCAN.unlink(missing_ok=True)

    player_mode = MPV_DRM_MODE or None
    player = start_mpv(player_mode)
    backend = start_backend(
        os.environ.get("SHARPLAY_HOST", "127.0.0.1"),
        int(os.environ.get("SHARPLAY_PORT", "8787")),
    )
    mode = "watch"
    current = None
    limit_feedback = False
    feedback_until = None
    playback = blank_playback_state()
    usage_dirty = False
    session_dirty = False
    last_usage_write = time.monotonic()
    last_resume_write = time.monotonic()
    last_status_write = 0.0
    last_tick = time.monotonic()
    was_playing = False
    snapshot_failures = 0
    last_state_read = time.monotonic()
    running = True

    def request_shutdown(_signum, _frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, request_shutdown)
    signal.signal(signal.SIGINT, request_shutdown)

    def match_player_to(media):
        nonlocal player, player_mode
        target_mode = source_drm_mode(media)
        if target_mode == player_mode:
            return
        print(f"Switching DRM output from {player_mode or 'preferred'} to {target_mode}", flush=True)
        terminate_mpv(player)
        previous_mode = player_mode
        try:
            player = start_mpv(target_mode)
        except Exception:
            player = start_mpv(previous_mode)
            raise
        player_mode = target_mode

    def account_active_interval(daily_limit):
        nonlocal last_tick, usage_dirty, session_dirty
        now = time.monotonic()
        cutoff = None
        if current and was_playing and not current.get("override"):
            elapsed = max(0.0, now - last_tick)
            old_used = usage["seconds"]
            old_session_used = session["usedSeconds"]
            usage["seconds"], session["usedSeconds"], cutoff = account_playback(old_used, old_session_used, elapsed, daily_limit)
            wall_now = time.time()
            if begin_cooldown(session, wall_now - max(0.0, old_session_used + elapsed - SESSION_SECONDS)) and cutoff is None:
                cutoff = "session"
            usage_dirty |= usage["seconds"] != old_used
            session_dirty = True
        last_tick = now
        return cutoff

    last_uid = card_uid()
    if last_uid:
        print("Card present at startup; remove it before the next tap", flush=True)
    absent_since = None
    candidate_uid = None
    candidate_since = None
    previous_mode = "watch"
    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
    print(f"NFC Movie Box ready: {len(cards)} registered card(s); persistent DRM output is black", flush=True)

    try:
        while running:
            loop_started = time.monotonic()
            if loop_started - last_state_read >= 0.5:
                try:
                    settings = load_settings()
                    new_access_blocked = load_access()
                    if new_access_blocked != access_blocked:
                        access_blocked = new_access_blocked
                        print(f"Card taps {'blocked' if access_blocked else 'allowed'}", flush=True)
                except (AssertionError, json.JSONDecodeError, OSError) as error:
                    print(f"Keeping last valid settings/access state: {error}", flush=True)
                last_state_read = loop_started

            session, session_reset = refresh_session(session, time.time())
            if session_reset:
                write_json(SESSION, session)
                session_dirty = False
                print("Session cooldown complete; a fresh session is available", flush=True)
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)

            day = toronto_date()
            if usage["date"] != day.isoformat():
                usage = {"date": day.isoformat(), "seconds": 0.0}
                write_json(USAGE, usage)
                usage_dirty = False
                last_usage_write = loop_started
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
            daily_limit = daily_limit_seconds(settings, day)

            returncode = player.poll()
            if returncode is not None:
                now = time.monotonic()
                account_active_interval(daily_limit)
                if usage_dirty:
                    write_json(USAGE, usage)
                    usage_dirty = False
                if session_dirty:
                    write_json(SESSION, session)
                    session_dirty = False
                had_display = current is not None or limit_feedback
                print(f"mpv exited with status {returncode}; restoring black DRM output", flush=True)
                current = None
                limit_feedback = False
                feedback_until = None
                playback = blank_playback_state()
                was_playing = False
                player = start_mpv(player_mode)
                last_tick = time.monotonic()
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                if had_display:
                    turn_tv_off()
                time.sleep(POLL_SECONDS)
                continue

            try:
                snapshot = playback_snapshot()
                snapshot_failures = 0
            except (OSError, ConnectionError, TimeoutError) as error:
                if player.poll() is not None:
                    continue
                snapshot_failures += 1
                cutoff = account_active_interval(daily_limit)
                if cutoff is not None or snapshot_failures >= 3:
                    print(f"mpv IPC remained unresponsive; replacing it with black output: {error}", flush=True)
                    terminate_mpv(player)
                    continue
                print(f"mpv IPC sample failed ({snapshot_failures}/3): {error}", flush=True)
                time.sleep(POLL_SECONDS)
                continue
            now = time.monotonic()
            cutoff = account_active_interval(daily_limit)

            if current:
                path_matches = snapshot["path"] == current["url"]
                if path_matches:
                    current["loaded"] = True
                    retry_position = audio_retry_position(current, snapshot)
                    if retry_position is not None:
                        current["audioRetried"] = True
                        options = load_options(current["media"], resumes)
                        options.update({"start": f"{retry_position:.3f}", "aid": "auto"})
                        try:
                            prepare_video_output()
                            mpv_command(["set_property", "sub-visibility", False])
                            mpv_command(["loadfile", current["url"], "replace", -1, options])
                            current["subtitleAdded"] = not bool(current["subtitle"])
                            current["subtitleAttempts"] = 0
                            current["loaded"] = False
                            current["loadingAt"] = time.monotonic()
                            playback["position"] = retry_position
                            playback["loading"] = True
                            playback["playing"] = False
                            was_playing = False
                            last_tick = time.monotonic()
                            print(f"Retrying HDMI audio once at {retry_position:.3f}s", flush=True)
                            last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                            time.sleep(max(0.0, POLL_SECONDS - (time.monotonic() - loop_started)))
                            continue
                        except (OSError, RuntimeError, TimeoutError) as error:
                            print(f"Could not retry HDMI audio: {error}", flush=True)
                    if current["subtitle"] and not current["subtitleAdded"]:
                        try:
                            mpv_command(["sub-add", current["subtitle"], "select"])
                            mpv_command(["set_property", "sub-visibility", False])
                            current["subtitleAdded"] = True
                        except RuntimeError as error:
                            current["subtitleAttempts"] += 1
                            if current["subtitleAttempts"] >= 3:
                                current["subtitleAdded"] = True
                                print(f"Could not load subtitles for {current['title']}: {error}", flush=True)
                    if type(snapshot["time-pos"]) in (int, float) and math.isfinite(snapshot["time-pos"]):
                        playback["position"] = max(0.0, float(snapshot["time-pos"]))
                        playback["positionConfirmed"] = True
                    if type(snapshot["duration"]) in (int, float) and math.isfinite(snapshot["duration"]):
                        playback["duration"] = max(0.0, float(snapshot["duration"]))
                playback["paused"] = bool(snapshot["pause"])
                if type(snapshot["speed"]) in (int, float) and math.isfinite(snapshot["speed"]):
                    playback["speed"] = float(snapshot["speed"])
                playback["loading"] = bool(not path_matches or snapshot["paused-for-cache"] or snapshot["core-idle"] or snapshot["seeking"])
                playback["subtitlesVisible"] = bool(path_matches and snapshot["sub-visibility"])
                playback["playing"] = bool(
                    path_matches and not snapshot["pause"] and not snapshot["paused-for-cache"]
                    and not snapshot["core-idle"] and not snapshot["seeking"] and not snapshot["eof-reached"]
                )
            else:
                playback = blank_playback_state()
            was_playing = bool(current and playback["playing"])

            if now - last_resume_write >= USAGE_WRITE_SECONDS:
                checkpoint_resume(current, playback, resumes)
                last_resume_write = now

            if (usage_dirty or session_dirty) and now - last_usage_write >= USAGE_WRITE_SECONDS:
                if usage_dirty:
                    write_json(USAGE, usage)
                    usage_dirty = False
                if session_dirty:
                    write_json(SESSION, session)
                    session_dirty = False
                last_usage_write = now

            if current and not current.get("override") and usage["seconds"] >= daily_limit and cutoff is None:
                cutoff = "daily"
            ended = bool(current and current["loaded"] and (snapshot["eof-reached"] or not snapshot["path"]))
            loading_failed = bool(current and not current["loaded"] and now - current["loadingAt"] >= 60)
            if ended:
                print(f"Finished: {current['title']}", flush=True)
                clear_finished_media(current, resumes)
                if usage_dirty:
                    write_json(USAGE, usage)
                    usage_dirty = False
                if session_dirty:
                    write_json(SESSION, session)
                    session_dirty = False
                last_usage_write = now
                stop_to_black()
                current = None
                playback = blank_playback_state()
                was_playing = False
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                turn_tv_off()
            elif loading_failed:
                print(f"Media did not load: {current['title']}", flush=True)
                stop_to_black()
                current = None
                playback = blank_playback_state()
                was_playing = False
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                turn_tv_off()
            elif current and cutoff:
                mpv_command(["set_property", "pause", True])
                capture_resume(current, playback, resumes)
                if cutoff == "session":
                    assert session["cooldownUntil"] is not None
                if usage_dirty:
                    write_json(USAGE, usage)
                    usage_dirty = False
                if session_dirty:
                    write_json(SESSION, session)
                    session_dirty = False
                last_usage_write = now
                print(f"{cutoff.capitalize()} playback cutoff at {playback['position']:.3f}s", flush=True)
                stop_to_black()
                current = None
                playback = blank_playback_state()
                was_playing = False
                if cutoff == "daily":
                    limit_feedback = True
                    feedback_until = None
                    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    try:
                        show_time_up_image()
                        feedback_until = time.monotonic() + LIMIT_FEEDBACK_SECONDS
                    except Exception as error:
                        print(f"Could not show daily-limit image: {error}", flush=True)
                        stop_to_black()
                        limit_feedback = False
                        turn_tv_off()
                else:
                    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    try:
                        show_time_up_image(SESSION_IMAGE)
                        feedback_until = time.monotonic() + LIMIT_FEEDBACK_SECONDS
                    except Exception as error:
                        print(f"Could not show session time-up image: {error}", flush=True)
                        stop_to_black()
                        turn_tv_off()

            if feedback_until is not None and time.monotonic() >= feedback_until:
                stop_to_black()
                limit_feedback = False
                feedback_until = None
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                turn_tv_off()

            command_path = claim_command()
            command = None
            if command_path:
                try:
                    command = validate_command(read_json(command_path))
                except Exception as error:
                    print(f"Discarding invalid player command: {error}", flush=True)
                finally:
                    command_path.unlink(missing_ok=True)
                    fsync_directory(STATE)
            if command:
                if "playbackId" in command and (current is None or command["playbackId"] != current["id"]):
                    print(f"Ignoring stale {command['action']} command", flush=True)
                elif command["action"] == "skipCooldown":
                    session, skipped = skip_cooldown(session)
                    if skipped:
                        write_json(SESSION, session)
                        session_dirty = False
                        if current is None and feedback_until is not None:
                            stop_to_black()
                            feedback_until = None
                            turn_tv_off()
                        print("Session cooldown skipped; a fresh session is available", flush=True)
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    else:
                        print("Ignoring skip-cooldown command while no cooldown is active", flush=True)
                elif command["action"] == "play":
                    media = command["media"]
                    media_path = safe_media_path(media)
                    base = Path(media).with_suffix("").as_posix()
                    subtitle = next((
                        str(safe_media_path(candidate, False))
                        for candidate in (f"{base}.srt", f"{base}.eng.srt", f"{base}.eng.SDH.srt")
                        if safe_media_path(candidate, False).is_file()
                    ), "")
                    if current:
                        account_active_interval(daily_limit)
                        mpv_command(["set_property", "pause", True])
                        capture_resume(current, playback, resumes)
                        if usage_dirty:
                            write_json(USAGE, usage)
                            usage_dirty = False
                        if session_dirty:
                            write_json(SESSION, session)
                            session_dirty = False
                        last_usage_write = time.monotonic()
                    limit_feedback = False
                    feedback_until = None
                    current = {
                        "id": str(time.time_ns()),
                        "media": media,
                        "title": media_path.stem,
                        "url": str(media_path),
                        "subtitle": subtitle,
                        "subtitleAdded": not bool(subtitle),
                        "subtitleAttempts": 0,
                        "audioRetried": False,
                        "loaded": False,
                        "loadingAt": time.monotonic(),
                        "override": True,
                    }
                    playback = blank_playback_state()
                    was_playing = False
                    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    print(f"Parent play: {current['title']}; limits ignored", flush=True)
                    try:
                        match_player_to(media_path)
                        prepare_tv()
                        options = load_options(media, resumes)
                        prepare_video_output()
                        mpv_command(["set_property", "sub-visibility", False])
                        mpv_command(["loadfile", current["url"], "replace", -1, options])
                        current["loadingAt"] = time.monotonic()
                        mpv_command(["set_property", "sub-visibility", False])
                        mpv_command(["set_property", "pause", False])
                        last_tick = time.monotonic()
                    except Exception as error:
                        print(f"Parent playback failed: {error}", flush=True)
                        stop_to_black()
                        current = None
                        playback = blank_playback_state()
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                        turn_tv_off()
                elif command["action"] == "pause":
                    if current:
                        boundary_cutoff = account_active_interval(daily_limit)
                        if boundary_cutoff is None:
                            mpv_command(["set_property", "pause", command["paused"]])
                            playback["paused"] = command["paused"]
                            playback["playing"] = bool(not command["paused"] and current["loaded"] and not playback["loading"])
                            was_playing = playback["playing"]
                            last_tick = time.monotonic()
                            if command["paused"]:
                                capture_resume(current, playback, resumes)
                            print("Paused" if command["paused"] else "Resumed", flush=True)
                            last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                        else:
                            print("Playback limit reached before pause command", flush=True)
                    else:
                        print("Ignoring pause command while no video is playing", flush=True)
                elif command["action"] == "subtitles":
                    if current:
                        mpv_command(["set_property", "sub-visibility", command["visible"]])
                        playback["subtitlesVisible"] = command["visible"]
                        print(f"Subtitles {'on' if command['visible'] else 'off'}", flush=True)
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    else:
                        print("Ignoring subtitles command while no video is playing", flush=True)
                elif command["action"] == "seek":
                    target = command.get("position")
                    mpv_command(["seek", target if target is not None else command["seconds"], "absolute+exact" if target is not None else "relative"])
                    print("Seeked playback", flush=True)
                elif command["action"] == "speed":
                    mpv_command(["set_property", "speed", command["value"]])
                    playback["speed"] = float(command["value"])
                    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                elif command["action"] == "finish":
                    if current:
                        account_active_interval(daily_limit)
                        mpv_command(["set_property", "pause", True])
                        clear_finished_media(current, resumes)
                        if usage_dirty:
                            write_json(USAGE, usage)
                            usage_dirty = False
                        write_json(SESSION, session)
                        session_dirty = False
                        last_usage_write = time.monotonic()
                        print(f"Finished manually: {current['title']}; next tap starts from the beginning", flush=True)
                        stop_to_black()
                        current = None
                        playback = blank_playback_state()
                        was_playing = False
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                        turn_tv_off()
                    else:
                        print("Ignoring finish command while already idle", flush=True)
                elif current:
                    account_active_interval(daily_limit)
                    mpv_command(["set_property", "pause", True])
                    capture_resume(current, playback, resumes)
                    if usage_dirty:
                        write_json(USAGE, usage)
                        usage_dirty = False
                    write_json(SESSION, session)
                    session_dirty = False
                    last_usage_write = time.monotonic()
                    print(f"Manual stop at {playback['position']:.3f}s; {max(0.0, SESSION_SECONDS - session['usedSeconds']):.1f}s remain in this session", flush=True)
                    stop_to_black()
                    current = None
                    playback = blank_playback_state()
                    was_playing = False
                    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    turn_tv_off()
                elif limit_feedback or feedback_until is not None:
                    stop_to_black()
                    limit_feedback = False
                    feedback_until = None
                    last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                    turn_tv_off()
                else:
                    print("Ignoring stop command while already idle", flush=True)

            new_mode = current_mode()
            if new_mode != mode:
                mode = new_mode
                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
            uid = card_uid()
            detected_at = time.monotonic()

            if mode == "assign":
                if previous_mode != "assign" and uid:
                    last_uid = uid
                    candidate_uid = None
                    record_scan(uid)
                    print(f"Card ready to assign: {uid}", flush=True)
                elif uid:
                    absent_since = None
                    if uid == last_uid:
                        candidate_uid = None
                    elif uid != candidate_uid:
                        candidate_uid = uid
                        candidate_since = detected_at
                    elif detected_at - candidate_since >= STABLE_SECONDS:
                        last_uid = uid
                        candidate_uid = None
                        record_scan(uid)
                        print(f"Card ready to assign: {uid}", flush=True)
                else:
                    candidate_uid = None
                    if last_uid:
                        absent_since = absent_since or detected_at
                        if detected_at - absent_since >= STABLE_SECONDS:
                            last_uid = None
                            absent_since = None
                            print("Reader armed for the next card", flush=True)
            else:
                accepted_uid = None
                if uid:
                    absent_since = None
                    if last_uid is None:
                        last_uid = uid
                        candidate_uid = None
                        accepted_uid = uid
                    elif uid == last_uid:
                        candidate_uid = None
                    elif uid != candidate_uid:
                        candidate_uid = uid
                        candidate_since = detected_at
                    elif detected_at - candidate_since >= STABLE_SECONDS:
                        last_uid = uid
                        candidate_uid = None
                        accepted_uid = uid
                else:
                    candidate_uid = None
                    if last_uid:
                        absent_since = absent_since or detected_at
                        if detected_at - absent_since >= WATCH_REMOVAL_SECONDS:
                            last_uid = None
                            absent_since = None
                            print("Reader armed for the next card", flush=True)

                item = record_scan(accepted_uid) if accepted_uid and not access_blocked else None
                if accepted_uid and access_blocked:
                    if current:
                        print("Card taps are blocked; leaving active playback unchanged", flush=True)
                    else:
                        print("Card taps are blocked; showing unavailable image", flush=True)
                        try:
                            prepare_tv()
                            show_time_up_image(BLOCKED_IMAGE)
                            feedback_until = time.monotonic() + LIMIT_FEEDBACK_SECONDS
                        except Exception as error:
                            print(f"Could not show blocked-access image: {error}", flush=True)
                            stop_to_black()
                            feedback_until = None
                            turn_tv_off()
                elif accepted_uid and not item:
                    print(f"Unknown card: {accepted_uid}", flush=True)
                if item:
                    if current and current.get("override") and (usage["seconds"] >= daily_limit or session["cooldownUntil"] is not None):
                        mpv_command(["set_property", "pause", True])
                        capture_resume(current, playback, resumes)
                        current = None
                        playback = blank_playback_state()
                        was_playing = False
                    if limit_feedback:
                        print("Daily-limit notice is active; ignoring Watch-mode tap", flush=True)
                    elif usage["seconds"] >= daily_limit:
                        print("Daily playback limit already reached", flush=True)
                        limit_feedback = True
                        feedback_until = None
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                        try:
                            prepare_tv()
                            show_time_up_image()
                            feedback_until = time.monotonic() + LIMIT_FEEDBACK_SECONDS
                        except Exception as error:
                            print(f"Could not show daily-limit image: {error}", flush=True)
                            stop_to_black()
                            limit_feedback = False
                            last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                            turn_tv_off()
                    elif session["cooldownUntil"] is not None:
                        remaining = max(0.0, session["cooldownUntil"] - time.time())
                        print(f"Session cooldown active for another {remaining:.1f}s", flush=True)
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                        if feedback_until is None:
                            try:
                                prepare_tv()
                                show_time_up_image(SESSION_IMAGE)
                                feedback_until = time.monotonic() + LIMIT_FEEDBACK_SECONDS
                            except Exception as error:
                                print(f"Could not show session cooldown image: {error}", flush=True)
                                stop_to_black()
                                turn_tv_off()
                    elif current and item["media"] == current["media"]:
                        try:
                            prepare_tv()
                            print("That video is already playing; TV returned to Sharplay", flush=True)
                        except Exception as error:
                            print(f"Could not return TV to Sharplay: {error}", flush=True)
                    else:
                        switching = current is not None
                        if switching:
                            old_title = current["title"]
                            boundary_cutoff = account_active_interval(daily_limit)
                            if boundary_cutoff is not None:
                                print("Playback limit reached before card switch", flush=True)
                                previous_mode = mode
                                last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                                time.sleep(max(0.0, POLL_SECONDS - (time.monotonic() - loop_started)))
                                continue
                            mpv_command(["set_property", "pause", True])
                            capture_resume(current, playback, resumes)
                            if usage_dirty:
                                write_json(USAGE, usage)
                                usage_dirty = False
                            write_json(SESSION, session)
                            session_dirty = False
                            last_usage_write = time.monotonic()
                            print(f"Switching from {old_title} to {item['title']}; session timer continues", flush=True)
                        else:
                            print(f"Playing: {item['title']}", flush=True)

                        media = item["media"]
                        feedback_until = None
                        current = {
                            "id": str(time.time_ns()),
                            "media": media,
                            "title": item["title"],
                            "url": str(safe_media_path(media)),
                            "subtitle": str(safe_media_path(item["subtitle"])) if item.get("subtitle") else "",
                            "subtitleAdded": not bool(item.get("subtitle")),
                            "subtitleAttempts": 0,
                            "audioRetried": False,
                            "override": False,
                            "loaded": False,
                            "loadingAt": time.monotonic(),
                        }
                        playback = blank_playback_state()
                        was_playing = False
                        last_tick = time.monotonic()
                        last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                        try:
                            match_player_to(Path(current["url"]))
                            prepare_tv()
                            options = load_options(media, resumes)
                            prepare_video_output()
                            mpv_command(["set_property", "sub-visibility", False])
                            mpv_command(["loadfile", current["url"], "replace", -1, options])
                            current["loadingAt"] = time.monotonic()
                            mpv_command(["set_property", "sub-visibility", False])
                            mpv_command(["set_property", "pause", False])
                            last_tick = time.monotonic()
                        except Exception as error:
                            print(f"Playback failed: {error}", flush=True)
                            stop_to_black()
                            current = None
                            playback = blank_playback_state()
                            last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
                            turn_tv_off()

            previous_mode = mode
            last_status_write = publish_status(mode, current, limit_feedback, playback, session, usage, settings, False, last_status_write)
            time.sleep(max(0.0, POLL_SECONDS - (time.monotonic() - loop_started)))
    finally:
        if current:
            try:
                mpv_command(["set_property", "pause", True])
            except (OSError, RuntimeError, TimeoutError):
                pass
        if current and was_playing:
            limit = daily_limit_seconds(settings, date.fromisoformat(usage["date"]))
            account_active_interval(limit)
        if usage_dirty:
            write_json(USAGE, usage)
        if session_dirty:
            write_json(SESSION, session)
        if current:
            try:
                capture_resume(current, playback, resumes)
            except (OSError, RuntimeError, TimeoutError):
                pass
        current = None
        limit_feedback = False
        playback = blank_playback_state()
        publish_status(mode, current, limit_feedback, playback, session, usage, settings, True, last_status_write)
        if player.poll() is None:
            try:
                stop_to_black()
            except (OSError, RuntimeError):
                pass
            terminate_mpv(player)
        backend.close()


if __name__ == "__main__":
    main()
