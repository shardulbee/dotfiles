"""Small HTTP/SSE backend for the Sharplay appliance process."""

import hashlib
import json
import math
import mimetypes
import os
import re
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

SOURCE_DIR = Path(__file__).resolve().parent
DEFAULT_APP_DIR = SOURCE_DIR / "app" if (SOURCE_DIR / "app").is_dir() else SOURCE_DIR.parent / "app"
STATE = Path(os.environ.get("SHARPLAY_STATE_DIR", "/var/lib/nfc-tv"))
MEDIA_ROOT = Path(os.environ.get("SHARPLAY_MEDIA_ROOT", "/srv/sharplay/media"))
APP_DIR = Path(os.environ.get("SHARPLAY_APP_DIR", DEFAULT_APP_DIR))
FFMPEG = os.environ.get("SHARPLAY_FFMPEG", "/usr/bin/ffmpeg")
FFPROBE = os.environ.get("SHARPLAY_FFPROBE", "/usr/bin/ffprobe")

CARDS = STATE / "cards.json"
MODE = STATE / "mode.json"
SCAN = STATE / "last-scan.json"
STATUS = STATE / "status.json"
SETTINGS = STATE / "settings.json"
ACCESS = STATE / "access.json"
COMMAND = STATE / "command.json"
EVENTS = STATE / "events.ndjson"
METADATA = STATE / "media-metadata.json"
THUMBNAILS = STATE / "thumbnails"
DEFAULT_SETTINGS = {"weekdayHours": 1, "weekendHours": 2}
DAILY_LIMIT_HOURS = tuple(quarter / 4 for quarter in range(1, 13))
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".m4v", ".mov", ".webm"}

_refresh = threading.Condition()
_refresh_revision = 0
_command_lock = threading.Lock()
_event_lock = threading.Lock()
_thumbnail_lock = threading.Lock()


def fsync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_json(path, value):
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        with temporary.open("w") as output:
            json.dump(value, output, indent=2)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
        fsync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def read_json(path, fallback=None):
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return fallback


def notify_refresh():
    global _refresh_revision
    with _refresh:
        _refresh_revision += 1
        _refresh.notify_all()


def append_event(kind, **details):
    with _event_lock, EVENTS.open("a") as output:
        output.write(json.dumps({"at": time.time(), "type": kind, **details}) + "\n")


def playback_state():
    status = read_json(STATUS)
    if not isinstance(status, dict) or status.get("active") and time.time() - float(status.get("updatedAt") or 0) > 10:
        return {
            "state": "idle", "active": False, "position": 0, "duration": 0,
            "paused": False, "speed": 1, "title": "", "media": "", "playbackId": "", "subtitles": False,
            "override": False, "sessionUsedSeconds": 0, "sessionRemainingSeconds": 25 * 60,
            "cooldownUntil": 0, "cooldownRemainingSeconds": 0,
            "dailyUsedSeconds": 0, "dailyLimitSeconds": 0, "dailyRemainingSeconds": 0,
            "date": "",
        }

    position = float(status.get("position") or 0)
    duration = float(status.get("duration") or 0)
    paused = bool(status.get("paused"))
    speed = float(status.get("speed") or 1)
    subtitles = bool(status.get("subtitlesVisible"))
    cooldown_until = float(status.get("cooldownUntil") or 0)
    cooldown_remaining = max(0.0, cooldown_until - time.time())
    state = status.get("state") or "idle"
    if state == "cooldown" and cooldown_remaining == 0:
        state = "idle"
    return {
        "state": state,
        "active": bool(status.get("active")),
        "position": position,
        "duration": duration,
        "paused": paused,
        "speed": speed,
        "title": status.get("title") or "",
        "media": status.get("media") or "",
        "playbackId": status.get("playbackId") or "",
        "subtitles": subtitles,
        "override": bool(status.get("override")),
        "sessionUsedSeconds": float(status.get("sessionUsedSeconds") or 0),
        "sessionRemainingSeconds": float(status.get("sessionRemainingSeconds") or 0),
        "cooldownUntil": cooldown_until,
        "cooldownRemainingSeconds": cooldown_remaining,
        "dailyUsedSeconds": float(status.get("dailyUsedSeconds") or 0),
        "dailyLimitSeconds": float(status.get("dailyLimitSeconds") or 0),
        "dailyRemainingSeconds": float(status.get("dailyRemainingSeconds") or 0),
        "date": status.get("date") or "",
    }


def safe_media_path(relative, must_exist=True):
    if not isinstance(relative, str) or not relative or "\0" in relative:
        raise ValueError("Invalid media path")
    candidate = (MEDIA_ROOT / relative).resolve()
    root = MEDIA_ROOT.resolve()
    if not candidate.is_relative_to(root) or must_exist and not candidate.is_file():
        raise ValueError("Unknown media")
    return candidate


def scan_files():
    if not MEDIA_ROOT.is_dir():
        return set()
    root = MEDIA_ROOT.resolve()
    return {
        path.relative_to(MEDIA_ROOT).as_posix()
        for path in MEDIA_ROOT.rglob("*")
        if path.is_file() and path.resolve().is_relative_to(root)
    }


def scan_media():
    return sorted(path for path in scan_files() if Path(path).suffix.lower() in VIDEO_EXTENSIONS)


def probe_duration(relative):
    try:
        result = subprocess.run(
            [FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(safe_media_path(relative))],
            capture_output=True, text=True, timeout=30, check=False,
        )
        return relative, {"duration": float(result.stdout.strip()) if result.returncode == 0 else 0}
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return relative, {"duration": 0}


def index_media_once():
    videos = scan_media()
    metadata = read_json(METADATA, {})
    if not isinstance(metadata, dict):
        metadata = {}
    missing = [path for path in videos if path not in metadata]
    with ThreadPoolExecutor(max_workers=4) as pool:
        for path, value in pool.map(probe_duration, missing):
            metadata[path] = value
    metadata = {path: metadata[path] for path in videos}
    write_json(METADATA, metadata)
    notify_refresh()


def media_index_loop(stop):
    while not stop.is_set():
        try:
            index_media_once()
        except Exception as error:
            print(f"Could not refresh local media index: {error}", flush=True)
        stop.wait(120)


def card_artwork(media, entries):
    cards = read_json(CARDS, {})
    if isinstance(cards, dict):
        for card in cards.values():
            if isinstance(card, dict) and card.get("media") == media and card.get("artwork") in entries:
                return card["artwork"]
    base = str(Path(media).with_suffix(""))
    return next((candidate for candidate in (f"{base}.card.png", f"{base}.card.jpg") if candidate in entries), "")


def queue_command(command):
    with _command_lock:
        pending = read_json(COMMAND)
        if isinstance(pending, dict) and pending.get("action") in ("stop", "finish"):
            return command.get("action") == pending["action"]
        if pending is not None and command.get("action") != "stop":
            return False
        write_json(COMMAND, command)
        return True


class CommandBusyError(RuntimeError):
    pass


class SharplayServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, stop):
        self.stop_event = stop
        super().__init__(address, SharplayHandler)


class SharplayHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, _format, *_args):
        pass

    def send_bytes(self, status, data, content_type, cache="no-store"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, status, value):
        self.send_bytes(status, json.dumps(value, separators=(",", ":")).encode(), "application/json")

    def read_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as error:
            raise ValueError("Invalid content length") from error
        if length > 1_000_000:
            raise ValueError("Body too large")
        try:
            value = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError as error:
            raise ValueError("Invalid JSON") from error
        if type(value) is not dict:
            raise ValueError("JSON object required")
        return value

    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            path = parsed.path
            if path == "/api/events":
                return self.events()
            if path == "/api/state":
                mode = read_json(MODE, {"mode": "watch"})
                return self.send_json(200, {
                    "mode": mode.get("mode", "watch") if isinstance(mode, dict) else "watch",
                    "accessBlocked": (read_json(ACCESS, {}) or {}).get("blocked") is True,
                    "scan": read_json(SCAN),
                    "playback": playback_state(),
                })
            if path == "/api/settings":
                value = read_json(SETTINGS, DEFAULT_SETTINGS)
                if not isinstance(value, dict):
                    value = DEFAULT_SETTINGS
                settings = {
                    "weekdayHours": value.get("weekdayHours") if value.get("weekdayHours") in DAILY_LIMIT_HOURS else DEFAULT_SETTINGS["weekdayHours"],
                    "weekendHours": value.get("weekendHours") if value.get("weekendHours") in DAILY_LIMIT_HOURS else DEFAULT_SETTINGS["weekendHours"],
                }
                return self.send_json(200, settings)
            if path == "/api/media":
                metadata = read_json(METADATA, {})
                return self.send_json(200, {"videos": [
                    {"path": media, "duration": (metadata.get(media) or {}).get("duration", 0)}
                    for media in scan_media()
                ]})
            if path == "/api/artwork":
                query = parse_qs(parsed.query)
                return self.artwork(query.get("media", [""])[0], query.get("kind", ["video"])[0])

            assets = {
                "/manifest.webmanifest": "manifest.webmanifest", "/sw.js": "sw.js",
                "/apple-touch-icon.png": "apple-touch-icon.png", "/icon-192.png": "icon-192.png",
                "/icon-512.png": "icon-512.png", "/favicon-32.png": "favicon-32.png",
            }
            if path in ("/", "/movie-box", "/movie-box/"):
                data = (APP_DIR / "index.html").read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'")
                self.end_headers()
                return self.wfile.write(data)
            if path in assets:
                file = APP_DIR / assets[path]
                content_type = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
                return self.send_bytes(200, file.read_bytes(), content_type, "public, max-age=3600")
            self.send_json(404, {"error": "Not found"})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except ValueError as error:
            self.send_json(400, {"error": str(error)})
        except Exception as error:
            print(f"HTTP GET failed: {error}", flush=True)
            self.send_json(500, {"error": str(error) or "Request failed"})

    def do_POST(self):
        self.change()

    def do_PUT(self):
        self.change()

    def change(self):
        try:
            path = urlparse(self.path).path
            value = self.read_body()
            if path == "/api/mode" and self.command == "POST":
                if value.get("mode") not in ("watch", "assign"):
                    raise ValueError("Invalid mode")
                write_json(MODE, {"mode": value["mode"], "updatedAt": time.time()})
                SCAN.unlink(missing_ok=True)
                append_event("mode", mode=value["mode"])
                notify_refresh()
                return self.send_json(200, {"ok": True})
            if path == "/api/access" and self.command == "POST":
                if type(value.get("blocked")) is not bool:
                    raise ValueError("Blocked must be true or false")
                write_json(ACCESS, {"blocked": value["blocked"], "updatedAt": time.time()})
                append_event("access", blocked=value["blocked"])
                notify_refresh()
                return self.send_json(200, {"blocked": value["blocked"]})
            if path == "/api/scan/clear" and self.command == "POST":

                SCAN.unlink(missing_ok=True)
                notify_refresh()
                return self.send_json(200, {"ok": True})
            if path == "/api/assign" and self.command == "POST":
                uid = value.get("uid")
                media = value.get("media")
                if not isinstance(uid, str) or not re.fullmatch(r"[0-9A-F]{8,20}", uid):
                    raise ValueError("Invalid card UID")
                entries = set(scan_media())
                if media not in entries:
                    raise ValueError("Select a listed video")
                media_path = Path(media)
                base = media_path.with_suffix("").as_posix()
                subtitle = next((candidate for candidate in (f"{base}.srt", f"{base}.eng.srt", f"{base}.eng.SDH.srt") if safe_media_path(candidate, False).is_file()), "")
                all_entries = scan_files()
                cards = read_json(CARDS, {})
                if not isinstance(cards, dict):
                    cards = {}
                cards[uid] = {
                    "title": media_path.stem,
                    "media": media,
                    "subtitle": subtitle,
                    "artwork": card_artwork(media, all_entries),
                }
                write_json(CARDS, cards)
                SCAN.unlink(missing_ok=True)
                append_event("assign", uid=uid, media=media)
                notify_refresh()
                return self.send_json(200, {"ok": True, "card": cards[uid]})
            if path == "/api/settings" and self.command in ("POST", "PUT"):
                weekday = value.get("weekdayHours")
                weekend = value.get("weekendHours")
                if type(weekday) not in (int, float) or type(weekend) not in (int, float) or weekday not in DAILY_LIMIT_HOURS or weekend not in DAILY_LIMIT_HOURS:
                    raise ValueError("Choose a 15-minute interval up to 3 hours")
                settings = {"weekdayHours": weekday, "weekendHours": weekend}
                write_json(SETTINGS, settings)
                append_event("settings", **settings)
                notify_refresh()
                return self.send_json(200, settings)
            if path == "/api/control" and self.command == "POST":
                action = value.get("action")
                playback_id = value.get("playbackId")
                if action in ("pause", "seek", "speed", "finish", "subtitles") and (not isinstance(playback_id, str) or not playback_id):
                    raise ValueError("Playback identity required")
                if action == "pause":
                    paused = value.get("paused")
                    if type(paused) is not bool:
                        raise ValueError("Paused must be true or false")
                    if not queue_command({"action": "pause", "playbackId": playback_id, "paused": paused}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "seek" and type(value.get("position")) in (int, float) and math.isfinite(value["position"]) and 0 <= value["position"] <= 86400:
                    if not queue_command({"action": "seek", "playbackId": playback_id, "position": value["position"]}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "seek" and type(value.get("seconds")) in (int, float) and math.isfinite(value["seconds"]) and abs(value["seconds"]) <= 60:
                    if not queue_command({"action": "seek", "playbackId": playback_id, "seconds": value["seconds"]}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "speed" and type(value.get("value")) in (int, float) and value["value"] in (0.75, 1, 1.25, 1.5, 2):
                    if not queue_command({"action": "speed", "playbackId": playback_id, "value": value["value"]}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "stop":
                    if not queue_command({"action": "stop"}):
                        raise CommandBusyError("Another terminal player command is still pending")
                elif action == "finish":
                    if not queue_command({"action": "finish", "playbackId": playback_id}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "skipCooldown":
                    playback = playback_state()
                    if playback["active"] or playback["cooldownRemainingSeconds"] <= 0:
                        raise ValueError("No session cooldown is active")
                    if not queue_command({"action": "skipCooldown"}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "play":
                    media = value.get("media")
                    if media not in set(scan_media()):
                        raise ValueError("Select a listed video")
                    if not queue_command({"action": "play", "media": media}):
                        raise CommandBusyError("Another player command is still pending")
                elif action == "subtitles" and type(value.get("enabled")) is bool:
                    if not queue_command({"action": "subtitles", "playbackId": playback_id, "visible": value["enabled"]}):
                        raise CommandBusyError("Another player command is still pending")
                else:
                    raise ValueError("Invalid control")
                append_event("control", action=action, value=value.get("value"), seconds=value.get("seconds"))
                return self.send_json(200, {"ok": True, **({"subtitles": value["enabled"]} if action == "subtitles" else {})})
            self.send_json(404, {"error": "Not found"})
        except ValueError as error:
            self.send_json(400, {"error": str(error)})
        except CommandBusyError as error:
            self.send_json(409, {"error": str(error)})
        except Exception as error:
            print(f"HTTP change failed: {error}", flush=True)
            self.send_json(500, {"error": str(error) or "Request failed"})

    def events(self):
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.wfile.write(b"retry: 2000\nevent: refresh\ndata: {}\n\n")
        self.wfile.flush()
        revision = _refresh_revision
        try:
            while not self.server.stop_event.is_set():
                with _refresh:
                    _refresh.wait(timeout=25)
                    changed = _refresh_revision != revision
                    revision = _refresh_revision
                self.wfile.write(b"event: refresh\ndata: {}\n\n" if changed else b": keepalive\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass

    def artwork(self, media, kind):
        media_file = safe_media_path(media)
        entries = scan_files()
        if media_file.suffix.lower() not in VIDEO_EXTENSIONS:
            raise ValueError("Unknown video")
        if kind == "card":
            artwork = card_artwork(media, entries)
            if artwork:
                file = safe_media_path(artwork)
                return self.send_bytes(200, file.read_bytes(), mimetypes.guess_type(file.name)[0] or "image/png", "public, max-age=86400")

        output = THUMBNAILS / f"{hashlib.sha1(media.encode()).hexdigest()}.jpg"
        with _thumbnail_lock:
            if not output.exists():
                temporary = output.with_name(f".{output.name}.{os.getpid()}.tmp.jpg")
                try:
                    result = subprocess.run(
                        [FFMPEG, "-hide_banner", "-loglevel", "error", "-ss", "00:00:45", "-i", str(media_file), "-frames:v", "1", "-vf", "scale=960:-2", "-q:v", "3", "-y", str(temporary)],
                        timeout=30, check=False,
                    )
                    if result.returncode != 0 or not temporary.is_file():
                        raise RuntimeError("Could not create thumbnail")
                    os.replace(temporary, output)
                finally:
                    temporary.unlink(missing_ok=True)
        self.send_bytes(200, output.read_bytes(), "image/jpeg", "public, max-age=86400")


class Backend:
    def __init__(self, servers, threads, stop):
        self.servers = servers
        self.threads = threads
        self.stop = stop

    @property
    def port(self):
        return self.servers[0].server_address[1]

    def close(self):
        self.stop.set()
        notify_refresh()
        for server in self.servers:
            server.shutdown()
            server.server_close()
        for thread in self.threads:
            thread.join(timeout=3)


def start_backend(host, port=8787, *, state=None, media_root=None, app_dir=None, index_media=True):
    global STATE, MEDIA_ROOT, APP_DIR, CARDS, MODE, SCAN, STATUS, SETTINGS, ACCESS, COMMAND, EVENTS, METADATA, THUMBNAILS
    if state is not None:
        STATE = Path(state)
        CARDS, MODE, SCAN = STATE / "cards.json", STATE / "mode.json", STATE / "last-scan.json"
        STATUS, SETTINGS, ACCESS, COMMAND = STATE / "status.json", STATE / "settings.json", STATE / "access.json", STATE / "command.json"
        EVENTS, METADATA, THUMBNAILS = STATE / "events.ndjson", STATE / "media-metadata.json", STATE / "thumbnails"
    if media_root is not None:
        MEDIA_ROOT = Path(media_root)
    if app_dir is not None:
        APP_DIR = Path(app_dir)
    STATE.mkdir(parents=True, exist_ok=True)
    THUMBNAILS.mkdir(exist_ok=True)

    stop = threading.Event()
    addresses = list(dict.fromkeys(["127.0.0.1", host]))
    servers = []
    threads = []
    selected_port = port
    for address in addresses:
        server = SharplayServer((address, selected_port), stop)
        if selected_port == 0:
            selected_port = server.server_address[1]
        servers.append(server)
        thread = threading.Thread(target=server.serve_forever, name=f"http-{address}", daemon=True)
        thread.start()
        threads.append(thread)
        print(f"Sharplay listening on http://{address}:{server.server_address[1]}", flush=True)
    if index_media:
        thread = threading.Thread(target=media_index_loop, args=(stop,), name="media-index", daemon=True)
        thread.start()
        threads.append(thread)
    return Backend(servers, threads, stop)
