# Sharplay cutover

Sharbox owns the media copy on its internal NVMe. The Pi and its USB SSD remain
unchanged as the rollback appliance.

## Prepare while the Pi is live

1. Authorize Sharbox's existing SSH public key for the Pi's `shardul` account.
   Keep strict host-key checking enabled.
2. Copy media, mutable state, and the webOS credential from the trusted Pi host:

   ```sh
   pi=<trusted-sharplay-host>
   sudo rsync -a --delete --no-owner --no-group --chown=root:sharplay \
     --chmod=D750,F640 --rsync-path='sudo -n rsync' \
     "shardul@$pi:/srv/sharplay/media/" /srv/sharplay/media/
   sudo rsync -a --delete --no-owner --no-group --chown=sharplay:sharplay \
     --chmod=D770,F660 --rsync-path='sudo -n rsync' \
     "shardul@$pi:/var/lib/nfc-tv/" /var/lib/nfc-tv/
   sudo rsync -a --no-owner --no-group --chown=root:root --chmod=F600 \
     --rsync-path='sudo -n rsync' \
     "shardul@$pi:/etc/nfc-tv/webos.json" \
     /var/lib/sharplay/secrets/webos.json
   ```

   Compare rsync's aggregate file counts and total sizes with aggregate source
   and destination measurements. Create the readiness marker only after they
   agree: `sudo install -m 0640 -o root -g sharplay /dev/null
   /srv/sharplay/media/.migration-complete`.
3. Build the pushed, disabled migration revision. Do not activate it. The stable
   DRM selector is already configured; the HDMI audio selector remains a
   cutover value.

## Quiesce and switch

1. Confirm playback is idle, then stop the Pi's Sharplay service and tunnel.
   Repeat all three rsync commands for the final delta and compare aggregate
   counts and sizes again. Shut down the Pi.
2. Move the HDMI cable and USB NFC reader from the powered-off Pi to Sharbox.
   Do not move the USB SSD.
3. On Sharbox, identify the HDMI output with `mpv --audio-device=help`. Set
   `services.sharplay.audioDevice` and `enable = true`, leaving `publish = false`.
   Commit, push, build that exact revision, and deploy it with `deploy-sharbox`.
4. Verify the credential and readiness conditions, read-only media sandbox,
   pcscd, exactly one connected HDMI output, NFC reader, local PWA/API/SSE,
   media index and durations, one Assign scan, one Watch playback,
   pause/seek/subtitles, resume/accounting, black idle output, and TV power-off.
5. Set `publish = true`, commit, push, and deploy. Move only the
   `play.sharxe.dev` route from the Pi tunnel to the existing Sharbox tunnel,
   then repeat the web checks through the public hostname.

Until step 1, the Pi remains authoritative. A final delta is mandatory even
after a successful pre-copy. Missing media readiness, credential, reader, DRM
card, audio output, or exactly-one-HDMI state must leave Sharplay stopped.

## Roll back

1. Route `play.sharxe.dev` back to the Pi tunnel and disable Sharplay on Sharbox.
2. Disconnect HDMI and the NFC reader from Sharbox. Reconnect them to the
   powered-off Pi, then boot it and restore its tunnel and service.
3. Verify the Pi's local and public UI, one NFC playback, and idle black output.
   Keep Sharbox's copies for diagnosis; do not merge post-cutover state back
   unless that activity must be preserved.
