# Reader deployment

The [Reader repository](https://github.com/shardulbee/reader) owns the app and
deployment workflow. [`default.nix`](default.nix) owns the host helper,
privileges, guest, and persistent state.
