{ lib, pkgs, ... }:

# Reader deployment and persistent-state wiring for Sharbox.
let
  deployReader = pkgs.writeShellScriptBin "deploy-reader" ''
    set -euo pipefail

    if [[ $# -ne 1 ]]; then
      echo "usage: deploy-reader <40-hex-reader-commit|rollback>" >&2
      exit 2
    fi

    profile=/nix/var/nix/profiles/per-container/reader/system
    exec 9>/run/lock/reader-deploy.lock
    ${pkgs.util-linux}/bin/flock 9

    if [[ $1 == rollback ]]; then
      ${pkgs.nix}/bin/nix profile rollback --profile "$profile"
    elif [[ $1 =~ ^[0-9a-f]{40}$ ]]; then
      # Actions streams git archive for this SHA; never use a host GitHub login.
      source_dir="$(${pkgs.coreutils}/bin/mktemp -d)"
      trap '${pkgs.coreutils}/bin/rm -rf "$source_dir"' EXIT
      ${pkgs.gnutar}/bin/tar --extract --file=- --directory="$source_dir" \
        --no-same-owner --no-same-permissions
      ${pkgs.nix}/bin/nix build \
        --profile "$profile" \
        --no-link \
        "path:$source_dir#nixosConfigurations.reader.config.system.build.toplevel"
    else
      echo "deploy-reader: expected rollback or a 40-character lowercase Git SHA" >&2
      exit 2
    fi

    ${pkgs.systemd}/bin/systemctl reload-or-restart systemd-nspawn@reader.service
  '';
in
{
  systemd.tmpfiles.rules = [
    "d /var/lib/machines/reader/usr 0755 root root -"
    "d /var/lib/reader 0750 root root -"
    "d /var/lib/reader/state 0700 1101 1101 -"
    "d /var/lib/reader/config 0750 root 1101 -"
  ];

  bouk.containers.reader = {
    nspawnConfig = {
      execConfig.PrivateUsers = false;
      networkConfig = {
        Private = true;
        VirtualEthernet = true;
      };
      filesConfig = {
        Bind = [ "/var/lib/reader/state:/srv/reader" ];
        BindReadOnly = lib.mkForce [
          "/nix/store:/nix/store"
          "/nix/var/nix/profiles/per-container/reader:/nix/var/nix/profiles"
          "/var/lib/reader/config:/etc/reader"
        ];
      };
    };
  };

  systemd.network.networks."40-reader" = {
    matchConfig.Name = "ve-reader";
    address = [ "10.50.1.1/24" ];
    networkConfig.DHCPServer = false;
  };

  # Federated deployments log in as this otherwise unprivileged account. Its
  # only sudo capability is the exact deployReader path below.
  users.users.reader-deploy = {
    isNormalUser = true;
    description = "Reader deployment account";
    createHome = false;
    home = "/var/empty";
    shell = pkgs.bashInteractive;
    extraGroups = [ ];
  };

  environment.systemPackages = [ deployReader ];

  security.sudo.extraRules = [
    {
      users = [ "reader-deploy" ];
      commands = [
        {
          command = "/run/current-system/sw/bin/deploy-reader";
          options = [ "NOPASSWD" ];
        }
      ];
    }
  ];
}
