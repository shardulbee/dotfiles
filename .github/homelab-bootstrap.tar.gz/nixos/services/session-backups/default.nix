{ pkgs, lib, ... }:
let
  backups = pkgs.callPackage ../../../tools/session-backups { };
  sources = [
    "amp"
    "pi"
    "hermes"
  ];
in
{
  environment.systemPackages = [ backups ];
  systemd.tmpfiles.rules = [ "d /var/lib/agent-sessions 0700 shardul users -" ];
  systemd.services = lib.genAttrs (map (source: "agent-session-export-${source}") sources) (name: {
    description = "Ingest ${lib.removePrefix "agent-session-export-" name} sessions into Knowledge Search";
    after = [ "network-online.target" ];
    wants = [ "network-online.target" ];
    environment.HOME = "/home/shardul";
    serviceConfig = {
      Type = "oneshot";
      User = "shardul";
      UMask = "0077";
      ExecStart = "${backups}/bin/agent-session-export ${lib.removePrefix "agent-session-export-" name} --export-state /var/lib/agent-sessions";
      TimeoutStartSec = "5min";
      Nice = 10;
      NoNewPrivileges = true;
      PrivateTmp = true;
      # Amp's bundled native modules and user cache require a writable home.
      ProtectSystem = if name == "agent-session-export-amp" then "full" else "strict";
      ProtectHome = if name == "agent-session-export-amp" then false else "read-only";
      ReadOnlyPaths = [ "/var/lib/obsidian/vault" ];
      ReadWritePaths = [
        "/var/lib/agent-sessions"
        "/var/lib/knowledge"
      ];
    };
  });
  systemd.timers = lib.genAttrs (map (source: "agent-session-export-${source}") sources) (name: {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnBootSec = "2min";
      OnUnitInactiveSec = if name == "agent-session-export-amp" then "1min" else "5min";
      AccuracySec = "1s";
    };
  });
}
