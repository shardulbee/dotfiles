{ inputs, pkgs, ... }:

# Executor deployment and persistent-state wiring for Sharbox.
let
  executor = import ./package.nix { inherit pkgs; };

  fastmailMcp = inputs.self.packages.${pkgs.system}.fastmail-mcp;

  caddyfile = pkgs.writeText "executor-local.Caddyfile" ''
    {
      admin off
      auto_https off
    }

    http://mcp.shardul.ca {
      bind unix//run/executor-origin/executor.sock|0220

      handle {
        reverse_proxy 127.0.0.1:4789 {
          header_up -CF-Access-Client-Id
          header_up -CF-Access-Client-Secret
          header_up -Cf-Access-Jwt-Assertion
          header_up Authorization "Bearer {$EXECUTOR_MCP_TOKEN}"
        }
      }
    }
  '';

  backupExecutor = pkgs.writeShellScript "backup-executor" ''
    set -eu
    umask 077

    root=/var/backups/executor
    stamp=$(${pkgs.coreutils}/bin/date -u +%Y%m%dT%H%M%SZ)
    dest="$root/$stamp"
    ok=0

    mkdir -p "$dest"
    cleanup() {
      [ "$ok" -eq 1 ] || rm -rf "$dest"
    }
    trap cleanup EXIT HUP INT TERM

    ${pkgs.sqlite}/bin/sqlite3 /home/executor/.executor/data.db ".timeout 10000" ".backup '$dest/data.db'"
    ${pkgs.sqlite}/bin/sqlite3 "$dest/data.db" 'PRAGMA quick_check;' | ${pkgs.gnugrep}/bin/grep -Fx ok >/dev/null

    set -- .executor
    [ ! -d /home/executor/.config ] || set -- "$@" .config
    [ ! -d /home/executor/vault ] || set -- "$@" vault
    ${pkgs.gnutar}/bin/tar -C /home/executor -I ${pkgs.gzip}/bin/gzip -cf "$dest/executor-files.tgz" \
      --exclude='.executor/data.db' \
      --exclude='.executor/data.db-wal' \
      --exclude='.executor/data.db-shm' \
      --exclude='.executor/logs' \
      --exclude='.executor/cache' \
      "$@"

    (cd "$dest" && ${pkgs.coreutils}/bin/sha256sum data.db executor-files.tgz >SHA256SUMS)
    ok=1
    trap - EXIT HUP INT TERM
    ${pkgs.findutils}/bin/find "$root" -mindepth 1 -maxdepth 1 -type d -mtime +14 -exec rm -rf {} +
  '';
in
{
  systemd.tmpfiles.rules = [
    "d /var/lib/executor 0750 root root -"
    "d /var/lib/executor/home 0700 1106 1106 -"
    "d /var/lib/executor/secrets 0700 root root -"
    "d /var/lib/executor/backups 0700 root root -"
  ];

  containers.executor = {
    autoStart = true;
    privateNetwork = true;
    hostAddress = "10.50.4.1";
    localAddress = "10.50.4.2";
    bindMounts = {
      "/home/executor" = {
        hostPath = "/var/lib/executor/home";
        isReadOnly = false;
      };
      "/var/lib/executor-secrets" = {
        hostPath = "/var/lib/executor/secrets";
        isReadOnly = true;
      };
      "/var/backups/executor" = {
        hostPath = "/var/lib/executor/backups";
        isReadOnly = false;
      };
      "/run/executor-origin" = {
        hostPath = "/run/executor-origin";
        isReadOnly = false;
      };
    };
    config = { pkgs, ... }: {
      networking = {
        hostName = "executor-local";
        useHostResolvConf = false;
        nameservers = [ "1.1.1.1" ];
      };

      users.groups = {
        executor.gid = 1106;
        executor-origin.gid = 1105;
      };
      users.users = {
        executor = {
          isSystemUser = true;
          uid = 1106;
          group = "executor";
          home = "/home/executor";
        };
        caddy = {
          isSystemUser = true;
          uid = 1107;
          group = "executor-origin";
        };
      };

      systemd.services = {
        executor = {
          description = "Executor MCP gateway";
          wantedBy = [ "multi-user.target" ];
          after = [ "network-online.target" ];
          wants = [ "network-online.target" ];
          unitConfig.ConditionPathExists = "/home/executor/.executor/data.db";
          environment = {
            HOME = "/home/executor";
            XDG_CONFIG_HOME = "/home/executor/.config";
            EXECUTOR_DATA_DIR = "/home/executor/.executor";
            EXECUTOR_SCOPE_DIR = "/Users/shardul/.executor";
            EXECUTOR_SUPERVISED = "1";
            EXECUTOR_SERVICE_VERSION = "1.6.8";
            EXECUTOR_WEB_BASE_URL = "https://mcp.shardul.ca";
          };
          serviceConfig = {
            User = "executor";
            Group = "executor";
            WorkingDirectory = "/home/executor/.executor";
            ExecStart = "${executor}/bin/executor daemon run --foreground --port 4789 --hostname 127.0.0.1";
            Restart = "on-failure";
            RestartSec = "3s";
            UMask = "0077";
            NoNewPrivileges = true;
            PrivateTmp = true;
            ProtectSystem = "strict";
            ReadWritePaths = [ "/home/executor" ];
            ProtectKernelTunables = true;
            ProtectKernelModules = true;
            ProtectKernelLogs = true;
            ProtectControlGroups = true;
            RestrictSUIDSGID = true;
            RestrictRealtime = true;
            LockPersonality = true;
            RestrictAddressFamilies = [
              "AF_UNIX"
              "AF_INET"
              "AF_INET6"
            ];
          };
        };

        fastmail-mcp = {
          description = "Fastmail Streamable HTTP MCP service";
          wantedBy = [ "multi-user.target" ];
          after = [ "network-online.target" ];
          wants = [ "network-online.target" ];
          environment.MCP_ADDR = "127.0.0.1:8781";
          serviceConfig = {
            DynamicUser = true;
            ExecStart = "${fastmailMcp}/bin/fastmail-mcp";
            Restart = "on-failure";
            RestartSec = "2s";
            UMask = "0077";
            NoNewPrivileges = true;
            PrivateDevices = true;
            PrivateTmp = true;
            ProtectSystem = "strict";
            ProtectHome = true;
            InaccessiblePaths = [ "/home/executor" ];
            ProtectKernelTunables = true;
            ProtectKernelModules = true;
            ProtectKernelLogs = true;
            ProtectControlGroups = true;
            ProtectClock = true;
            ProtectHostname = true;
            RestrictSUIDSGID = true;
            LockPersonality = true;
            MemoryDenyWriteExecute = true;
            RestrictAddressFamilies = [
              "AF_INET"
              "AF_INET6"
            ];
            TasksMax = 32;
            # A maximum-size MCP attachment upload peaks near 384 MiB.
            MemoryMax = "512M";
            MemorySwapMax = 0;
            CPUQuota = "25%";
          };
        };

        caddy = {
          description = "Executor authenticated origin";
          wantedBy = [ "multi-user.target" ];
          after = [ "executor.service" ];
          requires = [ "executor.service" ];
          unitConfig.ConditionPathExists = "/var/lib/executor-secrets/executor.env";
          serviceConfig = {
            User = "caddy";
            Group = "executor-origin";
            EnvironmentFile = "/var/lib/executor-secrets/executor.env";
            Environment = [
              "HOME=/run/caddy"
              "XDG_CONFIG_HOME=/run/caddy/config"
              "XDG_DATA_HOME=/run/caddy/data"
            ];
            ExecStartPre = "${pkgs.caddy}/bin/caddy validate --config ${caddyfile} --adapter caddyfile";
            ExecStart = "${pkgs.caddy}/bin/caddy run --config ${caddyfile} --adapter caddyfile";
            Restart = "on-failure";
            RestartSec = "5s";
            RuntimeDirectory = "caddy";
            RuntimeDirectoryMode = "0750";
            UMask = "0027";
            CapabilityBoundingSet = "";
            NoNewPrivileges = true;
            PrivateTmp = true;
            PrivateDevices = true;
            ProtectSystem = "strict";
            ProtectHome = true;
            ProtectKernelTunables = true;
            ProtectKernelModules = true;
            ProtectKernelLogs = true;
            ProtectControlGroups = true;
            ProtectClock = true;
            ProtectHostname = true;
            RestrictSUIDSGID = true;
            RestrictRealtime = true;
            LockPersonality = true;
            RestrictAddressFamilies = [
              "AF_UNIX"
              "AF_INET"
              "AF_INET6"
            ];
          };
        };

        executor-backup = {
          description = "Back up Executor state";
          after = [ "executor.service" ];
          unitConfig.ConditionPathExists = "/home/executor/.executor/data.db";
          serviceConfig = {
            Type = "oneshot";
            ExecStart = backupExecutor;
            UMask = "0077";
            PrivateTmp = true;
            ProtectSystem = "strict";
            ReadWritePaths = [ "/var/backups/executor" ];
            ProtectHome = "read-only";
            ProtectKernelTunables = true;
            ProtectKernelModules = true;
            ProtectControlGroups = true;
          };
        };
      };

      systemd.timers = {
        executor-backup = {
          description = "Daily Executor backup";
          wantedBy = [ "timers.target" ];
          timerConfig = {
            OnCalendar = "daily";
            RandomizedDelaySec = "1h";
            Persistent = true;
          };
        };

      };

      programs.nix-ld = {
        enable = true;
        libraries = [ pkgs.stdenv.cc.cc.lib ];
      };

      system.stateVersion = "26.05";
    };
  };
}
