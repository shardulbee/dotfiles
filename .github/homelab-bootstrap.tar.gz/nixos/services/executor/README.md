# Executor

Executor runs in an isolated NixOS container on Sharbox. Nix and this repository
are the configuration source of truth; credentials, application state, and
backups remain outside Git and the Nix store.

## Architecture

```text
MCP clients                         Browser
     |                                 |
     | Access service identity         | email + one-time PIN
     v                                 v
             mcp.shardul.ca
                    |
            Cloudflare Access
                    |
       Sharbox Cloudflare Tunnel
                    |
          private Unix-domain socket
                    |
        Caddy proxy + bearer injection
                    |
           Executor 127.0.0.1:4789
                    |
           Fastmail 127.0.0.1:8781
```

`mcp.shardul.ca` is one Cloudflare Access application. Browsers authenticate as
`shardul@baral.ca` through email and one-time PIN. MCP clients use expiring
Cloudflare Access service identities supplied through the
`CF-Access-Client-Id` and `CF-Access-Client-Secret` headers. Access authenticates
both forms before Caddy strips their credentials and proxies the request.

The dashboard is `https://mcp.shardul.ca/` and the canonical connector URL is
`https://mcp.shardul.ca/mcp`. Keeping both on one origin matches Executor's URL
generation and avoids browser-handoff redirects.

Cloudflare is the only public ingress. Caddy has no TCP listener: the host
cloudflared process connects to a group-restricted Unix socket under
`/run/executor-origin`. Caddy strips client credentials before injecting
Executor's internal bearer. Raw ports 4789 and 8781 remain loopback-only.

## Deployment and state

[`default.nix`](default.nix) defines the container at `10.50.4.2`, including
Executor 1.6.8, the
[`Fastmail MCP`](../../../packages/fastmail-mcp/) integration,
Caddy, and daily backups. The container has no SSH server, cloudflared process,
or inbound network listener.

[`package.nix`](package.nix) installs the hash-pinned stable Linux x64 npm
binary. [Upstream 1.6.8](https://github.com/UsefulSoftwareCo/executor/releases/tag/v1.6.8)
includes both OAuth Basic authentication fixes. For X OAuth apps, keep
**HTTP Basic (raw)** for token endpoint authentication. Standard Basic
form-encodes punctuation in credentials before Base64 encoding; X rejects
that format for the configured app.

The host's locally configured Cloudflare Tunnel is `sharbox`
(`c175485d-bcae-43e4-b63d-b18459a864f4`). Its ingress is declarative in
[`sharbox.nix`](../../sharbox.nix); the Access application and policies are
managed through Cloudflare. Persistent host paths are:

| Purpose | Sharbox path |
| --- | --- |
| Executor home and state | `/var/lib/executor/home` |
| Executor proxy bearer | `/var/lib/executor/secrets/executor.env` |
| Sharbox tunnel credential | `/var/lib/cloudflared-sharbox/credentials.json` |
| Verified daily backups | `/var/lib/executor/backups` |

The tunnel credential is root-only and enters cloudflared through systemd's
private credentials directory. The general machine credential's current source
is the `executor` entry in `~/.pi/agent/auth.json` on TurboGadget; copy it into
1Password before configuring other clients. Grok uses its existing dedicated
credential. Neither credential is retained on Sharbox or in this repository.

The active DNS record is a proxied CNAME for `mcp.shardul.ca` to the tunnel.

## Operations

```sh
ssh root@sharbox

systemctl status container@executor
systemctl status cloudflared
nixos-container run executor -- systemctl status \
  executor fastmail-mcp caddy executor-backup.timer
nixos-container run executor -- journalctl -u executor -u caddy \
  -n 100 --no-pager
nixos-container run executor -- ss -lnt
ls -l /run/executor-origin
```

Expected ingress and listeners:

- `/run/executor-origin/executor.sock` — private Executor origin for host cloudflared
- `127.0.0.1:4789` — Executor
- `127.0.0.1:8781` — Fastmail MCP
- no externally reachable TCP listener in the container

## Backups and restore

`executor-backup.timer` runs daily with up to one hour of randomized delay and
keeps 14 days. Each root-only snapshot contains:

- `data.db` — SQLite online backup checked with `PRAGMA quick_check`;
- `executor-files.tgz` — non-database Executor files and optional configuration
  directories;
- `SHA256SUMS` — snapshot integrity hashes.

Nix restores service and proxy configuration rather than duplicating it in
state backups.

Run and verify a backup manually:

```sh
nixos-container run executor -- systemctl start executor-backup.service
latest=$(find /var/lib/executor/backups -mindepth 1 -maxdepth 1 \
  -type d | sort | tail -1)
(cd "$latest" && sha256sum -c SHA256SUMS)
```

Restore only during an outage or planned rollback:

```sh
nixos-container run executor -- systemctl stop \
  caddy executor fastmail-mcp
cp /var/lib/executor/backups/<timestamp>/data.db \
  /var/lib/executor/home/.executor/data.db
tar -C /var/lib/executor/home -xzf \
  /var/lib/executor/backups/<timestamp>/executor-files.tgz
rm -f /var/lib/executor/home/.executor/data.db-wal \
  /var/lib/executor/home/.executor/data.db-shm
nixos-container run executor -- chown -R executor:executor \
  /home/executor/.executor
nixos-container run executor -- systemctl start \
  executor fastmail-mcp caddy
```

After restoration, test both MCP execution and Fastmail, then create and verify
a fresh backup.
