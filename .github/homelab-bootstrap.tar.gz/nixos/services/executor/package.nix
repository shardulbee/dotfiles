{ pkgs }:
pkgs.stdenv.mkDerivation rec {
  pname = "executor";
  version = "1.6.8";
  src = pkgs.fetchurl {
    url = "https://registry.npmjs.org/executor/-/executor-${version}-linux-x64.tgz";
    hash = "sha256-RycWlPMFb11fHvzj6l1G7W1hWp98v4v4vXbammhk9uc=";
  };
  nativeBuildInputs = [ pkgs.autoPatchelfHook ];
  buildInputs = [ pkgs.stdenv.cc.cc.lib ];
  dontStrip = true;
  installPhase = ''
    mkdir -p "$out"
    cp -R . "$out/"
  '';
}
