{ lib, pkgs, ... }:

let
  slots = lib.range 1 4;
  firewall = pkgs.writeText "choux-network.nft" (
    "destroy table inet choux\n" + builtins.readFile ./network.nft
  );
in
{
  users.users = builtins.listToAttrs (
    map (slot: {
      name = "choux${toString slot}";
      value = {
        isSystemUser = true;
        uid = 20000 + slot;
        group = "choux${toString slot}";
      };
    }) slots
  );
  users.groups = builtins.listToAttrs (
    map (slot: {
      name = "choux${toString slot}";
      value.gid = 20000 + slot;
    }) slots
  );

  # Keep the host firewall and Tailscale rules intact. Install guest drops before
  # enabling TAPs or forwarding; retain the drops when stopping this service.
  systemd.services.choux-network = {
    wantedBy = [ "multi-user.target" ];
    after = [ "network-online.target" ];
    wants = [ "network-online.target" ];
    before = [ "choux-hotbox.service" ];
    path = [
      pkgs.iproute2
      pkgs.nftables
      pkgs.procps
    ];
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = true;
    };
    script = ''
      nft -f ${firewall}
      ${lib.concatMapStringsSep "\n" (slot: ''
        ip link show choux${toString slot} >/dev/null 2>&1 || \
          ip tuntap add choux${toString slot} mode tap user ${toString (20000 + slot)}
        ip addr replace 172.30.${toString slot}.1/30 dev choux${toString slot}
        ip link set choux${toString slot} up
      '') slots}
      sysctl -w net.ipv4.ip_forward=1
    '';
    preStop = lib.concatMapStringsSep "\n" (slot: ''
      ip link set choux${toString slot} down
    '') slots;
  };

  # Artifacts are installed separately under root ownership. This service needs
  # the reviewed Kitchen-only tailnet grant before it is enabled.
  systemd.services.choux-hotbox = {
    after = [
      "choux-network.service"
      "tailscaled.service"
    ];
    requires = [
      "choux-network.service"
      "tailscaled.service"
    ];
    bindsTo = [ "choux-network.service" ];
    path = [
      pkgs.coreutils
      pkgs.systemd
    ];
    serviceConfig = {
      ExecStart = lib.concatStringsSep " " [
        "/opt/choux-hotbox/choux-hotbox"
        "--listen 100.70.20.26:32345"
        "--uid 20000 --max-puffs 4"
        "--kernel /var/lib/choux-images/vmlinux"
        "--rootfs /var/lib/choux-images/rootfs.ext4"
        "--firecracker /opt/choux-hotbox/firecracker"
        "--jailer /opt/choux-hotbox/jailer"
      ];
      Restart = "on-failure";
      RestartSec = 3;
      UMask = "0077";
    };
  };
}
