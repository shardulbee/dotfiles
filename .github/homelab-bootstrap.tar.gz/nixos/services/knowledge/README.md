# Vault sync and search

Canonical note vault: `/var/lib/obsidian/vault`, owned by `shardul`.
Session exporters write only the SQLite archive and raw storage.
Credentials and sync cursor stay outside the vault.
The [SQLite archive](../../../tools/session-backups/README.md#sqlite-archive)
stores durable sessions and indexed note snapshots in `/var/lib/knowledge`.

`obsidian-sync.timer` runs a bidirectional pass 15 seconds after the previous
pass completes. It shares `state/vault.lock` with note CRUD. Busy writes return a
retryable error instead of racing local sync. Revision checks cover current local
content; concurrent remote edits still use Obsidian's merge conflict strategy.
Only one host owns sync. `/var/lib/obsidian/ready` gates startup after provisioning.

Executor reaches `http://10.50.4.1:8784/mcp` for Knowledge Search search/get,
`:8783/mcp` for notes, and `:8785/mcp` for tools sourced from
`agent-skills/`. These unauthenticated internal listeners bind only to the
Executor-facing host address; the host firewall admits only `ve-executor`.
External clients authenticate through the existing Executor gateway.
Configure the skills listener in Executor as `agent-skills` at
`http://10.50.4.1:8785/mcp`.

Hermes uses the [Executor skill](hermes-obsidian.md) at
`~/.hermes/skills/note-taking/managing-obsidian/SKILL.md`. If gateway tools are
unavailable, note writes are unavailable. Sharbox owns vault storage and sync.

Note create is idempotent by stable path and identical content. Create/edit
require explicit content, including an explicit empty string to clear a note.
Edit/delete require the SHA256 revision from read.
Only visible Markdown paths are writable. Symlinks, hidden/config paths and
`Agent Sessions` are rejected. Do not add another uncoordinated local vault writer.

`knowledge-notes.timer` scans notes every five minutes. Session exporters upsert
the archive incrementally. Notes `freshness` reports successful sync and exporter
state times; Knowledge Search `get` includes `provenance.indexedAt`. Read the
[tool contract](../../../packages/knowledge-mcp/README.md) for offsets and revisions.

The sync client stores its credentials and cursor under
`/var/lib/obsidian/config/obsidian-headless`. Never copy its files into Git, the
Nix store, or an orb.
