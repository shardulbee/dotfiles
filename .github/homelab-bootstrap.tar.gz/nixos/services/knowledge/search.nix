{
  inputs,
  pkgs,
  lib,
  ...
}:
{
  networking.firewall.interfaces.ve-executor.allowedTCPPorts = [ 8784 ];
  networking.firewall.extraCommands = lib.mkAfter ''
    ${pkgs.iptables}/bin/iptables -I nixos-fw 1 -d 10.50.4.1 -p tcp --dport 8784 ! -i ve-executor -j DROP
  '';
  systemd.services.knowledge-mcp = {
    description = "Executor-only read-only knowledge archive search";
    wantedBy = [ "multi-user.target" ];
    after = [ "container@executor.service" ];
    requires = [ "container@executor.service" ];
    unitConfig.ConditionPathExists = "/var/lib/knowledge/archive.sqlite3";
    environment = {
      KNOWLEDGE_DB = "/var/lib/knowledge/archive.sqlite3";
      LISTEN_ADDR = "10.50.4.1:8784";
    };
    serviceConfig = {
      User = "shardul";
      UMask = "0077";
      ExecStart = "${inputs.self.packages.${pkgs.system}.knowledge-mcp}/bin/knowledge-mcp";
      Restart = "on-failure";
      NoNewPrivileges = true;
      PrivateTmp = true;
      ProtectSystem = "strict";
      ProtectHome = true;
      # A mode=ro WAL reader may create missing WAL/SHM sidecars.
      ReadWritePaths = [ "/var/lib/knowledge" ];
      ReadOnlyPaths = [
        "/var/lib/knowledge/archive.sqlite3"
        "/var/lib/knowledge/backups"
      ];
      MemoryMax = "2G";
      CPUQuota = "100%";
    };
  };
}
