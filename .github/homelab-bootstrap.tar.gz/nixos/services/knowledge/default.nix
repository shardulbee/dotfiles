{ inputs, pkgs, ... }:
let
  packages = inputs.self.packages.${pkgs.system};
  vault = "/var/lib/obsidian/vault";
  state = "/var/lib/obsidian/state";
in
{
  imports = [ ./search.nix ];
  systemd.tmpfiles.rules = [
    "d /var/lib/obsidian 0700 shardul users -"
    "d ${vault} 0700 shardul users -"
    "d ${state} 0700 shardul users -"
    "d /var/lib/obsidian/config 0700 shardul users -"
    "d /var/lib/knowledge 0700 shardul users -"
    "d /var/lib/knowledge/backups 0700 shardul users -"
  ];
  systemd.services.knowledge-notes = {
    description = "Snapshot Obsidian notes and Markdown conversation exports";
    unitConfig.ConditionPathExists = "/var/lib/obsidian/ready";
    serviceConfig = {
      Type = "oneshot";
      User = "shardul";
      UMask = "0077";
      ExecStart = "${packages.session-backups}/bin/knowledge-import notes";
      TimeoutStartSec = "5min";
      Nice = 10;
      NoNewPrivileges = true;
      PrivateTmp = true;
      ProtectHome = true;
      ProtectSystem = "strict";
      ReadWritePaths = [ "/var/lib/knowledge" ];
    };
  };
  systemd.timers.knowledge-notes = {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnBootSec = "2min";
      OnUnitInactiveSec = "5min";
      AccuracySec = "1s";
    };
  };
  systemd.services.knowledge-backup = {
    description = "Verified single-file SQLite knowledge archive backup";
    unitConfig.ConditionPathExists = "/var/lib/knowledge/archive.sqlite3";
    serviceConfig = {
      Type = "oneshot";
      User = "shardul";
      UMask = "0077";
      ExecStart = "${packages.session-backups}/bin/knowledge-import backup";
      TimeoutStartSec = "30min";
      Nice = 15;
      NoNewPrivileges = true;
      PrivateTmp = true;
      ProtectHome = true;
      ProtectSystem = "strict";
      ReadWritePaths = [ "/var/lib/knowledge" ];
    };
  };
  systemd.timers.knowledge-backup = {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnCalendar = "daily";
      Persistent = true;
      RandomizedDelaySec = "1h";
    };
  };
  # Only Executor's private host-facing interface can reach these listeners.
  networking.firewall.interfaces.ve-executor.allowedTCPPorts = [
    8783
    8785
  ];
  # br-guests is trusted by the host. Reject other ingress before that blanket
  # accept, including direct VM access and already-established connections.
  networking.firewall.extraCommands = ''
    ${pkgs.iptables}/bin/iptables -I nixos-fw 1 -d 10.50.4.1 -p tcp --dport 8783 ! -i ve-executor -j DROP
    ${pkgs.iptables}/bin/iptables -I nixos-fw 1 -d 10.50.4.1 -p tcp --dport 8785 ! -i ve-executor -j DROP
  '';
  systemd.services.obsidian-sync = {
    description = "Host-owned bidirectional Obsidian sync";
    after = [ "network-online.target" ];
    wants = [ "network-online.target" ];
    unitConfig.ConditionPathExists = "/var/lib/obsidian/ready";
    environment = {
      HOME = "/var/lib/obsidian";
      XDG_CONFIG_HOME = "/var/lib/obsidian/config";
    };
    postStart = "date -u +%FT%TZ > ${state}/synced-at";
    serviceConfig = {
      Type = "oneshot";
      User = "shardul";
      UMask = "0077";
      WorkingDirectory = vault;
      ExecStart = "${pkgs.util-linux}/bin/flock ${state}/vault.lock ${packages.obsidian-headless}/bin/ob sync --path ${vault}";
      TimeoutStartSec = "10min";
      NoNewPrivileges = true;
      PrivateTmp = true;
      ProtectSystem = "strict";
      ProtectHome = true;
      ReadWritePaths = [ "/var/lib/obsidian" ];
      # Sync logs contain note paths. Keep them in the private client log only.
      StandardOutput = "null";
      StandardError = "append:${state}/sync-errors.log";
    };
  };
  systemd.timers.obsidian-sync = {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnBootSec = "30s";
      OnUnitInactiveSec = "15s";
      AccuracySec = "1s";
    };
  };
  systemd.services.vault-mcp = {
    description = "Executor-only revision-checked vault notes";
    wantedBy = [ "multi-user.target" ];
    after = [ "container@executor.service" ];
    unitConfig.ConditionPathExists = "/var/lib/obsidian/ready";
    environment = {
      VAULT_ROOT = vault;
      VAULT_STATE = state;
      LISTEN_ADDR = "10.50.4.1:8783";
    };
    serviceConfig = {
      User = "shardul";
      UMask = "0077";
      ExecStart = "${packages.vault-mcp}/bin/vault-mcp";
      Restart = "on-failure";
      NoNewPrivileges = true;
      PrivateTmp = true;
      ProtectSystem = "strict";
      ProtectHome = true;
      ReadWritePaths = [
        vault
        state
      ];
    };
  };
  systemd.services.agent-skills-mcp = {
    description = "Executor-only agent skills";
    wantedBy = [ "multi-user.target" ];
    after = [ "container@executor.service" ];
    unitConfig.ConditionPathExists = "${vault}/agent-skills";
    environment = {
      SKILLS_ROOT = "${vault}/agent-skills";
      SKILLS_STATE = state;
      LISTEN_ADDR = "10.50.4.1:8785";
    };
    serviceConfig = {
      User = "shardul";
      UMask = "0077";
      ExecStart = "${packages.agent-skills-mcp}/bin/agent-skills-mcp";
      Restart = "on-failure";
      NoNewPrivileges = true;
      PrivateTmp = true;
      ProtectSystem = "strict";
      ProtectHome = true;
      ReadWritePaths = [
        "${vault}/agent-skills"
        state
      ];
    };
  };
}
