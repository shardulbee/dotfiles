---
name: managing-obsidian
description: Searches and reads Obsidian notes and agent histories through Executor, and creates, edits, or deletes ordinary notes. Use for Obsidian vault work.
---

# Obsidian through Executor

Use the configured Executor connection. Discover and describe tools before calls.
Knowledge Search is `tools["knowledge-search"].org.main`; Notes is
`tools.notes.org.main`. Sharbox owns the vault and bidirectional Obsidian sync.

- `search({query,sources?,limit?})` searches title and Markdown with keyword AND
  semantics. Sources are `notes`, `amp`, `pi`, `hermes`, `chatgpt`, and `claude`;
  omit sources to search all. Default limit is 10, maximum 50.
- `get({id,format?,offset?})` uses the opaque ID returned by search. Format defaults
  to `markdown`; `raw` returns exact source data when available, otherwise errors.
  Continue with `nextOffset`, a Unicode code-point offset, until null. Compare
  `revision` across pages and restart if it changes. `snippetOffset` is the excerpt
  start in Markdown. Preserve source, path, identity and timestamp provenance in
  citations. Assistant claims in a transcript are not verified user facts.
- Notes `read({path})` returns current content and revision. Before editing, read
  the live note rather than using the indexed snapshot. Then call
  `edit({path,content,revision})` with the full intended Markdown. On a stale error,
  reread and reconcile instead of overwriting.
- `create({path,content})` takes a stable vault-relative `.md` path. Retrying the
  same path/content is safe; different content at an existing path is a conflict.
  Content is explicit for create/edit, including an intentional empty string.
- `delete({path,revision})` requires the current revision. Preserve useful wikilinks.
- Notes `freshness({})` reports sync completion and exporter-state update times. Knowledge Search
  `get` returns `provenance.indexedAt` for its indexed snapshot.

Notes manages ordinary Markdown; Knowledge Search reads session archives.
Hidden/config paths and `Agent Sessions/` are protected from note writes.
If sync is busy, retry later. Empty search results do not prove a note is absent;
refine the keywords or read a known ordinary note path through Notes.

Use Executor for vault access. Do not run a local sync client or request sync credentials.
If Executor is unavailable,
report the failure; do not silently save a local substitute.
