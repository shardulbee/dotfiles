{
  stdenv,
  fetchFromGitHub,
  pnpm_10,
  nodejs,
  python3,
  node-gyp,
  makeWrapper,
}:
stdenv.mkDerivation (final: {
  pname = "obsidian-headless";
  version = "0.0.14";
  src = fetchFromGitHub {
    owner = "obsidianmd";
    repo = "obsidian-headless";
    rev = "0d0ec4364bfde6c715c539cf3555ff8272bb7a58";
    hash = "sha256-ue2M9maFyvabGH9qTDOpAJS4OPwCikpAMYm/M/XRGKo=";
  };
  pnpmDeps = pnpm_10.fetchDeps {
    inherit (final) pname version src;
    fetcherVersion = 3;
    hash = "sha256-2jGvGgmeeFbeuPIR1Td1TaPdFt/10ZJ/k/ZY9KWQksg=";
  };
  nativeBuildInputs = [
    nodejs
    pnpm_10.configHook
    python3
    node-gyp
    makeWrapper
  ];
  buildPhase = ''
    export HOME="$TMPDIR"
    (cd node_modules/better-sqlite3 && node-gyp rebuild --release --nodedir=${nodejs})
  '';
  installPhase = ''
    mkdir -p $out/lib/obsidian-headless $out/bin
    cp -r cli.js btime package.json node_modules $out/lib/obsidian-headless/
    makeWrapper ${nodejs}/bin/node $out/bin/ob --add-flags "$out/lib/obsidian-headless/cli.js"
  '';
})
