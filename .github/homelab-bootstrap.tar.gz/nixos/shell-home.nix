{ inputs, pkgs, ... }:

{
  programs.fish.enable = true;
  users.users.shardul.shell = pkgs.fish;

  home-manager = {
    useGlobalPkgs = true;
    useUserPackages = true;
    backupFileExtension = "hm-backup";

    users.shardul = {
      imports = [ (import ../dotfiles/shell.nix { inherit (inputs) monstar; }) ];
      home = {
        username = "shardul";
        homeDirectory = "/home/shardul";
        stateVersion = "26.05";
      };

      programs.home-manager.enable = true;
    };
  };
}
