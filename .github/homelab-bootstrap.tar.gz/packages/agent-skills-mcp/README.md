# Agent Skills MCP

This server exposes each directory in `SKILLS_ROOT` as an MCP tool.
The directory name becomes the tool name. The `description` field in
`SKILL.md` becomes the tool description.

Calling a tool returns its `SKILL.md` and a list of files in that directory.
Pass `file` to read one of those files. The response includes a SHA256 revision
of the full skill directory. Skill files must be UTF-8 text.

`write` creates a skill or changes one file when the directory revision matches.
It accepts up to 2 MB. `delete` removes a skill when its revision matches. Both
tools share the Obsidian sync lock. Use them only when the user explicitly asks.

Set `SKILLS_ROOT`, `SKILLS_STATE`, and `LISTEN_ADDR`. The Streamable HTTP
endpoint is `/mcp`.
Restart the service after adding or removing a skill. This refreshes the MCP
tool list.
