{ buildGoModule }:
buildGoModule {
  pname = "agent-skills-mcp";
  version = "1.0.0";
  src = ./.;
  vendorHash = "sha256-F6toRF5zlwas4ypl8she/QEBMC/hp1b5fWHq4A0Z+o4=";
  env.CGO_ENABLED = "0";
  subPackages = [ "." ];
}
