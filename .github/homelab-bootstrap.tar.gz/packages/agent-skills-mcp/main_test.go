package main

import (
	"context"
	"net/http/httptest"
	"os"
	"path/filepath"
	"slices"
	"testing"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

func fixture(t *testing.T) *Store {
	t.Helper()
	root := t.TempDir()
	state := t.TempDir()
	for name, body := range map[string]string{
		"bro/SKILL.md":        "---\ndescription: Rewrite dense prose.\n---\n\n# Bro\n",
		"bro/references/a.md": "reference",
		"no-ghosts/SKILL.md":  "---\ndescription: 'Remove edit history.'\n---\n",
		"index.md":            "not a skill",
	} {
		path := filepath.Join(root, name)
		if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(body), 0600); err != nil {
			t.Fatal(err)
		}
	}
	store, err := openStore(root, state)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(store.close)
	return store
}

func TestSkillsAndRead(t *testing.T) {
	store := fixture(t)
	skills, err := store.skills()
	if err != nil {
		t.Fatal(err)
	}
	if len(skills) != 2 || skills[0] != (Skill{Name: "bro", Description: "Rewrite dense prose."}) || skills[1].Name != "no-ghosts" {
		t.Fatalf("skills = %#v", skills)
	}
	result, err := store.read("bro", "")
	if err != nil {
		t.Fatal(err)
	}
	if result.Content == "" || result.Revision == "" || !slices.Equal(result.Files, []string{"SKILL.md", "references/a.md"}) {
		t.Fatalf("result = %#v", result)
	}
	result, err = store.read("bro", "references/a.md")
	if err != nil || result.Content != "reference" || result.Files != nil {
		t.Fatalf("reference = %#v, %v", result, err)
	}
}

func TestFoldedDescription(t *testing.T) {
	got, err := description("---\ndescription: >-\n  First line.\n  Second line.\nname: example\n---\n")
	if err != nil || got != "First line. Second line." {
		t.Fatalf("description = %q, %v", got, err)
	}
}

func TestMCPTools(t *testing.T) {
	store := fixture(t)
	skills, err := store.skills()
	if err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(handler(store, skills))
	defer server.Close()
	client := mcp.NewClient(&mcp.Implementation{Name: "test", Version: "1"}, nil)
	session, err := client.Connect(context.Background(), &mcp.StreamableClientTransport{Endpoint: server.URL}, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer session.Close()
	tools, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(tools.Tools) != 4 || tools.Tools[0].Name != "bro" || tools.Tools[0].Description != "Rewrite dense prose." || tools.Tools[0].Annotations == nil || !tools.Tools[0].Annotations.ReadOnlyHint {
		t.Fatalf("tools = %#v", tools.Tools)
	}
	names := []string{tools.Tools[0].Name, tools.Tools[1].Name, tools.Tools[2].Name, tools.Tools[3].Name}
	slices.Sort(names)
	if !slices.Equal(names, []string{"bro", "delete", "no-ghosts", "write"}) {
		t.Fatalf("tool names = %v", names)
	}
	result, err := session.CallTool(context.Background(), &mcp.CallToolParams{Name: "no-ghosts"})
	if err != nil || result.IsError {
		t.Fatalf("call = %#v, %v", result, err)
	}
}

func TestWriteAndDelete(t *testing.T) {
	store := fixture(t)
	read, err := store.read("bro", "")
	if err != nil {
		t.Fatal(err)
	}
	if _, err = store.write("bro", "SKILL.md", "---\ndescription: New.\n---\n", "wrong"); err == nil {
		t.Fatal("stale write accepted")
	}
	written, err := store.write("bro", "SKILL.md", "---\ndescription: New.\n---\n", read.Revision)
	if err != nil || !written.RestartRequired || written.Revision == read.Revision {
		t.Fatalf("write = %#v, %v", written, err)
	}
	created, err := store.write("bro", "references/new.md", "new", written.Revision)
	if err != nil || created.RestartRequired || created.Revision == written.Revision {
		t.Fatalf("create = %#v, %v", created, err)
	}
	if _, err = store.delete("bro", read.Revision); err == nil {
		t.Fatal("stale delete accepted")
	}
	current, err := store.read("bro", "")
	if err != nil {
		t.Fatal(err)
	}
	deleted, err := store.delete("bro", current.Revision)
	if err != nil || !deleted.RestartRequired {
		t.Fatalf("delete = %#v, %v", deleted, err)
	}
	if _, err = store.read("bro", ""); !os.IsNotExist(err) {
		t.Fatalf("skill remains: %v", err)
	}
}

func TestPathGuards(t *testing.T) {
	store := fixture(t)
	outside := filepath.Join(t.TempDir(), "outside.md")
	if err := os.WriteFile(outside, []byte("secret"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outside, filepath.Join(store.rootPath, "bro", "escape.md")); err != nil {
		t.Fatal(err)
	}
	for _, file := range []string{"../index.md", "/etc/passwd", ".hidden", "references/../../index.md", "escape.md"} {
		if _, err := store.read("bro", file); err == nil {
			t.Errorf("accepted %q", file)
		}
	}
}
