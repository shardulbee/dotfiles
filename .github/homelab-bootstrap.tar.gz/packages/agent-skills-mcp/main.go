package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path"
	"slices"
	"strings"
	"sync"
	"syscall"
	"time"
	"unicode/utf8"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

type Skill struct {
	Name        string
	Description string
}

type Result struct {
	Content  string   `json:"content"`
	Revision string   `json:"revision"`
	Files    []string `json:"files,omitempty"`
}

type Mutation struct {
	Revision        string `json:"revision,omitempty"`
	RestartRequired bool   `json:"restartRequired"`
}

type Store struct {
	rootPath string
	root     *os.Root
	state    *os.Root
	lock     *os.File
	mu       sync.Mutex
}

func openStore(root, state string) (*Store, error) {
	r, err := os.OpenRoot(root)
	if err != nil {
		return nil, err
	}
	s, err := os.OpenRoot(state)
	if err != nil {
		r.Close()
		return nil, err
	}
	lock, err := s.OpenFile("vault.lock", os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		r.Close()
		s.Close()
		return nil, err
	}
	return &Store{rootPath: root, root: r, state: s, lock: lock}, nil
}

func (s *Store) close() {
	s.root.Close()
	s.state.Close()
	s.lock.Close()
}

func description(body string) (string, error) {
	lines := strings.Split(body, "\n")
	if len(lines) == 0 || strings.TrimSpace(lines[0]) != "---" {
		return "", errors.New("SKILL.md has no frontmatter")
	}
	for index, line := range lines[1:] {
		if strings.TrimSpace(line) == "---" {
			break
		}
		key, value, ok := strings.Cut(line, ":")
		if ok && strings.TrimSpace(key) == "description" {
			value = strings.Trim(strings.TrimSpace(value), `"'`)
			if value == ">" || value == ">-" || value == "|" || value == "|-" {
				var parts []string
				for _, continuation := range lines[index+2:] {
					if continuation == "" || continuation[0] != ' ' && continuation[0] != '\t' {
						break
					}
					parts = append(parts, strings.TrimSpace(continuation))
				}
				value = strings.Join(parts, " ")
			}
			if value != "" {
				return value, nil
			}
		}
	}
	return "", errors.New("SKILL.md has no description")
}

func validName(name string) bool {
	if name == "" || name == "write" || name == "delete" {
		return false
	}
	for _, r := range name {
		if !((r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '_') {
			return false
		}
	}
	return true
}

func (s *Store) skills() ([]Skill, error) {
	entries, err := os.ReadDir(s.rootPath)
	if err != nil {
		return nil, err
	}
	var skills []Skill
	for _, entry := range entries {
		if !entry.IsDir() || !validName(entry.Name()) {
			continue
		}
		body, err := s.root.ReadFile(path.Join(entry.Name(), "SKILL.md"))
		if errors.Is(err, fs.ErrNotExist) {
			continue
		}
		if err != nil {
			return nil, err
		}
		description, err := description(string(body))
		if err != nil {
			return nil, fmt.Errorf("%s: %w", entry.Name(), err)
		}
		skills = append(skills, Skill{Name: entry.Name(), Description: description})
	}
	slices.SortFunc(skills, func(a, b Skill) int { return strings.Compare(a.Name, b.Name) })
	return skills, nil
}

func validFile(file string) bool {
	if !fs.ValidPath(file) || strings.ContainsAny(file, "\\\x00") {
		return false
	}
	for _, part := range strings.Split(file, "/") {
		if strings.HasPrefix(part, ".") {
			return false
		}
	}
	return true
}

func (s *Store) read(skill, file string) (Result, error) {
	if file == "" {
		file = "SKILL.md"
	}
	if !validName(skill) || !validFile(file) {
		return Result{}, errors.New("invalid skill or file path")
	}
	var result Result
	err := s.locked(func() error {
		body, err := s.root.ReadFile(path.Join(skill, file))
		if err != nil {
			return err
		}
		if !utf8.Valid(body) {
			return errors.New("skill files must be UTF-8")
		}
		result.Content = string(body)
		if file != "SKILL.md" {
			result.Revision, err = s.skillRevision(skill)
			return err
		}
		if err := fs.WalkDir(s.root.FS(), skill, func(name string, entry fs.DirEntry, err error) error {
			if err == nil && !entry.IsDir() {
				result.Files = append(result.Files, strings.TrimPrefix(name, skill+"/"))
			}
			return err
		}); err != nil {
			return err
		}
		result.Revision, err = s.skillRevision(skill)
		return err
	})
	return result, err
}

func (s *Store) skillRevision(skill string) (string, error) {
	digest := sha256.New()
	err := fs.WalkDir(s.root.FS(), skill, func(name string, entry fs.DirEntry, err error) error {
		if err != nil || entry.IsDir() {
			return err
		}
		if entry.Type()&os.ModeSymlink != 0 {
			return errors.New("symlink files are not supported")
		}
		body, err := s.root.ReadFile(name)
		if err != nil {
			return err
		}
		digest.Write([]byte(strings.TrimPrefix(name, skill+"/")))
		digest.Write([]byte{0})
		digest.Write(body)
		digest.Write([]byte{0})
		return nil
	})
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(digest.Sum(nil)), nil
}

func (s *Store) locked(operation func() error) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := syscall.Flock(int(s.lock.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		return errors.New("vault sync busy; retry")
	}
	defer syscall.Flock(int(s.lock.Fd()), syscall.LOCK_UN)
	return operation()
}

func (s *Store) write(skill, file, content, revision string) (Mutation, error) {
	if file == "" {
		file = "SKILL.md"
	}
	if !validName(skill) || !validFile(file) {
		return Mutation{}, errors.New("invalid skill or file path")
	}
	body := []byte(content)
	if !utf8.Valid(body) || len(body) > 2_000_000 {
		return Mutation{}, errors.New("content must be UTF-8 and at most 2000000 bytes")
	}
	if file == "SKILL.md" {
		if _, err := description(content); err != nil {
			return Mutation{}, err
		}
	}
	result := Mutation{RestartRequired: file == "SKILL.md"}
	err := s.locked(func() error {
		_, err := s.root.Stat(path.Join(skill, "SKILL.md"))
		exists := err == nil
		if err != nil && !errors.Is(err, fs.ErrNotExist) {
			return err
		}
		if !exists {
			if file != "SKILL.md" || revision != "" {
				return errors.New("create SKILL.md first and omit revision")
			}
		} else {
			current, err := s.skillRevision(skill)
			if err != nil {
				return err
			}
			if revision == "" || current != revision {
				return errors.New("stale revision; read the skill before writing")
			}
		}
		target := path.Join(skill, file)
		if err := s.root.MkdirAll(path.Dir(target), 0700); err != nil {
			return err
		}
		temporary := path.Join(path.Dir(target), ".skill-"+rand.Text())
		if err := s.root.WriteFile(temporary, body, 0600); err != nil {
			return err
		}
		defer s.root.Remove(temporary)
		if err := s.root.Rename(temporary, target); err != nil {
			return err
		}
		result.Revision, err = s.skillRevision(skill)
		return nil
	})
	return result, err
}

func (s *Store) delete(skill, revision string) (Mutation, error) {
	if !validName(skill) || revision == "" {
		return Mutation{}, errors.New("skill and revision are required")
	}
	result := Mutation{RestartRequired: true}
	err := s.locked(func() error {
		current, err := s.skillRevision(skill)
		if err != nil {
			return err
		}
		if current != revision {
			return errors.New("stale revision; read the skill before deleting")
		}
		return s.root.RemoveAll(skill)
	})
	return result, err
}

func handler(s *Store, skills []Skill) http.Handler {
	server := mcp.NewServer(&mcp.Implementation{Name: "agent-skills", Version: "1.0.0"}, nil)
	for _, skill := range skills {
		mcp.AddTool(server, &mcp.Tool{
			Name:        skill.Name,
			Description: skill.Description,
			Annotations: &mcp.ToolAnnotations{ReadOnlyHint: true},
		}, func(_ context.Context, _ *mcp.CallToolRequest, in struct {
			File string `json:"file,omitempty" jsonschema:"Optional file path within the skill; defaults to SKILL.md"`
		}) (*mcp.CallToolResult, Result, error) {
			result, err := s.read(skill.Name, in.File)
			return nil, result, err
		})
	}
	destructive := true
	mcp.AddTool(server, &mcp.Tool{
		Name:        "write",
		Description: "Write a UTF-8 skill file only when the user explicitly asks. Existing skills require the revision returned by a skill tool.",
		Annotations: &mcp.ToolAnnotations{DestructiveHint: &destructive},
	}, func(_ context.Context, _ *mcp.CallToolRequest, in struct {
		Skill    string  `json:"skill"`
		File     string  `json:"file,omitempty" jsonschema:"File within the skill; defaults to SKILL.md"`
		Content  string  `json:"content"`
		Revision *string `json:"revision,omitempty" jsonschema:"Required to replace an existing file; omit to create"`
	}) (*mcp.CallToolResult, Mutation, error) {
		revision := ""
		if in.Revision != nil {
			revision = *in.Revision
		}
		result, err := s.write(in.Skill, in.File, in.Content, revision)
		return nil, result, err
	})
	mcp.AddTool(server, &mcp.Tool{
		Name:        "delete",
		Description: "Delete one skill and all its files only when the user explicitly asks. Requires the revision returned by a skill tool.",
		Annotations: &mcp.ToolAnnotations{DestructiveHint: &destructive},
	}, func(_ context.Context, _ *mcp.CallToolRequest, in struct {
		Skill    string `json:"skill"`
		Revision string `json:"revision" jsonschema:"Revision returned by the skill tool"`
	}) (*mcp.CallToolResult, Mutation, error) {
		result, err := s.delete(in.Skill, in.Revision)
		return nil, result, err
	})
	return mcp.NewStreamableHTTPHandler(func(*http.Request) *mcp.Server { return server }, &mcp.StreamableHTTPOptions{Stateless: true})
}

func main() {
	store, err := openStore(os.Getenv("SKILLS_ROOT"), os.Getenv("SKILLS_STATE"))
	if err != nil {
		log.Fatal(err)
	}
	defer store.close()
	skills, err := store.skills()
	if err != nil {
		log.Fatal(err)
	}
	mux := http.NewServeMux()
	mux.Handle("/mcp", handler(store, skills))
	server := &http.Server{Addr: os.Getenv("LISTEN_ADDR"), Handler: http.MaxBytesHandler(mux, 1_000_000), ReadHeaderTimeout: 10 * time.Second}
	if err = server.ListenAndServe(); err != nil {
		log.Fatal(fmt.Errorf("serve: %w", err))
	}
}
