# Fastmail MCP guide

See [README.md](README.md) for ownership and entrypoints. Never persist request
bearer/JMAP credentials; keep credentials and mutable state outside Git.

Do not add automated tests. Use the root workflow's static checks and builds.
