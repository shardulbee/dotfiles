# Fastmail MCP

Streamable HTTP MCP backed by Fastmail JMAP. Requires Folders mode; see the
account-mode constraint beside [mailbox mapping](internal/fastmail/mail.go).

- [Transport and health check](main.go), [MCP tools](internal/fastmail/mcp.go)
- [Nix package](default.nix), [checks](../../.github/workflows/deploy.yml)
- [Production operations](../../nixos/services/executor/)
