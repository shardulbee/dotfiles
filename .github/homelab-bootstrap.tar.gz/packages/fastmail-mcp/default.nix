{ buildGoModule }:

buildGoModule {
  pname = "fastmail-mcp";
  version = "5.0.0";
  src = ./.;
  vendorHash = "sha256-nhv+T7dIiOs8spt1esRXmbRHetIeJhwIz64tBJr5skA=";
  subPackages = [ "." ];
  ldflags = [
    "-s"
    "-w"
  ];
  env.CGO_ENABLED = "0";
  doCheck = false;
}
