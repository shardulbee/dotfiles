package fastmail

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type SearchEmailArgs struct {
	Query  string `json:"query,omitempty"`
	Cursor string `json:"cursor,omitempty"`
	Limit  int    `json:"limit,omitempty"`
}

type ReadEmailArgs struct {
	ID                string `json:"id"`
	IncludeQuotedText bool   `json:"includeQuotedText,omitempty"`
}

type ReadThreadArgs struct {
	ThreadID string `json:"threadId"`
}

type IDsArgs struct {
	IDs []string `json:"ids"`
}

type UpdateEmailArgs struct {
	IDs       []string `json:"ids"`
	IsRead    *bool    `json:"isRead,omitempty"`
	IsFlagged *bool    `json:"isFlagged,omitempty"`
	Folder    string   `json:"folder,omitempty"`
}

type MemoArgs struct {
	EmailID string `json:"emailId"`
	Text    string `json:"text"`
}

type UploadArgs struct {
	Name     string `json:"name"`
	Data     string `json:"data"`
	MIMEType string `json:"mimeType,omitempty"`
}

type searchCursor struct {
	Query    string `json:"query"`
	Position int    `json:"position"`
}

var searchTokenPattern = regexp.MustCompile(`(?:[^\s"]+|"[^"]*")+`)

func decodeCursor(value, query string) (int, error) {
	if value == "" {
		return 0, nil
	}
	content, err := base64.RawURLEncoding.DecodeString(value)
	if err != nil {
		return 0, errors.New("invalid cursor")
	}
	var cursor searchCursor
	if json.Unmarshal(content, &cursor) != nil || cursor.Position < 0 || cursor.Query != query {
		return 0, errors.New("cursor does not match query")
	}
	return cursor.Position, nil
}

func encodeCursor(query string, position int) string {
	content, _ := json.Marshal(searchCursor{Query: query, Position: position})
	return base64.RawURLEncoding.EncodeToString(content)
}

func parseDate(value string, now time.Time) (string, error) {
	lower := strings.ToLower(value)
	if lower == "today" || lower == "yesterday" || lower == "tomorrow" {
		offset := map[string]int{"yesterday": -1, "today": 0, "tomorrow": 1}[lower]
		date := now.UTC().AddDate(0, 0, offset)
		return time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, time.UTC).Format(time.RFC3339), nil
	}
	if len(lower) > 1 {
		amount, err := strconv.Atoi(lower[:len(lower)-1])
		if err == nil {
			switch lower[len(lower)-1] {
			case 'd':
				now = now.AddDate(0, 0, -amount)
			case 'w':
				now = now.AddDate(0, 0, -7*amount)
			case 'm':
				now = now.AddDate(0, -amount, 0)
			case 'y':
				now = now.AddDate(-amount, 0, 0)
			default:
				err = errors.New("invalid unit")
			}
			if err == nil {
				return now.UTC().Format(time.RFC3339), nil
			}
		}
	}
	parsed, err := time.Parse(time.RFC3339, value)
	if err != nil {
		if date, dateErr := time.Parse("2006-01-02", value); dateErr == nil {
			return date.Format(time.RFC3339), nil
		}
		return "", fmt.Errorf("invalid date %q", value)
	}
	return parsed.Format(time.RFC3339), nil
}

func findFolder(value string, all []Folder) (Folder, error) {
	var matches []Folder
	for _, folder := range all {
		role := ""
		if folder.Role != nil {
			role = *folder.Role
		}
		if folder.ID == value || strings.EqualFold(folder.Path, value) || strings.EqualFold(role, value) || strings.EqualFold(folder.Name, value) {
			matches = append(matches, folder)
		}
	}
	if len(matches) == 0 {
		return Folder{}, fmt.Errorf("folder not found: %s", value)
	}
	if len(matches) > 1 {
		return Folder{}, fmt.Errorf("folder is ambiguous; use its ID or full path: %s", value)
	}
	return matches[0], nil
}

func addressFilter(field, value string, identities []Identity) map[string]any {
	if !strings.EqualFold(value, "me") {
		return map[string]any{field: value}
	}
	conditions := make([]map[string]any, 0, len(identities))
	for _, identity := range identities {
		conditions = append(conditions, map[string]any{field: identity.Email})
	}
	if len(conditions) == 1 {
		return conditions[0]
	}
	return map[string]any{"operator": "OR", "conditions": conditions}
}

func parseSearchQuery(query string, all []Folder, identities []Identity) (any, error) {
	conditions := []map[string]any{}
	for _, token := range searchTokenPattern.FindAllString(query, -1) {
		key, value, qualified := strings.Cut(token, ":")
		value = strings.Trim(value, `"`)
		if !qualified {
			conditions = append(conditions, map[string]any{"text": strings.Trim(token, `"`)})
			continue
		}
		switch strings.ToLower(key) {
		case "from", "to", "cc", "bcc":
			conditions = append(conditions, addressFilter(strings.ToLower(key), value, identities))
		case "subject", "body", "text":
			conditions = append(conditions, map[string]any{strings.ToLower(key): value})
		case "with":
			addresses := []any{}
			for _, field := range []string{"from", "to", "cc", "bcc"} {
				filter := addressFilter(field, value, identities)
				if nested, ok := filter["conditions"].([]map[string]any); ok {
					for _, condition := range nested {
						addresses = append(addresses, condition)
					}
				} else {
					addresses = append(addresses, filter)
				}
			}
			conditions = append(conditions, map[string]any{"operator": "OR", "conditions": addresses})
		case "in":
			folder, err := findFolder(value, all)
			if err != nil {
				return nil, err
			}
			conditions = append(conditions, map[string]any{"inMailbox": folder.ID})
		case "before", "after":
			date, err := parseDate(value, time.Now())
			if err != nil {
				return nil, err
			}
			conditions = append(conditions, map[string]any{strings.ToLower(key): date})
		case "has":
			if strings.EqualFold(value, "attachment") {
				conditions = append(conditions, map[string]any{"hasAttachment": true})
			} else {
				return nil, fmt.Errorf("unsupported has qualifier: %s", value)
			}
		case "is":
			keywords := map[string]string{"read": "$seen", "flagged": "$flagged", "answered": "$answered", "forwarded": "$forwarded", "draft": "$draft"}
			negated := strings.HasPrefix(value, "un")
			name := value
			if negated {
				name = strings.TrimPrefix(value, "un")
			}
			if value == "unread" {
				name, negated = "read", true
			}
			keyword, ok := keywords[name]
			if !ok {
				return nil, fmt.Errorf("unsupported is qualifier: %s", value)
			}
			field := "hasKeyword"
			if negated {
				field = "notKeyword"
			}
			conditions = append(conditions, map[string]any{field: keyword})
		default:
			conditions = append(conditions, map[string]any{"text": token})
		}
	}
	if len(conditions) == 0 {
		return map[string]any{}, nil
	}
	if len(conditions) == 1 {
		return conditions[0], nil
	}
	return map[string]any{"operator": "AND", "conditions": conditions}, nil
}

func (c *Client) upload(ctx context.Context, jc *Context, args UploadArgs) (map[string]any, error) {
	data, err := base64.StdEncoding.Strict().DecodeString(args.Data)
	if err != nil {
		return nil, errors.New("data must be valid base64")
	}
	if jc.Session.UploadURL == "" {
		return nil, errors.New("JMAP session has no upload URL")
	}
	mimeType := valueOr(args.MIMEType, "application/octet-stream")
	url := fillDownloadURL(jc.Session.UploadURL, map[string]string{"accountId": jc.MailAccountID})
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	request.Header.Set("Authorization", "Bearer "+jc.Token)
	request.Header.Set("Content-Type", mimeType)
	response, err := c.HTTP.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	content, err := io.ReadAll(io.LimitReader(response.Body, maxJSON+1))
	if err != nil {
		return nil, err
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return nil, fmt.Errorf("upload failed: %s", response.Status)
	}
	var uploaded struct {
		BlobID string `json:"blobId"`
		Type   string `json:"type"`
		Size   int    `json:"size"`
	}
	if err := json.Unmarshal(content, &uploaded); err != nil {
		return nil, err
	}
	if uploaded.BlobID == "" {
		return nil, errors.New("upload returned no blob ID")
	}
	return map[string]any{"blobId": uploaded.BlobID, "name": args.Name, "mimeType": valueOr(uploaded.Type, mimeType), "size": uploaded.Size}, nil
}

func (c *Client) searchEmail(ctx context.Context, jc *Context, args SearchEmailArgs) (map[string]any, error) {
	if args.Limit == 0 {
		args.Limit = 10
	}
	if args.Limit < 1 || args.Limit > 50 {
		return nil, errors.New("limit must be between 1 and 50")
	}
	position, err := decodeCursor(args.Cursor, args.Query)
	if err != nil {
		return nil, err
	}
	mailboxes, err := c.getMailboxes(ctx, jc)
	if err != nil {
		return nil, err
	}
	allFolders := folders(mailboxes)
	identities, err := c.getIdentities(ctx, jc)
	if err != nil {
		return nil, err
	}
	filter, err := parseSearchQuery(args.Query, allFolders, identities)
	if err != nil {
		return nil, err
	}
	response, err := c.JMAP(ctx, jc,
		call{"Email/query", map[string]any{"accountId": jc.MailAccountID, "filter": filter, "sort": []map[string]any{{"property": "receivedAt", "isAscending": false}}, "limit": args.Limit + 1, "position": position}, "q"},
		call{"Email/get", map[string]any{"accountId": jc.MailAccountID, "#ids": map[string]any{"resultOf": "q", "name": "Email/query", "path": "/ids"}, "properties": []string{"id", "threadId", "mailboxIds", "keywords", "subject", "receivedAt", "sentAt", "from", "to", "cc", "bcc", "replyTo", "messageId", "preview"}}, "g"},
	)
	if err != nil {
		return nil, err
	}
	var query struct {
		IDs []string `json:"ids"`
	}
	var get struct {
		List []Email `json:"list"`
	}
	if err := method(response, 0, &query); err != nil {
		return nil, err
	}
	if err := method(response, 1, &get); err != nil {
		return nil, err
	}
	hasMore := len(query.IDs) > args.Limit
	byID := map[string]Email{}
	for _, email := range get.List {
		byID[email.ID] = email
	}
	results := []NativeEmail{}
	for _, id := range query.IDs[:min(len(query.IDs), args.Limit)] {
		if email, ok := byID[id]; ok {
			results = append(results, nativeEmail(email, allFolders, nil, true, true, false))
		}
	}
	result := map[string]any{"results": results, "hasMore": hasMore}
	if hasMore {
		result["nextCursor"] = encodeCursor(args.Query, position+args.Limit)
	}
	return result, nil
}

func (c *Client) readEmail(ctx context.Context, jc *Context, args ReadEmailArgs) (NativeEmail, error) {
	emails, err := c.emailGet(ctx, jc, []string{args.ID}, bodyFormatText)
	if err != nil {
		return NativeEmail{}, err
	}
	mailboxes, err := c.getMailboxes(ctx, jc)
	if err != nil {
		return NativeEmail{}, err
	}
	body := emailBody(emails[0], bodyFormatText).Content
	if !args.IncludeQuotedText {
		body = stripQuotedText(body)
	}
	return nativeEmail(emails[0], folders(mailboxes), &body, false, true, true), nil
}

func (c *Client) readThread(ctx context.Context, jc *Context, id string) ([]NativeEmail, error) {
	response, err := c.JMAP(ctx, jc, call{"Thread/get", map[string]any{"accountId": jc.MailAccountID, "ids": []string{id}}, "t"})
	if err != nil {
		return nil, err
	}
	var threads struct {
		List     []threadRecord `json:"list"`
		NotFound []string       `json:"notFound"`
	}
	if err := method(response, 0, &threads); err != nil {
		return nil, err
	}
	if len(threads.NotFound) > 0 || len(threads.List) != 1 {
		return nil, fmt.Errorf("thread not found: %s", id)
	}
	emails, err := c.emailGet(ctx, jc, threads.List[0].EmailIDs, bodyFormatText)
	if err != nil {
		return nil, err
	}
	mailboxes, err := c.getMailboxes(ctx, jc)
	if err != nil {
		return nil, err
	}
	sortEmails(emails)
	result := make([]NativeEmail, 0, len(emails))
	for _, email := range emails {
		body := stripQuotedText(emailBody(email, bodyFormatText).Content)
		if len(body) > 20_000 {
			body = body[:20_000]
		}
		result = append(result, nativeEmail(email, folders(mailboxes), &body, false, false, true))
	}
	return result, nil
}

func (c *Client) updateEmails(ctx context.Context, jc *Context, args UpdateEmailArgs) (map[string]any, error) {
	if len(args.IDs) < 1 || len(args.IDs) > 100 {
		return nil, errors.New("ids must contain 1..100 email IDs")
	}
	patch := map[string]any{}
	if args.IsRead != nil {
		patch["keywords/$seen"] = map[bool]any{true: true, false: nil}[*args.IsRead]
	}
	if args.IsFlagged != nil {
		patch["keywords/$flagged"] = map[bool]any{true: true, false: nil}[*args.IsFlagged]
	}
	if args.Folder != "" {
		mailboxes, err := c.getMailboxes(ctx, jc)
		if err != nil {
			return nil, err
		}
		folder, err := findFolder(args.Folder, folders(mailboxes))
		if err != nil {
			return nil, err
		}
		role := ""
		if folder.Role != nil {
			role = *folder.Role
		}
		if role != "" && role != "inbox" && role != "junk" {
			return nil, fmt.Errorf("use the dedicated tool or choose a normal destination folder: %s", args.Folder)
		}
		patch["mailboxIds"] = map[string]bool{folder.ID: true}
	}
	if len(patch) == 0 {
		return nil, errors.New("at least one mutation field is required")
	}
	updates := map[string]any{}
	for _, id := range unique(args.IDs) {
		updates[id] = patch
	}
	response, err := c.JMAP(ctx, jc, call{"Email/set", map[string]any{"accountId": jc.MailAccountID, "update": updates}, "update"})
	if err != nil {
		return nil, err
	}
	var set jmapSetResult
	if err := method(response, 0, &set); err != nil {
		return nil, err
	}
	if err := set.requireUpdated(args.IDs); err != nil {
		return nil, err
	}
	return map[string]any{"ids": unique(args.IDs), "updated": true}, nil
}

func (c *Client) moveEmailsToRole(ctx context.Context, jc *Context, ids []string, role string) (map[string]any, error) {
	if len(ids) < 1 || len(ids) > 100 {
		return nil, errors.New("ids must contain 1..100 email IDs")
	}
	mailboxes, err := c.getMailboxes(ctx, jc)
	if err != nil {
		return nil, err
	}
	var destination string
	for _, mailbox := range mailboxes {
		if mailbox.Role != nil && *mailbox.Role == role {
			destination = mailbox.ID
		}
	}
	if destination == "" {
		return nil, fmt.Errorf("no %s folder found", role)
	}
	updates := map[string]any{}
	for _, id := range unique(ids) {
		updates[id] = map[string]any{"mailboxIds": map[string]bool{destination: true}}
	}
	response, err := c.JMAP(ctx, jc, call{"Email/set", map[string]any{"accountId": jc.MailAccountID, "update": updates}, role})
	if err != nil {
		return nil, err
	}
	var set jmapSetResult
	if err := method(response, 0, &set); err != nil {
		return nil, err
	}
	if err := set.requireUpdated(ids); err != nil {
		return nil, err
	}
	if role == "archive" {
		return map[string]any{"ids": unique(ids), "archived": true}, nil
	}
	return map[string]any{"trashed": unique(ids)}, nil
}

func (c *Client) setMemo(ctx context.Context, jc *Context, args MemoArgs) (map[string]any, error) {
	var memo any
	if args.Text != "" {
		memo = args.Text
	}
	targets, err := c.emailGet(ctx, jc, []string{args.EmailID}, "")
	if err != nil {
		return nil, err
	}
	target := targets[0]
	response, err := c.JMAP(ctx, jc, call{"Thread/get", map[string]any{"accountId": jc.MailAccountID, "ids": []string{target.ThreadID}}, "thread"})
	if err != nil {
		return nil, err
	}
	var threads struct {
		List []threadRecord `json:"list"`
	}
	if err := method(response, 0, &threads); err != nil || len(threads.List) != 1 {
		return nil, valueOrError(err, "email thread not found")
	}
	members, err := c.emailGet(ctx, jc, threads.List[0].EmailIDs, "")
	if err != nil {
		return nil, err
	}
	destroy := []string{}
	for _, member := range members {
		if member.Keywords["$memo"] && intersects(member.InReplyTo, target.MessageID) {
			destroy = append(destroy, member.ID)
		}
	}
	if args.Text != "" {
		mailboxes, err := c.getMailboxes(ctx, jc)
		if err != nil {
			return nil, err
		}
		var memoMailbox string
		for _, mailbox := range mailboxes {
			if strings.EqualFold(mailbox.Name, "Memos") {
				memoMailbox = mailbox.ID
			}
		}
		if memoMailbox == "" {
			return nil, errors.New("no Memos folder found")
		}
		identities, err := c.getIdentities(ctx, jc)
		if err != nil {
			return nil, err
		}
		identity, err := selectIdentity(identities, "")
		if err != nil {
			return nil, err
		}
		set := map[string]any{"accountId": jc.MailAccountID, "create": map[string]any{"memo": map[string]any{
			"subject": target.Subject, "inReplyTo": target.MessageID, "references": target.MessageID,
			"mailboxIds": map[string]bool{memoMailbox: true}, "keywords": map[string]bool{"$memo": true, "$seen": true},
			"from":          []Address{{Name: identity.Name, Email: identity.Email}},
			"bodyStructure": map[string]any{"type": "text/plain", "partId": "text"},
			"bodyValues":    map[string]any{"text": map[string]any{"value": args.Text}},
		}}}
		response, err = c.JMAP(ctx, jc, call{"Email/set", set, "memo-create"})
		if err != nil {
			return nil, fmt.Errorf("memo creation outcome is unknown; the previous memo was preserved, so inspect before retrying: %w", err)
		}
		var created jmapSetResult
		if err := method(response, 0, &created); err != nil {
			return nil, fmt.Errorf("memo creation was not confirmed; the previous memo was preserved, so inspect before retrying: %w", err)
		}
		if failure, failed := created.NotCreated["memo"]; failed {
			return nil, fmt.Errorf("memo was not created: %s", valueOr(failure.Description, valueOr(failure.Type, "request failed")))
		}
		if item, ok := created.Created["memo"]; !ok || item.ID == "" {
			return nil, errors.New("memo creation was not confirmed; the previous memo was preserved")
		}
	}
	if len(destroy) == 0 {
		return map[string]any{"emailId": args.EmailID, "memo": memo}, nil
	}
	response, err = c.JMAP(ctx, jc, call{"Email/set", map[string]any{"accountId": jc.MailAccountID, "destroy": destroy}, "memo-destroy"})
	if err != nil {
		if args.Text != "" {
			return nil, fmt.Errorf("new memo was created, but previous memo cleanup is uncertain; do not retry automatically: %w", err)
		}
		return nil, fmt.Errorf("memo removal outcome is unknown; inspect before retrying: %w", err)
	}
	var destroyed jmapSetResult
	if err := method(response, 0, &destroyed); err != nil {
		if args.Text != "" {
			return nil, fmt.Errorf("new memo was created, but previous memo cleanup failed; do not retry automatically: %w", err)
		}
		return nil, err
	}
	if err := destroyed.requireDestroyed(destroy); err != nil {
		if args.Text != "" {
			return nil, fmt.Errorf("new memo was created, but previous memo cleanup failed; do not retry automatically: %w", err)
		}
		return nil, err
	}
	return map[string]any{"emailId": args.EmailID, "memo": memo}, nil
}

func intersects(left, right []string) bool {
	values := map[string]bool{}
	for _, value := range left {
		values[value] = true
	}
	for _, value := range right {
		if values[value] {
			return true
		}
	}
	return false
}

func valueOrError(err error, fallback string) error {
	if err != nil {
		return err
	}
	return errors.New(fallback)
}
