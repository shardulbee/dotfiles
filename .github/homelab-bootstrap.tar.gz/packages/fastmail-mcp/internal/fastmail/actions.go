package fastmail

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"html"
	"strings"

	"github.com/yuin/goldmark"
)

type AttachmentReference struct {
	BlobID   string `json:"blobId"`
	Name     string `json:"name,omitempty"`
	MIMEType string `json:"mimeType,omitempty"`
}

type ComposeArgs struct {
	To          []Address             `json:"to,omitempty"`
	CC          []Address             `json:"cc,omitempty"`
	BCC         []Address             `json:"bcc,omitempty"`
	Body        string                `json:"body"`
	Subject     string                `json:"subject,omitempty"`
	From        string                `json:"from,omitempty"`
	Attachments []AttachmentReference `json:"attachments,omitempty"`
	EmailID     string                `json:"emailId,omitempty"`
	Mode        string                `json:"mode,omitempty"`
	ReplyAll    bool                  `json:"replyAll,omitempty"`
}

func selectIdentity(identities []Identity, from string) (Identity, error) {
	if from == "" {
		for _, identity := range identities {
			if identity.Email != "" && !strings.HasPrefix(identity.Email, "*@") {
				return identity, nil
			}
		}
		return Identity{}, errors.New("no concrete sending identity found; specify from")
	}
	for _, identity := range identities {
		if strings.EqualFold(identity.Email, from) {
			return identity, nil
		}
	}
	for _, identity := range identities {
		if strings.HasPrefix(identity.Email, "*@") && strings.HasSuffix(strings.ToLower(from), strings.ToLower(identity.Email[1:])) {
			identity.Email = from
			return identity, nil
		}
	}
	return Identity{}, fmt.Errorf("no JMAP identity found for %s", from)
}

func inferredIdentity(identities []Identity, recipients []Address) (string, error) {
	matches := map[string]string{}
	for _, recipient := range recipients {
		if recipient.Email == "" {
			continue
		}
		if _, err := selectIdentity(identities, recipient.Email); err == nil {
			matches[strings.ToLower(recipient.Email)] = recipient.Email
		}
	}
	if len(matches) > 1 {
		return "", errors.New("multiple sending identities match the original recipients; specify from")
	}
	for _, address := range matches {
		return address, nil
	}
	return "", nil
}

func markdownHTML(value string) (string, error) {
	var output bytes.Buffer
	if err := goldmark.Convert([]byte(value), &output); err != nil {
		return "", err
	}
	return output.String(), nil
}

func quoteText(original Email) string {
	body := emailBody(original, bodyFormatText).Content
	if body == "" {
		return ""
	}
	body = strings.ReplaceAll(body, "\n", "\n> ")
	from := strings.Join(simplifyAddresses(original.From), ", ")
	return fmt.Sprintf("\n\nOn %s, %s wrote:\n> %s", valueOr(original.ReceivedAt, original.SentAt), from, body)
}

func quoteHTML(original Email) string {
	body := emailBody(original, bodyFormatHTML)
	content := body.Content
	if body.Format != bodyFormatHTML {
		content = "<pre>" + html.EscapeString(content) + "</pre>"
	}
	if content == "" {
		return ""
	}
	return fmt.Sprintf("<p>On %s, %s wrote:</p><blockquote>%s</blockquote>", html.EscapeString(valueOr(original.ReceivedAt, original.SentAt)), html.EscapeString(strings.Join(simplifyAddresses(original.From), ", ")), content)
}

func dedupeAddresses(values []Address, own map[string]bool) []Address {
	seen := map[string]bool{}
	result := []Address{}
	for _, address := range values {
		key := strings.ToLower(address.Email)
		if key == "" || own[key] || seen[key] {
			continue
		}
		seen[key] = true
		result = append(result, address)
	}
	return result
}

func appendInferredAddresses(existing, candidates []Address, seen map[string]bool) []Address {
	for _, address := range existing {
		if address.Email != "" {
			seen[strings.ToLower(address.Email)] = true
		}
	}
	for _, address := range candidates {
		key := strings.ToLower(address.Email)
		if key != "" && !seen[key] {
			existing = append(existing, address)
			seen[key] = true
		}
	}
	return existing
}

func (c *Client) composeEmail(ctx context.Context, jc *Context, args ComposeArgs) (string, string, error) {
	userBody := args.Body
	mode := valueOr(args.Mode, "new")
	if mode != "new" && mode != "reply" && mode != "forward" {
		return "", "", errors.New("mode must be new, reply, or forward")
	}
	if mode != "new" && args.EmailID == "" {
		return "", "", errors.New("emailId is required for reply and forward")
	}
	mailboxes, err := c.getMailboxes(ctx, jc)
	if err != nil {
		return "", "", err
	}
	var draftsID string
	for _, mailbox := range mailboxes {
		if mailbox.Role != nil && *mailbox.Role == "drafts" {
			draftsID = mailbox.ID
		}
	}
	if draftsID == "" {
		return "", "", errors.New("no drafts mailbox found")
	}
	var original *Email
	if mode != "new" {
		emails, err := c.emailGet(ctx, jc, []string{args.EmailID}, bodyFormatText)
		if err != nil {
			return "", "", err
		}
		original = &emails[0]
	}
	identities, err := c.getIdentities(ctx, jc)
	if err != nil {
		return "", "", err
	}
	if args.From == "" && mode == "reply" && original != nil {
		args.From, err = inferredIdentity(identities, append(append([]Address{}, original.To...), original.CC...))
		if err != nil {
			return "", "", err
		}
	}
	identity, err := selectIdentity(identities, args.From)
	if err != nil {
		return "", "", err
	}
	own := map[string]bool{}
	for _, item := range identities {
		if !strings.HasPrefix(item.Email, "*@") {
			own[strings.ToLower(item.Email)] = true
		}
	}
	own[strings.ToLower(identity.Email)] = true
	if original != nil {
		prefix := "Re: "
		if mode == "forward" {
			prefix = "Fwd: "
		}
		if args.Subject == "" {
			if strings.HasPrefix(strings.ToLower(original.Subject), strings.ToLower(strings.TrimSpace(prefix))) {
				args.Subject = original.Subject
			} else {
				args.Subject = prefix + original.Subject
			}
		}
		if mode == "reply" {
			if len(args.To) == 0 {
				recipients := original.ReplyTo
				if len(recipients) == 0 {
					recipients = original.From
				}
				args.To = dedupeAddresses(recipients, own)
			}
			if args.ReplyAll {
				seen := map[string]bool{}
				for address := range own {
					seen[address] = true
				}
				for _, address := range args.CC {
					seen[strings.ToLower(address.Email)] = true
				}
				args.To = appendInferredAddresses(args.To, original.To, seen)
				args.CC = appendInferredAddresses(args.CC, original.CC, seen)
			}
		}
	}
	if len(args.To) == 0 {
		return "", "", errors.New("no recipients provided")
	}
	htmlBody, err := markdownHTML(userBody)
	if err != nil {
		return "", "", err
	}
	if original != nil {
		args.Body += quoteText(*original)
		htmlBody += quoteHTML(*original)
	}
	textPart := map[string]any{"type": "text/plain", "partId": "text"}
	htmlPart := map[string]any{"type": "text/html", "partId": "html"}
	bodyStructure := map[string]any{"type": "multipart/alternative", "subParts": []any{textPart, htmlPart}}
	if len(args.Attachments) > 0 {
		parts := []any{bodyStructure}
		for _, attachment := range args.Attachments {
			if attachment.BlobID == "" {
				return "", "", errors.New("attachment blobId is required")
			}
			parts = append(parts, map[string]any{"blobId": attachment.BlobID, "name": attachment.Name, "type": valueOr(attachment.MIMEType, "application/octet-stream"), "disposition": "attachment"})
		}
		bodyStructure = map[string]any{"type": "multipart/mixed", "subParts": parts}
	}
	email := map[string]any{
		"mailboxIds": map[string]bool{draftsID: true}, "keywords": map[string]bool{"$draft": true},
		"from": []Address{{Name: identity.Name, Email: identity.Email}}, "to": args.To, "cc": args.CC, "bcc": args.BCC, "subject": args.Subject,
		"bodyStructure": bodyStructure, "bodyValues": map[string]any{"text": map[string]any{"value": args.Body}, "html": map[string]any{"value": htmlBody}},
	}
	if mode == "reply" && original != nil && len(original.MessageID) > 0 {
		email["inReplyTo"] = original.MessageID
		email["references"] = append(append([]string{}, original.References...), original.MessageID...)
	}
	response, err := c.JMAP(ctx, jc, call{"Email/set", map[string]any{"accountId": jc.MailAccountID, "create": map[string]any{"draft": email}}, "set"})
	if err != nil {
		return "", "", fmt.Errorf("draft creation outcome is unknown; inspect Drafts before retrying: %w", err)
	}
	var result jmapSetResult
	if err := method(response, 0, &result); err != nil {
		return "", "", err
	}
	if failure, failed := result.NotCreated["draft"]; failed {
		return "", "", fmt.Errorf("draft was not created: %s", valueOr(failure.Description, valueOr(failure.Type, "request failed")))
	}
	id := result.Created["draft"].ID
	if id == "" {
		return "", "", errors.New("draft creation returned no email ID")
	}
	return id, identity.ID, nil
}

func (c *Client) sendDraft(ctx context.Context, jc *Context, draftID, identityID string) (any, error) {
	mailboxes, err := c.getMailboxes(ctx, jc)
	if err != nil {
		return nil, fmt.Errorf("submission was not attempted for draft %s because folders could not be inspected: %w", draftID, err)
	}
	var draftsID, sentID string
	for _, mailbox := range mailboxes {
		if mailbox.Role == nil {
			continue
		}
		switch *mailbox.Role {
		case "drafts":
			draftsID = mailbox.ID
		case "sent":
			sentID = mailbox.ID
		}
	}
	if draftsID == "" || sentID == "" {
		return nil, fmt.Errorf("submission was not attempted for draft %s because Drafts or Sent is unavailable", draftID)
	}
	patch := map[string]any{"keywords/$draft": nil}
	patch["mailboxIds/"+draftsID] = nil
	patch["mailboxIds/"+sentID] = true
	response, err := c.JMAP(ctx, jc, call{"EmailSubmission/set", map[string]any{
		"accountId": jc.SubmissionAccountID, "create": map[string]any{"send": map[string]any{"emailId": draftID, "identityId": identityID}},
		"onSuccessUpdateEmail": map[string]any{"#send": patch},
	}, "submit"})
	if err != nil {
		return nil, fmt.Errorf("submission outcome is unknown for draft %s; do not retry send_email automatically: %w", draftID, err)
	}
	var set jmapSetResult
	if err := method(response, 0, &set); err != nil {
		return nil, fmt.Errorf("submission failed for draft %s: %w", draftID, err)
	}
	if failure, failed := set.NotCreated["send"]; failed {
		return nil, fmt.Errorf("submission was rejected for draft %s: %s", draftID, valueOr(failure.Description, valueOr(failure.Type, "request failed")))
	}
	if created, ok := set.Created["send"]; !ok || created.ID == "" {
		return nil, fmt.Errorf("submission was not confirmed for draft %s; do not retry send_email automatically", draftID)
	}
	result := map[string]any{"emailId": draftID, "submissionId": set.Created["send"].ID}
	var filing jmapSetResult
	if err := method(response, 1, &filing); err != nil {
		result["warning"] = fmt.Sprintf("message submission was accepted, but filing could not be confirmed for draft %s; do not resend", draftID)
	} else if err := filing.requireUpdated([]string{draftID}); err != nil {
		result["warning"] = fmt.Sprintf("message submission was accepted, but filing failed for draft %s; do not resend: %v", draftID, err)
	}
	return result, nil
}
