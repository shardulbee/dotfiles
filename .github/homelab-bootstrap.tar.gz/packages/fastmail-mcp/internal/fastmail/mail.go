package fastmail

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"sort"
	"strings"
)

type Address struct {
	Name  string `json:"name,omitempty"`
	Email string `json:"email"`
}

type BodyPart struct {
	PartID      string     `json:"partId,omitempty"`
	BlobID      string     `json:"blobId,omitempty"`
	Name        string     `json:"name,omitempty"`
	Type        string     `json:"type,omitempty"`
	Size        int64      `json:"size,omitempty"`
	Disposition string     `json:"disposition,omitempty"`
	SubParts    []BodyPart `json:"subParts,omitempty"`
}

type BodyValue struct {
	Value             string `json:"value"`
	IsTruncated       bool   `json:"isTruncated"`
	IsEncodingProblem bool   `json:"isEncodingProblem"`
}

type emailReference struct {
	ID      string `json:"id"`
	Subject string `json:"subject"`
}

type Email struct {
	ID            string               `json:"id"`
	ThreadID      string               `json:"threadId"`
	MailboxIDs    map[string]bool      `json:"mailboxIds"`
	Keywords      map[string]bool      `json:"keywords"`
	Subject       string               `json:"subject"`
	ReceivedAt    string               `json:"receivedAt"`
	SentAt        string               `json:"sentAt"`
	From          []Address            `json:"from"`
	To            []Address            `json:"to"`
	CC            []Address            `json:"cc"`
	BCC           []Address            `json:"bcc"`
	ReplyTo       []Address            `json:"replyTo"`
	MessageID     []string             `json:"messageId"`
	InReplyTo     []string             `json:"inReplyTo"`
	References    []string             `json:"references"`
	Preview       string               `json:"preview"`
	BodyStructure *BodyPart            `json:"bodyStructure"`
	TextBody      []BodyPart           `json:"textBody"`
	HTMLBody      []BodyPart           `json:"htmlBody"`
	BodyValues    map[string]BodyValue `json:"bodyValues"`
}

type Mailbox struct {
	ID           string  `json:"id"`
	Name         string  `json:"name"`
	Role         *string `json:"role"`
	ParentID     *string `json:"parentId"`
	SortOrder    int     `json:"sortOrder"`
	TotalEmails  int     `json:"totalEmails"`
	UnreadEmails int     `json:"unreadEmails"`
}

type Folder struct {
	ID           string  `json:"id"`
	Name         string  `json:"name"`
	Path         string  `json:"path"`
	Role         *string `json:"role,omitempty"`
	ParentID     *string `json:"parentId"`
	TotalEmails  int     `json:"totalEmails"`
	UnreadEmails int     `json:"unreadEmails"`
}

type NativeIdentity struct {
	Email     string `json:"email"`
	Name      string `json:"name"`
	IsDefault bool   `json:"isDefault"`
}

type EmailFolder struct {
	ID   string  `json:"id"`
	Name string  `json:"name"`
	Path string  `json:"path"`
	Role *string `json:"role,omitempty"`
}

type NativeEmail struct {
	ID          string       `json:"id"`
	ThreadID    string       `json:"threadId"`
	MessageID   []string     `json:"messageId"`
	Subject     string       `json:"subject"`
	From        []Address    `json:"from"`
	To          []Address    `json:"to"`
	CC          any          `json:"cc"`
	BCC         *[]Address   `json:"bcc,omitempty"`
	ReplyTo     *[]Address   `json:"replyTo,omitempty"`
	ReceivedAt  string       `json:"receivedAt"`
	Preview     *string      `json:"preview,omitempty"`
	BodyText    *string      `json:"bodyText,omitempty"`
	IsRead      bool         `json:"isRead"`
	IsFlagged   bool         `json:"isFlagged"`
	IsAnswered  bool         `json:"isAnswered"`
	IsForwarded bool         `json:"isForwarded"`
	IsDraft     bool         `json:"isDraft"`
	Folder      *EmailFolder `json:"folder,omitempty"`
}

type Identity struct {
	ID            string    `json:"id"`
	Name          string    `json:"name"`
	Email         string    `json:"email"`
	ReplyTo       []Address `json:"replyTo"`
	BCC           []Address `json:"bcc"`
	TextSignature string    `json:"textSignature"`
	HTMLSignature string    `json:"htmlSignature"`
	MayDelete     bool      `json:"mayDelete"`
}

type Attachment struct {
	BlobID      string  `json:"blobId"`
	Name        *string `json:"name"`
	Type        *string `json:"type"`
	Size        *int64  `json:"size"`
	Disposition *string `json:"disposition"`
}

type SimpleEmail struct {
	ID          string          `json:"id"`
	ThreadID    string          `json:"threadId"`
	MailboxIDs  map[string]bool `json:"mailboxIds"`
	Keywords    map[string]bool `json:"keywords"`
	Subject     string          `json:"subject"`
	ReceivedAt  string          `json:"receivedAt"`
	SentAt      string          `json:"sentAt"`
	From        []string        `json:"from"`
	To          []string        `json:"to"`
	CC          []string        `json:"cc"`
	BCC         []string        `json:"bcc"`
	ReplyTo     []string        `json:"replyTo"`
	Attachments []Attachment    `json:"attachments"`
	Preview     *string         `json:"preview,omitempty"`
	Body        *EmailBody      `json:"body,omitempty"`
}

var addressPattern = regexp.MustCompile(`^(.*?)\s*<([^>]+)>$`)

func (c *Client) getMailboxes(ctx context.Context, jc *Context) ([]Mailbox, error) {
	response, err := c.JMAP(ctx, jc,
		call{"Mailbox/query", map[string]any{"accountId": jc.MailAccountID, "sort": []map[string]any{{"property": "sortOrder"}}}, "q"},
		call{"Mailbox/get", map[string]any{"accountId": jc.MailAccountID, "#ids": map[string]any{"resultOf": "q", "name": "Mailbox/query", "path": "/ids"}, "properties": []string{"id", "name", "role", "parentId", "sortOrder", "totalEmails", "unreadEmails"}}, "g"},
	)
	if err != nil {
		return nil, err
	}
	var result struct {
		List []Mailbox `json:"list"`
	}
	if err := method(response, 1, &result); err != nil {
		return nil, err
	}
	return nonNil(result.List), nil
}

func (c *Client) getIdentities(ctx context.Context, jc *Context) ([]Identity, error) {
	response, err := c.JMAP(ctx, jc, call{"Identity/get", map[string]any{
		"accountId":  jc.SubmissionAccountID,
		"properties": []string{"id", "name", "email", "replyTo", "bcc", "textSignature", "htmlSignature", "mayDelete"},
	}, "ids"})
	if err != nil {
		return nil, err
	}
	var result struct {
		List []Identity `json:"list"`
	}
	if err := method(response, 0, &result); err != nil {
		return nil, err
	}
	return nonNil(result.List), nil
}

// Only Fastmail Folders mode is supported. JMAP represents folders and labels
// identically and does not expose the UI preference, so this cannot be checked
// here. Select Folders in Fastmail Settings → Mail preferences before connecting.
func folders(mailboxes []Mailbox) []Folder {
	byID := map[string]Mailbox{}
	for _, mailbox := range mailboxes {
		byID[mailbox.ID] = mailbox
	}
	path := func(mailbox Mailbox) string {
		parts := []string{mailbox.Name}
		for mailbox.ParentID != nil {
			parent, ok := byID[*mailbox.ParentID]
			if !ok {
				break
			}
			parts = append([]string{parent.Name}, parts...)
			mailbox = parent
		}
		return strings.Join(parts, "/")
	}
	result := make([]Folder, 0, len(mailboxes))
	for _, mailbox := range mailboxes {
		result = append(result, Folder{ID: mailbox.ID, Name: mailbox.Name, Path: path(mailbox), Role: mailbox.Role, ParentID: mailbox.ParentID, TotalEmails: mailbox.TotalEmails, UnreadEmails: mailbox.UnreadEmails})
	}
	return result
}

func folderForEmail(email Email, all []Folder) *EmailFolder {
	for _, folder := range all {
		if email.MailboxIDs[folder.ID] {
			return &EmailFolder{ID: folder.ID, Name: folder.Name, Path: folder.Path, Role: folder.Role}
		}
	}
	return nil
}

func nativeAddresses(values []Address) any {
	if len(values) == 0 {
		return nil
	}
	return values
}

func nativeEmail(email Email, all []Folder, bodyText *string, includePreview, includeBCC, includeReplyTo bool) NativeEmail {
	result := NativeEmail{
		ID: email.ID, ThreadID: email.ThreadID, MessageID: nonNil(email.MessageID), Subject: email.Subject,
		From: nonNil(email.From), To: nonNil(email.To), CC: nativeAddresses(email.CC),
		ReceivedAt: valueOr(email.ReceivedAt, email.SentAt), IsRead: email.Keywords["$seen"], IsFlagged: email.Keywords["$flagged"],
		IsAnswered: email.Keywords["$answered"], IsForwarded: email.Keywords["$forwarded"], IsDraft: email.Keywords["$draft"], Folder: folderForEmail(email, all), BodyText: bodyText,
	}
	if includePreview {
		result.Preview = &email.Preview
	}
	if includeBCC {
		result.BCC = &email.BCC
	}
	if includeReplyTo {
		result.ReplyTo = &email.ReplyTo
	}
	return result
}

func (c *Client) emailGet(ctx context.Context, jc *Context, ids []string, bodyFormat string) ([]Email, error) {
	emails, err := c.emailGetChunks(ctx, jc, ids, bodyFormat)
	if err != nil || bodyFormat == "" {
		return emails, err
	}
	fallbackFormat := bodyFormatText
	if bodyFormat == bodyFormatText {
		fallbackFormat = bodyFormatHTML
	}
	var fallbackIDs []string
	for _, email := range emails {
		if bodyNeedsFallback(email, bodyFormat) {
			fallbackIDs = append(fallbackIDs, email.ID)
		}
	}
	if len(fallbackIDs) == 0 {
		return emails, nil
	}
	fallback, err := c.emailGetChunks(ctx, jc, fallbackIDs, fallbackFormat)
	if err != nil {
		return nil, err
	}
	byID := map[string]int{}
	for index, email := range emails {
		byID[email.ID] = index
	}
	for _, email := range fallback {
		index, ok := byID[email.ID]
		if !ok {
			return nil, fmt.Errorf("unexpected fallback email returned: %s", email.ID)
		}
		if emails[index].Subject != email.Subject || emails[index].ThreadID != email.ThreadID {
			return nil, fmt.Errorf("email changed while fetching body: %s", email.ID)
		}
		if len(emails[index].TextBody) == 0 {
			emails[index].TextBody = email.TextBody
		}
		if len(emails[index].HTMLBody) == 0 {
			emails[index].HTMLBody = email.HTMLBody
		}
		if emails[index].BodyValues == nil {
			emails[index].BodyValues = map[string]BodyValue{}
		}
		for partID, value := range email.BodyValues {
			emails[index].BodyValues[partID] = value
		}
	}
	return emails, nil
}

func (c *Client) emailGetChunks(ctx context.Context, jc *Context, ids []string, bodyFormat string) ([]Email, error) {
	chunkSize := len(ids)
	if bodyFormat != "" {
		chunkSize = 1
	}
	if chunkSize == 0 {
		return []Email{}, nil
	}
	emails := make([]Email, 0, len(ids))
	for start := 0; start < len(ids); start += chunkSize {
		end := start + chunkSize
		if end > len(ids) {
			end = len(ids)
		}
		chunk, err := c.emailGetChunk(ctx, jc, ids[start:end], bodyFormat)
		if err != nil {
			return nil, err
		}
		emails = append(emails, chunk...)
	}
	return emails, nil
}

func (c *Client) emailGetChunk(ctx context.Context, jc *Context, ids []string, bodyFormat string) ([]Email, error) {
	properties := []string{"id", "threadId", "mailboxIds", "keywords", "subject", "receivedAt", "sentAt", "from", "to", "cc", "bcc", "replyTo", "messageId", "inReplyTo", "references", "bodyStructure"}
	request := map[string]any{
		"accountId":      jc.MailAccountID,
		"ids":            ids,
		"properties":     properties,
		"bodyProperties": []string{"partId", "blobId", "name", "type", "size", "disposition", "subParts"},
	}
	if bodyFormat != "" {
		request["properties"] = append(properties, "preview", "textBody", "htmlBody", "bodyValues")
		request["maxBodyValueBytes"] = 10_000_000
		if bodyFormat == bodyFormatHTML {
			request["fetchHTMLBodyValues"] = true
		} else {
			request["fetchTextBodyValues"] = true
		}
	}
	response, err := c.JMAP(ctx, jc, call{"Email/get", request, "g"})
	if err != nil {
		return nil, err
	}
	var result struct {
		List     []Email  `json:"list"`
		NotFound []string `json:"notFound"`
	}
	if err := method(response, 0, &result); err != nil {
		return nil, err
	}
	if err := validateEmailResponseIDs(ids, result.List, result.NotFound); err != nil {
		return nil, err
	}
	return nonNil(result.List), nil
}

func (c *Client) emailMetadataGet(ctx context.Context, jc *Context, ids []string) ([]Email, error) {
	response, err := c.JMAP(ctx, jc, call{"Email/get", map[string]any{
		"accountId":  jc.MailAccountID,
		"ids":        ids,
		"properties": []string{"id", "threadId", "subject"},
	}, "g"})
	if err != nil {
		return nil, err
	}
	var result struct {
		List     []Email  `json:"list"`
		NotFound []string `json:"notFound"`
	}
	if err := method(response, 0, &result); err != nil {
		return nil, err
	}
	if err := validateEmailResponseIDs(ids, result.List, result.NotFound); err != nil {
		return nil, err
	}
	return nonNil(result.List), nil
}

func validateEmailResponseIDs(requested []string, emails []Email, notFound []string) error {
	if len(notFound) > 0 {
		return fmt.Errorf("email not found: %s", strings.Join(notFound, ", "))
	}
	expected := map[string]bool{}
	for _, id := range requested {
		expected[id] = true
	}
	seen := map[string]bool{}
	for _, email := range emails {
		if !expected[email.ID] {
			return fmt.Errorf("unexpected email returned: %s", email.ID)
		}
		if seen[email.ID] {
			return fmt.Errorf("duplicate email returned: %s", email.ID)
		}
		seen[email.ID] = true
	}
	for _, id := range unique(requested) {
		if !seen[id] {
			return fmt.Errorf("email not found: %s", id)
		}
	}
	return nil
}

func validateEmailSubjects(requested []emailReference, emails []Email) error {
	byID := map[string]Email{}
	for _, email := range emails {
		byID[email.ID] = email
	}
	for _, reference := range requested {
		email, ok := byID[reference.ID]
		if !ok {
			return fmt.Errorf("email not found: %s", reference.ID)
		}
		if email.Subject != reference.Subject {
			return fmt.Errorf("subject does not match email ID: %s", reference.ID)
		}
	}
	return nil
}

func validateThreadSubjects(requested []emailReference, emails []Email) error {
	for _, reference := range requested {
		matched := false
		for _, email := range emails {
			if email.ThreadID == reference.ID && email.Subject == reference.Subject {
				matched = true
				break
			}
		}
		if !matched {
			return fmt.Errorf("subject does not match thread ID: %s", reference.ID)
		}
	}
	return nil
}

func referenceIDs(references []emailReference) []string {
	ids := make([]string, 0, len(references))
	for _, reference := range references {
		ids = append(ids, reference.ID)
	}
	return unique(ids)
}

func simplifyEmail(email Email, bodyFormat string) SimpleEmail {
	attachments := []Attachment{}
	for _, part := range attachmentParts(email.BodyStructure) {
		name, typ, disposition := nullable(part.Name), nullable(part.Type), nullable(part.Disposition)
		var size *int64
		if part.Size != 0 {
			size = &part.Size
		}
		attachments = append(attachments, Attachment{BlobID: part.BlobID, Name: name, Type: typ, Size: size, Disposition: disposition})
	}
	result := SimpleEmail{
		ID: email.ID, ThreadID: email.ThreadID, MailboxIDs: email.MailboxIDs, Keywords: email.Keywords,
		Subject: email.Subject, ReceivedAt: email.ReceivedAt, SentAt: email.SentAt,
		From: simplifyAddresses(email.From), To: simplifyAddresses(email.To), CC: simplifyAddresses(email.CC), BCC: simplifyAddresses(email.BCC), ReplyTo: simplifyAddresses(email.ReplyTo), Attachments: attachments,
	}
	if bodyFormat != "" {
		body := emailBody(email, bodyFormat)
		result.Preview = &email.Preview
		result.Body = &body
	}
	return result
}

func attachmentParts(part *BodyPart) []BodyPart {
	if part == nil {
		return nil
	}
	var result []BodyPart
	if part.BlobID != "" && (part.Name != "" || strings.EqualFold(part.Disposition, "attachment")) {
		result = append(result, *part)
	}
	for index := range part.SubParts {
		result = append(result, attachmentParts(&part.SubParts[index])...)
	}
	return result
}

func simplifyAddresses(addresses []Address) []string {
	result := make([]string, 0, len(addresses))
	for _, item := range addresses {
		if item.Name != "" {
			result = append(result, fmt.Sprintf("%s <%s>", item.Name, item.Email))
		} else {
			result = append(result, item.Email)
		}
	}
	return result
}

func parseAddresses(input string) []Address {
	if input == "" {
		return []Address{}
	}
	var result []Address
	for _, value := range strings.Split(input, ",") {
		value = strings.TrimSpace(value)
		if match := addressPattern.FindStringSubmatch(value); match != nil {
			result = append(result, Address{Name: strings.TrimSpace(match[1]), Email: strings.TrimSpace(match[2])})
		} else if value != "" {
			result = append(result, Address{Email: value})
		}
	}
	return result
}

func safeName(name string) string {
	if name == "" {
		name = "attachment"
	}
	name = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 || strings.ContainsRune(`/\\?%*:|"<>`, r) {
			return '-'
		}
		return r
	}, name)
	name = strings.Join(strings.Fields(name), " ")
	name = strings.TrimSpace(name)
	if len(name) > 160 {
		name = name[:160]
	}
	if name == "" {
		return "attachment"
	}
	return name
}

func fillDownloadURL(template string, values map[string]string) string {
	for key, value := range values {
		encoded := strings.ReplaceAll(url.QueryEscape(value), "+", "%20")
		template = strings.ReplaceAll(template, "{"+key+"}", encoded)
	}
	return template
}

func unique(values []string) []string {
	seen := map[string]bool{}
	result := make([]string, 0, len(values))
	for _, value := range values {
		if !seen[value] {
			seen[value] = true
			result = append(result, value)
		}
	}
	return result
}

func nonNil[T any](values []T) []T {
	if values == nil {
		return []T{}
	}
	return values
}

func nullable(value string) *string {
	if value == "" {
		return nil
	}
	return &value
}

func marshalSize(value any) error {
	content, err := json.Marshal(value)
	if err != nil {
		return err
	}
	if len(content) > 36<<20 {
		return errors.New("tool result exceeds 36 MiB")
	}
	return nil
}

func sortEmails(emails []Email) {
	sort.Slice(emails, func(i, j int) bool {
		a := valueOr(emails[i].ReceivedAt, emails[i].SentAt)
		b := valueOr(emails[j].ReceivedAt, emails[j].SentAt)
		return a < b
	})
}
