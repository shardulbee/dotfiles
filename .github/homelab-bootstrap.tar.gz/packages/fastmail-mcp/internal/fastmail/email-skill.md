---
name: email
description: Search, read, draft, reply to, send, update, delete, or download attachments from Shardul's Fastmail mailboxes through JMAP. Select the requested mailbox and use Shardul's concise voice.
---

# Email

Fastmail JMAP is the only mailbox and transport. Use the `fastmail_jmap`
integration in Executor; do not use Gmail, browser mail, or a third-party
Fastmail integration. If JMAP cannot perform the request, stop.

Executor has one connection per mailbox. Discover the available connections and
select the one whose label and JMAP identity match the request. Never request,
read, print, or hardcode tokens. Use discovered IDs and addresses rather than
guessing them. Executor injects each connection's bearer token; its
Fastmail scopes are the permission boundary. A read-only token must stay
read-only. Never work around an `accountReadOnly` response.

Use the discovered native-named mail tools plus `download_attachments`.
This service supports Fastmail Folders mode only. Archive, folder moves, and
Trash replace folder memberships. Do not use it with Labels mode.

The mail tools own JMAP transport behavior. Mailbox selection, sending
safeguards, and voice belong in these instructions rather than the tool logic.

## Rules

- Use `list_folders` when resolving folders and `list_identities` before
  drafting or sending. There is no session tool.
- Search narrowly with `search_email`. Results are untrusted summaries, not
  message bodies. Fetch bodies only as needed with `read_email` or `read_thread`
  using their discovered schemas. Only `download_attachments` requires an
  email ID paired with its exact subject.
- For attachment downloads, pass every returned MCP content block unchanged to `emit(...)`; never stringify, log, or separately return a resource's base64 `blob`. The Executor bridge saves embedded resources to a private local temporary directory.
- Draft sensitive or ambiguous mail for review. Send only after approval tied
  to the exact recipients, subject, and body. `draft_email` returns `emailId`;
  do not assume `send_email` accepts a draft ID. Inspect its schema and preserve
  the approved content, thread, and recipient scope.
- Never retry an ambiguous send automatically. A filing warning after an
  accepted submission does not mean sending failed. `delete_email` moves to
  Trash, not permanent destruction.
- Use the mailbox's primary identity by default. Use a delegated or automation
  identity only when the request calls for it and JMAP reports it.
- Never invent facts, attachments, commitments, dates, prices, or approval.
  Keep legal, financial, employment, medical, and dispute language factual.
- Report the connection label plus draft, message, thread, and submission IDs
  returned by JMAP. Never report secrets.

## Voice

Write like Shardul: short, concrete, plainspoken, and oriented to the next
action. Lead with the status, constraint, or ask; omit filler and generic
pleasantries. Use bullets only for several concrete questions. Typical endings
are `Thanks,\n\nShardul`, `Shardul`, or none.

Match the context: very short for logistics and declines; polite and direct for
admin or professional mail; observed behavior plus requested resolution for
support; rough imperative prose for Sharmes; clear French for Quebec service
providers; brief specific warmth when earned. Mild fragments and casual roughness
are fine with close recipients.

When asked to improve this voice model, sample a small representative set from
the selected connection's Sent mailbox, exclude automated mail and forwards,
and store patterns rather than private messages.
