package fastmail

func objectSchema(properties map[string]any, required ...string) map[string]any {
	schema := map[string]any{"type": "object", "properties": properties}
	if len(required) > 0 {
		schema["required"] = required
	}
	return schema
}

func arraySchema(items any, min, max int) map[string]any {
	schema := map[string]any{"type": "array", "items": items}
	if min > 0 {
		schema["minItems"] = min
	}
	if max > 0 {
		schema["maxItems"] = max
	}
	return schema
}

func addressSchema() map[string]any {
	return map[string]any{"type": "object"}
}

func attachmentReferenceSchema() map[string]any {
	return objectSchema(map[string]any{
		"blobId":   map[string]any{"type": "string", "description": "From upload_attachment."},
		"name":     map[string]any{"type": "string", "description": "Filename to show the recipient."},
		"mimeType": map[string]any{"type": "string", "description": "MIME content type."},
	}, "blobId")
}

func composeInputSchema(draft bool) map[string]any {
	toDescription := "Recipients, e.g. [{\"name\": \"Jo\", \"email\": \"jo@example.com\"}]. Required for new emails. For replies, defaults to the original sender. For forwards, you must specify the new recipients."
	fromDescription := "Email address to send from. Must match a verified identity. If omitted, the best matching identity is used. Use list_identities to see available addresses."
	if draft {
		toDescription = "Recipients, e.g. [{\"name\": \"Jo\", \"email\": \"jo@example.com\"}]. For replies, defaults to the original sender (or all recipients if replyAll). For forwards, you must specify the new recipients."
		fromDescription = "Email address to send from. Must match a verified identity. For replies, defaults to the identity matching the original's recipient. Use list_identities to see available addresses."
	}
	to := arraySchema(addressSchema(), 0, 0)
	to["description"] = toDescription
	cc := arraySchema(addressSchema(), 0, 0)
	cc["description"] = "CC recipients, same format as 'to'"
	bcc := arraySchema(addressSchema(), 0, 0)
	bcc["description"] = "BCC recipients, same format as 'to'"
	attachments := arraySchema(attachmentReferenceSchema(), 0, 0)
	attachments["description"] = "File attachments. Call upload_attachment first for each file to obtain a blobId, then pass the returned objects here."
	return objectSchema(map[string]any{
		"to": to, "cc": cc, "bcc": bcc,
		"body":        map[string]any{"type": "string", "description": "Email body in markdown format. Converted to HTML automatically with the markdown kept as plain text alternative. For replies/forwards, this is your new text — the original message is quoted below automatically."},
		"subject":     map[string]any{"type": "string", "description": "Email subject. Defaults to 'Re: ...' for replies, 'Fwd: ...' for forwards."},
		"from":        map[string]any{"type": "string", "description": fromDescription},
		"attachments": attachments,
		"emailId":     map[string]any{"type": "string", "description": "Email ID of the message to reply to or forward. Required when mode is 'reply' or 'forward'."},
		"mode":        map[string]any{"type": "string", "enum": []string{"new", "reply", "forward"}, "description": "Compose mode: 'new' (default) for a fresh email, 'reply' to reply to an existing email, 'forward' to forward an existing email."},
		"replyAll":    map[string]any{"type": "boolean", "description": "When true with mode 'reply', reply to all original recipients (To and CC) instead of just the sender."},
	}, "body")
}

func searchInputSchema() map[string]any {
	return objectSchema(map[string]any{
		"query":  map[string]any{"type": "string", "description": "Gmail-style search string. Omit to list the most recent emails."},
		"cursor": map[string]any{"type": "string", "description": "Opaque pagination cursor from a previous response's `nextCursor`. Pass it together with the same `query` to fetch the next page. Omit for the first page."},
		"limit":  map[string]any{"type": "integer", "description": "Maximum number of results per page (default 10, max 50)"},
	})
}

func readInputSchema() map[string]any {
	return objectSchema(map[string]any{
		"id":                map[string]any{"type": "string", "description": "The email ID to retrieve"},
		"includeQuotedText": map[string]any{"type": "boolean", "description": "Return the raw body including the quoted reply chain. Defaults to false (quoted history stripped)."},
	}, "id")
}

func threadInputSchema() map[string]any {
	return objectSchema(map[string]any{"threadId": map[string]any{"type": "string", "description": "The thread ID to retrieve all messages for"}}, "threadId")
}

func idsInputSchema(description string) map[string]any {
	ids := arraySchema(map[string]any{"type": "string"}, 0, 0)
	ids["description"] = description
	return objectSchema(map[string]any{"ids": ids}, "ids")
}

func updateInputSchema() map[string]any {
	return objectSchema(map[string]any{
		"ids":       map[string]any{"type": "array", "items": map[string]any{"type": "string"}, "description": "Email IDs to update."},
		"isRead":    map[string]any{"type": "boolean", "description": "Set to true to mark as read, false to mark as unread."},
		"isFlagged": map[string]any{"type": "boolean", "description": "Set to true to star, false to unstar."},
		"folder":    map[string]any{"type": "string", "description": "Destination folder. Accepts an id, a full path (e.g. \"Work/Projects\"), role (e.g. \"inbox\" or \"junk\"), or a leaf name when unambiguous. Trash and Archive are rejected — use delete_email or archive_email for those. Sent/Drafts and other system folders are not valid destinations. Use list_folders to see available folders and their paths."},
	}, "ids")
}

func memoInputSchema() map[string]any {
	return objectSchema(map[string]any{
		"emailId": map[string]any{"type": "string", "description": "The email to attach the memo to."},
		"text":    map[string]any{"type": "string", "description": "Memo text (plain text). Empty string removes any existing memo."},
	}, "emailId", "text")
}

func uploadInputSchema() map[string]any {
	return objectSchema(map[string]any{
		"name":     map[string]any{"type": "string", "description": "Filename to show the recipient, e.g. \"report.pdf\"."},
		"data":     map[string]any{"type": "string", "description": "Base64-encoded file bytes."},
		"mimeType": map[string]any{"type": "string", "description": "MIME content type, e.g. \"application/pdf\". Defaults to \"application/octet-stream\" when omitted."},
	}, "name", "data")
}

func attachmentInputSchema() map[string]any {
	return objectSchema(map[string]any{"emails": arraySchema(emailReferenceSchema(), 1, 20)}, "emails")
}

func emailReferenceSchema() map[string]any {
	return objectSchema(map[string]any{
		"id":      map[string]any{"type": "string"},
		"subject": map[string]any{"type": "string", "description": "Exact subject returned by search_email, shown during approval and verified before download."},
	}, "id", "subject")
}
