package fastmail

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	Core       = "urn:ietf:params:jmap:core"
	Mail       = "urn:ietf:params:jmap:mail"
	Submission = "urn:ietf:params:jmap:submission"
	maxJSON    = 16 << 20
)

type Client struct {
	HTTP       *http.Client
	SessionURL string
	Token      func() (string, error)
}

type Session struct {
	APIURL          string                     `json:"apiUrl"`
	DownloadURL     string                     `json:"downloadUrl"`
	UploadURL       string                     `json:"uploadUrl"`
	PrimaryAccounts map[string]string          `json:"primaryAccounts"`
	Accounts        orderedAccounts            `json:"accounts"`
	Capabilities    map[string]json.RawMessage `json:"capabilities"`
}

type Account struct {
	Capabilities map[string]json.RawMessage `json:"accountCapabilities"`
}

type orderedAccounts struct {
	Values map[string]Account
	Order  []string
}

func (accounts *orderedAccounts) UnmarshalJSON(data []byte) error {
	decoder := json.NewDecoder(bytes.NewReader(data))
	token, err := decoder.Token()
	if err != nil {
		return err
	}
	if delimiter, ok := token.(json.Delim); !ok || delimiter != '{' {
		return errors.New("JMAP accounts must be an object")
	}
	accounts.Values = map[string]Account{}
	accounts.Order = nil
	for decoder.More() {
		key, err := decoder.Token()
		if err != nil {
			return err
		}
		id, ok := key.(string)
		if !ok {
			return errors.New("JMAP account ID must be a string")
		}
		var account Account
		if err := decoder.Decode(&account); err != nil {
			return err
		}
		accounts.Order = append(accounts.Order, id)
		accounts.Values[id] = account
	}
	_, err = decoder.Token()
	return err
}

type Context struct {
	Token               string
	Session             Session
	MailAccountID       string
	SubmissionAccountID string
}

type call struct {
	Name string
	Args any
	ID   string
}

type wireRequest struct {
	Using       []string `json:"using"`
	MethodCalls [][]any  `json:"methodCalls"`
}

type wireResponse struct {
	MethodResponses [][]json.RawMessage `json:"methodResponses"`
	CreatedIDs      map[string]string   `json:"createdIds,omitempty"`
	SessionState    string              `json:"sessionState,omitempty"`
}

type jmapSetError struct {
	Type        string `json:"type"`
	Description string `json:"description"`
}

type jmapSetResult struct {
	Created map[string]struct {
		ID string `json:"id"`
	} `json:"created"`
	NotCreated   map[string]jmapSetError `json:"notCreated"`
	Updated      map[string]any          `json:"updated"`
	NotUpdated   map[string]jmapSetError `json:"notUpdated"`
	Destroyed    []string                `json:"destroyed"`
	NotDestroyed map[string]jmapSetError `json:"notDestroyed"`
}

func (result jmapSetResult) requireUpdated(ids []string) error {
	for _, id := range unique(ids) {
		if _, ok := result.Updated[id]; !ok {
			if failure, failed := result.NotUpdated[id]; failed {
				return fmt.Errorf("email %s was not updated: %s", id, valueOr(failure.Description, valueOr(failure.Type, "request failed")))
			}
			return fmt.Errorf("email %s update was not confirmed", id)
		}
	}
	return nil
}

func (result jmapSetResult) requireDestroyed(ids []string) error {
	destroyed := map[string]bool{}
	for _, id := range result.Destroyed {
		destroyed[id] = true
	}
	for _, id := range unique(ids) {
		if !destroyed[id] {
			if failure, failed := result.NotDestroyed[id]; failed {
				return fmt.Errorf("email %s was not destroyed: %s", id, valueOr(failure.Description, valueOr(failure.Type, "request failed")))
			}
			return fmt.Errorf("email %s destruction was not confirmed", id)
		}
	}
	return nil
}

func NewClient() *Client {
	return &Client{
		HTTP:       &http.Client{Timeout: 25 * time.Second},
		SessionURL: envOr("FASTMAIL_JMAP_SESSION_URL", "https://api.fastmail.com/jmap/session"),
		Token:      readToken,
	}
}

// ForRequest uses an Executor connection's Bearer credential as the JMAP token.
// Without an Authorization header, the configured environment/token file remains
// the fallback for standalone deployments.
func (c *Client) ForRequest(request *http.Request) *Client {
	copy := *c
	authorization := request.Header.Get("Authorization")
	if authorization == "" {
		return &copy
	}
	scheme, token, found := strings.Cut(authorization, " ")
	token = strings.TrimSpace(token)
	if found && strings.EqualFold(scheme, "Bearer") && token != "" {
		copy.Token = func() (string, error) { return token, nil }
	} else {
		copy.Token = func() (string, error) {
			return "", errors.New("Authorization must contain a non-empty Bearer token")
		}
	}
	return &copy
}

func readToken() (string, error) {
	if token := strings.TrimSpace(os.Getenv("FASTMAIL_JMAP_TOKEN")); token != "" {
		return token, nil
	}
	path := os.Getenv("FASTMAIL_JMAP_TOKEN_FILE")
	if path == "" {
		return "", errors.New("set FASTMAIL_JMAP_TOKEN or FASTMAIL_JMAP_TOKEN_FILE")
	}
	file, err := os.Open(path)
	if err != nil {
		return "", fmt.Errorf("read token file: %w", err)
	}
	defer file.Close()
	content, err := io.ReadAll(io.LimitReader(file, (64<<10)+1))
	if err != nil {
		return "", fmt.Errorf("read token file: %w", err)
	}
	if len(content) > 64<<10 {
		return "", errors.New("token file exceeds 64 KiB")
	}
	token := strings.TrimSpace(string(content))
	if token == "" {
		return "", fmt.Errorf("no token found at %s", path)
	}
	return token, nil
}

func (c *Client) LoadContext(ctx context.Context) (*Context, error) {
	token, err := c.Token()
	if err != nil {
		return nil, err
	}
	var session Session
	if err := c.fetchJSON(ctx, http.MethodGet, c.SessionURL, token, nil, &session); err != nil {
		return nil, err
	}
	mailID := session.PrimaryAccounts[Mail]
	if mailID == "" {
		for _, id := range session.Accounts.Order {
			if _, ok := session.Accounts.Values[id].Capabilities[Mail]; ok {
				mailID = id
				break
			}
		}
	}
	if mailID == "" {
		return nil, errors.New("no JMAP mail account found")
	}
	submissionID := session.PrimaryAccounts[Submission]
	if submissionID == "" {
		for _, id := range session.Accounts.Order {
			if _, ok := session.Accounts.Values[id].Capabilities[Submission]; ok {
				submissionID = id
				break
			}
		}
	}
	if submissionID == "" {
		submissionID = mailID
	}
	return &Context{Token: token, Session: session, MailAccountID: mailID, SubmissionAccountID: submissionID}, nil
}

func (c *Client) JMAP(ctx context.Context, jc *Context, calls ...call) (*wireResponse, error) {
	using := map[string]bool{Core: true}
	wireCalls := make([][]any, 0, len(calls))
	for _, item := range calls {
		if strings.HasPrefix(item.Name, "Identity/") || strings.HasPrefix(item.Name, "EmailSubmission/") {
			if _, ok := jc.Session.Capabilities[Submission]; !ok {
				return nil, errors.New("JMAP session does not advertise submission capability; use a token/client that supports JMAP submission")
			}
			using[Submission] = true
			using[Mail] = true
		} else {
			using[Mail] = true
		}
		wireCalls = append(wireCalls, []any{item.Name, item.Args, item.ID})
	}
	capabilities := []string{Core}
	if using[Mail] {
		capabilities = append(capabilities, Mail)
	}
	if using[Submission] {
		capabilities = append(capabilities, Submission)
	}
	var response wireResponse
	if err := c.fetchJSON(ctx, http.MethodPost, jc.Session.APIURL, jc.Token, wireRequest{Using: capabilities, MethodCalls: wireCalls}, &response); err != nil {
		return nil, err
	}
	return &response, nil
}

func method(response *wireResponse, index int, out any) error {
	if index >= len(response.MethodResponses) || len(response.MethodResponses[index]) < 2 {
		return errors.New("missing JMAP method response")
	}
	var name string
	if err := json.Unmarshal(response.MethodResponses[index][0], &name); err != nil {
		return err
	}
	if name == "error" {
		var detail struct {
			Type        string `json:"type"`
			Description string `json:"description"`
		}
		_ = json.Unmarshal(response.MethodResponses[index][1], &detail)
		return fmt.Errorf("JMAP %s: %s", valueOr(detail.Type, "error"), valueOr(detail.Description, "request failed"))
	}
	return json.Unmarshal(response.MethodResponses[index][1], out)
}

func (c *Client) fetchJSON(ctx context.Context, methodName, url, token string, body, out any) error {
	var reader io.Reader
	if body != nil {
		encoded, err := json.Marshal(body)
		if err != nil {
			return err
		}
		reader = bytes.NewReader(encoded)
	}
	request, err := http.NewRequestWithContext(ctx, methodName, url, reader)
	if err != nil {
		return err
	}
	request.Header.Set("Authorization", "Bearer "+token)
	if body != nil {
		request.Header.Set("Content-Type", "application/json")
	}
	response, err := c.HTTP.Do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	content, err := io.ReadAll(io.LimitReader(response.Body, maxJSON+1))
	if err != nil {
		return err
	}
	if len(content) > maxJSON {
		return fmt.Errorf("JMAP response exceeds %d bytes", maxJSON)
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return fmt.Errorf("%s %s failed: %s: %s", methodName, url, response.Status, content)
	}
	if len(content) == 0 {
		content = []byte("{}")
	}
	if err := json.Unmarshal(content, out); err != nil {
		return fmt.Errorf("decode JMAP response: %w", err)
	}
	return nil
}

func envOr(name, fallback string) string {
	if value := os.Getenv(name); value != "" {
		return value
	}
	return fallback
}

func valueOr(value, fallback string) string {
	if value != "" {
		return value
	}
	return fallback
}
