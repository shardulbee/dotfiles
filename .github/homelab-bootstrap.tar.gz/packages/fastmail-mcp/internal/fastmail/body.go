package fastmail

import (
	"strings"
	"unicode"
	"unicode/utf8"

	nethtml "golang.org/x/net/html"
)

const (
	bodyFormatText = "text"
	bodyFormatHTML = "html"
)

type EmailBody struct {
	Content           string `json:"content"`
	Format            string `json:"format"`
	SourceType        string `json:"sourceType"`
	IsTruncated       bool   `json:"isTruncated"`
	IsEncodingProblem bool   `json:"isEncodingProblem"`
}

func bodyNeedsFallback(email Email, format string) bool {
	parts, fallback := email.TextBody, email.HTMLBody
	keepHTML := false
	if format == bodyFormatHTML {
		parts, fallback = email.HTMLBody, email.TextBody
		keepHTML = true
	}
	content, _, _, _ := renderBodyParts(parts, email.BodyValues, keepHTML)
	if content == "" && keepHTML {
		content, _, _, _ = renderBodyParts(parts, email.BodyValues, false)
	}
	if content != "" {
		return false
	}
	for _, part := range fallback {
		if strings.EqualFold(part.Type, "text/plain") || strings.EqualFold(part.Type, "text/html") {
			return true
		}
	}
	return false
}

func emailBody(email Email, format string) EmailBody {
	if format == bodyFormatHTML {
		content, sourceType, truncated, encodingProblem := renderBodyParts(email.HTMLBody, email.BodyValues, true)
		if content != "" {
			return EmailBody{Content: content, Format: bodyFormatHTML, SourceType: sourceType, IsTruncated: truncated, IsEncodingProblem: encodingProblem}
		}
		content, sourceType, fallbackTruncated, fallbackEncodingProblem := renderBodyParts(email.HTMLBody, email.BodyValues, false)
		truncated = truncated || fallbackTruncated
		encodingProblem = encodingProblem || fallbackEncodingProblem
		if content == "" {
			content, sourceType, fallbackTruncated, fallbackEncodingProblem = renderBodyParts(email.TextBody, email.BodyValues, false)
			truncated = truncated || fallbackTruncated
			encodingProblem = encodingProblem || fallbackEncodingProblem
		}
		return EmailBody{Content: content, Format: bodyFormatText, SourceType: sourceType, IsTruncated: truncated, IsEncodingProblem: encodingProblem}
	}

	content, sourceType, truncated, encodingProblem := renderBodyParts(email.TextBody, email.BodyValues, false)
	if content == "" {
		content, sourceType, fallbackTruncated, fallbackEncodingProblem := renderBodyParts(email.HTMLBody, email.BodyValues, false)
		truncated = truncated || fallbackTruncated
		encodingProblem = encodingProblem || fallbackEncodingProblem
		return EmailBody{Content: content, Format: bodyFormatText, SourceType: sourceType, IsTruncated: truncated, IsEncodingProblem: encodingProblem}
	}
	return EmailBody{Content: content, Format: bodyFormatText, SourceType: sourceType, IsTruncated: truncated, IsEncodingProblem: encodingProblem}
}

func renderBodyParts(parts []BodyPart, values map[string]BodyValue, keepHTML bool) (string, string, bool, bool) {
	seen := map[string]bool{}
	sourceTypes := map[string]bool{}
	var content []string
	var truncated, encodingProblem bool
	for _, part := range parts {
		if part.PartID == "" || seen[part.PartID] {
			continue
		}
		seen[part.PartID] = true
		value, ok := values[part.PartID]
		if !ok {
			continue
		}
		var rendered string
		switch {
		case strings.EqualFold(part.Type, "text/plain"):
			if keepHTML {
				continue
			}
			rendered = normalizePlainText(value.Value)
		case strings.EqualFold(part.Type, "text/html"):
			if keepHTML {
				rendered = strings.TrimSpace(value.Value)
			} else {
				rendered = htmlToText(value.Value)
			}
		default:
			continue
		}
		truncated = truncated || value.IsTruncated
		encodingProblem = encodingProblem || value.IsEncodingProblem
		if rendered == "" {
			continue
		}
		content = append(content, rendered)
		sourceTypes[strings.ToLower(part.Type)] = true
	}
	joined := strings.Join(content, "\n\n")
	if !keepHTML {
		joined = normalizePlainText(joined)
	}
	sourceType := ""
	if len(sourceTypes) == 1 {
		for value := range sourceTypes {
			sourceType = value
		}
	} else if len(sourceTypes) > 1 {
		sourceType = "mixed"
	}
	return joined, sourceType, truncated, encodingProblem
}

func normalizePlainText(value string) string {
	value = strings.ReplaceAll(value, "\r\n", "\n")
	value = strings.ReplaceAll(value, "\r", "\n")
	value = strings.Map(func(r rune) rune {
		if r == '\n' || r == '\t' {
			return r
		}
		if r == '\u200b' || r == '\ufeff' || unicode.IsControl(r) {
			return -1
		}
		return r
	}, value)
	lines := strings.Split(value, "\n")
	cleaned := make([]string, 0, len(lines))
	blank := false
	for _, line := range lines {
		line = strings.TrimRightFunc(line, unicode.IsSpace)
		if strings.TrimSpace(line) == "" {
			if len(cleaned) == 0 || blank {
				continue
			}
			blank = true
			cleaned = append(cleaned, "")
			continue
		}
		blank = false
		cleaned = append(cleaned, line)
	}
	for len(cleaned) > 0 && cleaned[len(cleaned)-1] == "" {
		cleaned = cleaned[:len(cleaned)-1]
	}
	return strings.Join(cleaned, "\n")
}

func stripQuotedText(value string) string {
	lines := strings.Split(normalizePlainText(value), "\n")
	for index, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, ">") || strings.EqualFold(trimmed, "-----Original Message-----") ||
			(strings.HasPrefix(trimmed, "On ") && strings.HasSuffix(trimmed, " wrote:")) {
			return normalizePlainText(strings.Join(lines[:index], "\n"))
		}
	}
	return normalizePlainText(value)
}

func htmlToText(value string) string {
	document, err := nethtml.Parse(strings.NewReader(value))
	if err != nil {
		return normalizePlainText(value)
	}
	var output strings.Builder
	var walk func(*nethtml.Node, bool)
	walk = func(node *nethtml.Node, preserveWhitespace bool) {
		if node.Type == nethtml.TextNode {
			if preserveWhitespace {
				output.WriteString(node.Data)
			} else {
				appendHTMLText(&output, node.Data)
			}
			return
		}
		if node.Type != nethtml.ElementNode {
			for child := node.FirstChild; child != nil; child = child.NextSibling {
				walk(child, preserveWhitespace)
			}
			return
		}
		tag := strings.ToLower(node.Data)
		if tag == "script" || tag == "style" || tag == "head" || tag == "title" || tag == "template" || tag == "noscript" || tag == "svg" || tag == "canvas" || hiddenHTMLNode(node) {
			return
		}
		switch tag {
		case "br":
			output.WriteByte('\n')
			return
		case "img":
			if !trackingImage(node) {
				if alt := strings.TrimSpace(htmlAttribute(node, "alt")); alt != "" {
					output.WriteString(alt)
				}
			}
			return
		case "a":
			start := output.Len()
			for child := node.FirstChild; child != nil; child = child.NextSibling {
				walk(child, preserveWhitespace)
			}
			label := strings.TrimSpace(output.String()[start:])
			href := strings.TrimSpace(htmlAttribute(node, "href"))
			lower := strings.ToLower(href)
			if len(href) <= 2048 && (strings.HasPrefix(lower, "https://") || strings.HasPrefix(lower, "http://") || strings.HasPrefix(lower, "mailto:")) {
				comparable := strings.TrimPrefix(href, "mailto:")
				if label == "" {
					output.WriteString(comparable)
				} else if label != href && label != comparable {
					output.WriteString(" <")
					output.WriteString(href)
					output.WriteByte('>')
				}
			}
			return
		case "hr":
			output.WriteString("\n---\n")
			return
		case "li":
			output.WriteString("\n- ")
		case "td", "th":
			for previous := node.PrevSibling; previous != nil; previous = previous.PrevSibling {
				if previous.Type == nethtml.ElementNode && (strings.EqualFold(previous.Data, "td") || strings.EqualFold(previous.Data, "th")) {
					output.WriteString(" | ")
					break
				}
			}
		case "p", "div", "section", "article", "header", "footer", "main", "nav", "aside", "blockquote", "pre", "table", "tr", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6":
			output.WriteByte('\n')
		}
		for child := node.FirstChild; child != nil; child = child.NextSibling {
			walk(child, preserveWhitespace || tag == "pre")
		}
		switch tag {
		case "p", "div", "section", "article", "header", "footer", "main", "nav", "aside", "blockquote", "pre", "table", "tr", "ul", "ol", "li", "h1", "h2", "h3", "h4", "h5", "h6":
			output.WriteByte('\n')
		}
	}
	walk(document, false)
	return normalizePlainText(output.String())
}

func appendHTMLText(output *strings.Builder, value string) {
	fields := strings.Fields(value)
	if len(fields) == 0 {
		appendHTMLSpace(output)
		return
	}
	first, _ := utf8.DecodeRuneInString(value)
	last, _ := utf8.DecodeLastRuneInString(value)
	if unicode.IsSpace(first) {
		appendHTMLSpace(output)
	}
	for index, field := range fields {
		if index > 0 {
			appendHTMLSpace(output)
		}
		output.WriteString(field)
	}
	if unicode.IsSpace(last) {
		appendHTMLSpace(output)
	}
}

func appendHTMLSpace(output *strings.Builder) {
	value := output.String()
	if value == "" {
		return
	}
	last := value[len(value)-1]
	if last != ' ' && last != '\n' && last != '\t' {
		output.WriteByte(' ')
	}
}

func hiddenHTMLNode(node *nethtml.Node) bool {
	if htmlAttribute(node, "hidden") != "" || strings.EqualFold(strings.TrimSpace(htmlAttribute(node, "aria-hidden")), "true") {
		return true
	}
	style := strings.NewReplacer(" ", "", "\t", "", "\n", "").Replace(strings.ToLower(htmlAttribute(node, "style")))
	for _, marker := range []string{"display:none", "visibility:hidden", "mso-hide:all", "font-size:0", "max-height:0"} {
		if strings.Contains(style, marker) {
			return true
		}
	}
	return false
}

func trackingImage(node *nethtml.Node) bool {
	width := strings.TrimSpace(htmlAttribute(node, "width"))
	height := strings.TrimSpace(htmlAttribute(node, "height"))
	return width == "0" || width == "1" || height == "0" || height == "1" || hiddenHTMLNode(node)
}

func htmlAttribute(node *nethtml.Node, name string) string {
	for _, attribute := range node.Attr {
		if strings.EqualFold(attribute.Key, name) {
			if name == "hidden" && attribute.Val == "" {
				return "hidden"
			}
			return attribute.Val
		}
	}
	return ""
}
