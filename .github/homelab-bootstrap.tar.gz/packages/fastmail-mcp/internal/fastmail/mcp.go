package fastmail

import (
	"context"
	_ "embed"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

const (
	MaxAttachmentBytes = 25 << 20
	toolTimeout        = 25 * time.Second
	bodyToolTimeout    = 2 * time.Minute
)

//go:embed email-skill.md
var emailSkill string

type emptyArgs struct{}

type AttachmentArgs struct {
	Emails []emailReference `json:"emails"`
}

type threadRecord struct {
	ID       string   `json:"id"`
	EmailIDs []string `json:"emailIds"`
}

func annotations(readOnly, idempotent, openWorld bool) *mcp.ToolAnnotations {
	return &mcp.ToolAnnotations{ReadOnlyHint: readOnly, IdempotentHint: idempotent, OpenWorldHint: &openWorld}
}

func addTool[Args any](server *mcp.Server, tool *mcp.Tool, handler func(context.Context, *Args) (any, error)) {
	mcp.AddTool(server, tool, func(ctx context.Context, _ *mcp.CallToolRequest, args *Args) (*mcp.CallToolResult, any, error) {
		value, err := handler(ctx, args)
		if err != nil {
			return nil, nil, err
		}
		return structured(value)
	})
}

func NewMCP(client *Client) *mcp.Server {
	server := mcp.NewServer(&mcp.Implementation{Name: "fastmail-jmap", Version: "5.0.0"}, nil)

	addTool(server, &mcp.Tool{Name: "skill", Description: "Return the canonical instructions for using this Fastmail JMAP integration and writing email as Shardul.", Annotations: annotations(true, true, false), InputSchema: objectSchema(map[string]any{})}, func(context.Context, *emptyArgs) (any, error) {
		return map[string]string{"content": emailSkill}, nil
	})

	addTool(server, &mcp.Tool{Name: "list_folders", Description: "List all mailbox folders. Returns id, name, path (slash-separated full path from root, e.g. \"Work/Projects\"), role (e.g. inbox, drafts, sent, trash, junk, archive), parentId, totalEmails, and unreadEmails for each folder. Use the path with update_email to disambiguate when leaf names clash. For Trash and Archive, use delete_email or archive_email.", Annotations: annotations(true, true, false), InputSchema: objectSchema(map[string]any{})}, func(ctx context.Context, _ *emptyArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		mailboxes, err := client.getMailboxes(ctx, jc)
		return map[string]any{"items": folders(mailboxes)}, err
	})

	addTool(server, &mcp.Tool{Name: "list_identities", Description: "List the user's verified sending identities (from addresses). Use this to discover which email addresses are available for sending.", Annotations: annotations(true, true, false), InputSchema: objectSchema(map[string]any{})}, func(ctx context.Context, _ *emptyArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		identities, err := client.getIdentities(ctx, jc)
		if err != nil {
			return nil, err
		}
		defaultIdentity, _ := selectIdentity(identities, "")
		items := make([]NativeIdentity, 0, len(identities))
		for _, identity := range identities {
			items = append(items, NativeIdentity{Email: identity.Email, Name: identity.Name, IsDefault: identity.ID == defaultIdentity.ID})
		}
		return map[string]any{"items": items}, nil
	})

	addTool(server, &mcp.Tool{Name: "search_email", Description: "Search the user's mailbox with a Gmail-style search string. Returns an object { results, hasMore, nextCursor }: `results` is an array of email summaries with id, threadId, messageId, subject, from, to, receivedAt, preview, isRead/isFlagged/isAnswered/isForwarded/isDraft, and folder (object {id,name,path,role?}). Omit `query` to list the most recent emails. When `hasMore` is true a `nextCursor` is returned; call again with the same `query` plus that `cursor` to get the next page. Prefer refining the query (add from:/after:/in:) over paging deeply. Supported qualifiers: from to cc bcc with subject body text in before after is has. Extensions over Gmail: `me` expands to verified sending identities; plain names on address fields look up the contact's emails; `with:` matches any address field; `in:` accepts a mailbox id, name, or role; relative dates `7d`/`1w`/`3m`/`1y` plus `today`/`yesterday`/`tomorrow`.", Annotations: annotations(true, true, false), InputSchema: searchInputSchema()}, func(ctx context.Context, args *SearchEmailArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.searchEmail(ctx, jc, *args)
	})

	addTool(server, &mcp.Tool{Name: "read_email", Description: "Get the full content of a single email by ID. Returns id, threadId, messageId, subject, from, to, cc, replyTo, receivedAt, bodyText, isRead/isFlagged/isAnswered/isForwarded/isDraft, and folder (object {id,name,path,role?}). By default the quoted reply chain is stripped from bodyText so you see only this message's new content; pass includeQuotedText to get the raw body with the quoted original intact.", Annotations: annotations(true, true, false), InputSchema: readInputSchema()}, func(ctx context.Context, args *ReadEmailArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, bodyToolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.readEmail(ctx, jc, *args)
	})

	addTool(server, &mcp.Tool{Name: "read_thread", Description: "Get all emails in a thread by thread ID. Returns an array of emails (like read_email) sorted by receivedAt, each with id, threadId, messageId, subject, from, to, cc, replyTo, receivedAt, bodyText, isRead/isFlagged/isAnswered/isForwarded/isDraft, and folder. To keep the thread compact, each bodyText has its quoted reply chain stripped (replies repeat the history down the thread) and is truncated if very long — call read_email for one message's full content.", Annotations: annotations(true, true, false), InputSchema: threadInputSchema()}, func(ctx context.Context, args *ReadThreadArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, bodyToolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		emails, err := client.readThread(ctx, jc, args.ThreadID)
		return map[string]any{"items": emails}, err
	})

	addTool(server, &mcp.Tool{Name: "draft_email", Description: "Create a draft email in the Drafts folder (not sent). Supports composing new messages, replies, and forwards via the mode parameter. Threading headers and original message quoting are handled automatically for replies and forwards. Returns the draft email ID.", Annotations: annotations(false, false, false), InputSchema: composeInputSchema(true)}, func(ctx context.Context, args *ComposeArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, bodyToolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		id, _, err := client.composeEmail(ctx, jc, *args)
		return map[string]any{"emailId": id}, err
	})

	addTool(server, &mcp.Tool{Name: "send_email", Description: "Send an email immediately. Supports composing new messages, replies, and forwards via the mode parameter. Threading headers and original message quoting are handled automatically for replies and forwards.", Annotations: annotations(false, false, true), InputSchema: composeInputSchema(false)}, func(ctx context.Context, args *ComposeArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, bodyToolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		id, identityID, err := client.composeEmail(ctx, jc, *args)
		if err != nil {
			return nil, err
		}
		sent, err := client.sendDraft(ctx, jc, id, identityID)
		if err != nil {
			return nil, err
		}
		return sent, nil
	})

	addTool(server, &mcp.Tool{Name: "archive_email", Description: "Archive one or more emails by moving them to the Archive folder. This service supports Folders mode only.", Annotations: annotations(false, true, false), InputSchema: idsInputSchema("Email IDs to archive")}, func(ctx context.Context, args *IDsArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.moveEmailsToRole(ctx, jc, args.IDs, "archive")
	})

	deleteAnnotations := annotations(false, true, false)
	destructive := false
	deleteAnnotations.DestructiveHint = &destructive
	addTool(server, &mcp.Tool{Name: "delete_email", Description: "Move one or more emails to the Trash folder.", Annotations: deleteAnnotations, InputSchema: idsInputSchema("Email IDs to move to Trash")}, func(ctx context.Context, args *IDsArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.moveEmailsToRole(ctx, jc, args.IDs, "trash")
	})

	addTool(server, &mcp.Tool{Name: "update_email", Description: "Mark emails read or flagged and optionally move them to one folder. This service supports Folders mode only. Use delete_email for Trash and archive_email for Archive.", Annotations: annotations(false, true, false), InputSchema: updateInputSchema()}, func(ctx context.Context, args *UpdateEmailArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.updateEmails(ctx, jc, *args)
	})

	addTool(server, &mcp.Tool{Name: "set_memo", Description: "Add, update, or remove a personal memo attached to an email. A memo is a private note the user has written to themselves about an email — it shows up alongside the email in the Fastmail web UI and in the user's Memos folder. Pass non-empty `text` to add or replace the memo (any existing memo is replaced). Pass empty string to remove the memo.", Annotations: annotations(false, true, false), InputSchema: memoInputSchema()}, func(ctx context.Context, args *MemoArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, toolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.setMemo(ctx, jc, *args)
	})

	addTool(server, &mcp.Tool{Name: "upload_attachment", Description: "Upload a file as an attachment to use with draft_email or send_email. Returns { blobId, name, mimeType, size }; pass that object back in the compose tool's `attachments` array. Call this once per file before composing; multiple uploads can run in parallel.", Annotations: annotations(false, false, false), InputSchema: uploadInputSchema()}, func(ctx context.Context, args *UploadArgs) (any, error) {
		ctx, cancel := context.WithTimeout(ctx, bodyToolTimeout)
		defer cancel()
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, err
		}
		return client.upload(ctx, jc, *args)
	})

	mcp.AddTool(server, &mcp.Tool{Name: "download_attachments", Description: "Download every attachment from selected emails after verifying each approval-visible subject. This custom extension has no native Fastmail equivalent.", Annotations: annotations(true, true, false), InputSchema: attachmentInputSchema()}, func(ctx context.Context, _ *mcp.CallToolRequest, args *AttachmentArgs) (*mcp.CallToolResult, any, error) {
		ctx, cancel := context.WithTimeout(ctx, bodyToolTimeout)
		defer cancel()
		if len(args.Emails) < 1 || len(args.Emails) > 20 {
			return nil, nil, fmt.Errorf("emails must contain 1..20 references")
		}
		jc, err := client.LoadContext(ctx)
		if err != nil {
			return nil, nil, err
		}
		ids := referenceIDs(args.Emails)
		metadata, err := client.emailMetadataGet(ctx, jc, ids)
		if err != nil {
			return nil, nil, err
		}
		if err := validateEmailSubjects(args.Emails, metadata); err != nil {
			return nil, nil, err
		}
		emails, err := client.emailGet(ctx, jc, ids, "")
		if err != nil {
			return nil, nil, err
		}
		byID := map[string]Email{}
		for _, email := range emails {
			byID[email.ID] = email
		}
		if err := validateEmailSubjects(args.Emails, emails); err != nil {
			return nil, nil, err
		}
		content := []mcp.Content{}
		downloaded := []map[string]any{}
		total := 0
		for _, id := range ids {
			email, ok := byID[id]
			if !ok {
				return nil, nil, fmt.Errorf("email not found: %s", id)
			}
			for index, part := range attachmentParts(email.BodyStructure) {
				name := safeName(part.Name)
				if part.Name == "" {
					name = fmt.Sprintf("%s-%d.bin", email.ID, index+1)
				}
				mimeType := valueOr(part.Type, "application/octet-stream")
				downloadURL := fillDownloadURL(jc.Session.DownloadURL, map[string]string{"accountId": jc.MailAccountID, "blobId": part.BlobID, "name": name, "type": mimeType})
				request, err := http.NewRequestWithContext(ctx, http.MethodGet, downloadURL, nil)
				if err != nil {
					return nil, nil, err
				}
				request.Header.Set("Authorization", "Bearer "+jc.Token)
				response, err := client.HTTP.Do(request)
				if err != nil {
					return nil, nil, err
				}
				bytes, readErr := io.ReadAll(io.LimitReader(response.Body, int64(MaxAttachmentBytes-total+1)))
				response.Body.Close()
				if response.StatusCode < 200 || response.StatusCode >= 300 {
					return nil, nil, fmt.Errorf("download failed: %s", response.Status)
				}
				if readErr != nil {
					return nil, nil, readErr
				}
				total += len(bytes)
				if total > MaxAttachmentBytes {
					return nil, nil, fmt.Errorf("attachment download exceeds the %d byte limit", MaxAttachmentBytes)
				}
				uri := fmt.Sprintf("fastmail-attachment:///%s?email=%s&part=%d", urlComponent(name), urlComponent(email.ID), index+1)
				content = append(content, &mcp.EmbeddedResource{Resource: &mcp.ResourceContents{URI: uri, MIMEType: mimeType, Blob: bytes}})
				downloaded = append(downloaded, map[string]any{"emailId": email.ID, "subject": email.Subject, "attachmentName": name, "mimeType": mimeType, "size": len(bytes)})
			}
		}
		summary := map[string]any{"attachmentCount": len(downloaded), "attachments": downloaded}
		text, _ := json.Marshal(summary)
		content = append([]mcp.Content{&mcp.TextContent{Text: string(text)}}, content...)
		result := &mcp.CallToolResult{Content: content, StructuredContent: summary}
		if err := marshalSize(result); err != nil {
			return nil, nil, err
		}
		return result, nil, nil
	})
	return server
}

func structured(value any) (*mcp.CallToolResult, any, error) {
	if err := marshalSize(value); err != nil {
		return nil, nil, err
	}
	content, err := json.Marshal(value)
	if err != nil {
		return nil, nil, err
	}
	return &mcp.CallToolResult{Content: []mcp.Content{&mcp.TextContent{Text: string(content)}}, StructuredContent: value}, nil, nil
}

func urlComponent(value string) string {
	return fillDownloadURL("{value}", map[string]string{"value": value})
}
