{
  buildGoModule,
  sqlite,
}:
buildGoModule {
  pname = "knowledge-mcp";
  version = "1.0.0";
  src = ./.;
  vendorHash = "sha256-/Yma+zAgzlRzhlallfU+6qZ0NWWaDovceYOlPHg0sjI=";
  buildInputs = [ sqlite ];
  tags = [ "libsqlite3" ];
  subPackages = [ "." ];
}
