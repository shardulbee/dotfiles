# Knowledge Search MCP

Read-only SQLite archive access. `main.go` owns the two tool contracts and queries;
[`search.nix`](../../nixos/services/knowledge/search.nix) owns the Executor-only
listener at `http://10.50.4.1:8784/mcp` and read-only filesystem sandbox.
The Go MCP SDK matches Notes; `libsqlite3` links the pinned Nix SQLite with FTS5.

- `search`: Unicode letter/number keywords joined with AND; punctuation separates
  words. Source filtering precedes ranking/limit. Defaults to 10 hits, maximum 50.
  Snippets are exact Markdown excerpts, at most 1000 code points. Oversized
  matching tokens return an error. Titles are capped at 1000 code points.
- `get`: Markdown by default, or exact raw data with its `raw_format`. Pages contain
  at most 16000 code points; `nextOffset: null` marks the end. Missing raw errors.
  Stable IDs encode source identity, not rowid. Compare `revision` across pages;
  discard/restart on a change. Calls do not pin a multi-request snapshot.

`KNOWLEDGE_DB` and `LISTEN_ADDR` are required. SQLite opens with `mode=ro` and
`query_only`. The primary file is mounted read-only; its directory permits
creation of missing WAL/SHM sidecars. Ingestion and note writes belong to other
services. SQLite excerpts that are not contiguous Markdown, including some NUL
cases, return an error rather than an invented offset. `get` preserves NUL data.

Run `nix build .#knowledge-mcp` for package tests. `TestLiveArchive` is an opt-in
read-only HTTP MCP check selected by `KNOWLEDGE_TEST_DB`; it reports source names
and timings only. No catalog registration is part of this package.
