package main

import (
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"log"
	"math"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	_ "github.com/mattn/go-sqlite3"
	"github.com/modelcontextprotocol/go-sdk/mcp"
)

const snippetCap = 1000
const readCap = 16000

func sourceOK(s string) bool {
	switch s {
	case "amp", "pi", "hermes", "chatgpt", "claude", "notes":
		return true
	}
	return false
}

func documentID(source, id string) string {
	b, _ := json.Marshal([2]string{source, id})
	return base64.RawURLEncoding.EncodeToString(b)
}

func parseID(id string) (string, string, error) {
	b, e := base64.RawURLEncoding.Strict().DecodeString(id)
	var pair []string
	if e != nil || json.Unmarshal(b, &pair) != nil || len(pair) != 2 || !sourceOK(pair[0]) || pair[1] == "" || documentID(pair[0], pair[1]) != id {
		return "", "", errors.New("invalid document id")
	}
	return pair[0], pair[1], nil
}

func openDB(path string) (*sql.DB, error) {
	p, e := filepath.Abs(path)
	if e != nil {
		return nil, e
	}
	u := url.URL{Scheme: "file", Path: p, RawQuery: "mode=ro&_query_only=1&_busy_timeout=5000"}
	db, e := sql.Open("sqlite3", u.String())
	if e != nil {
		return nil, e
	}
	db.SetMaxOpenConns(4)
	if e = db.Ping(); e != nil {
		db.Close()
		return nil, e
	}
	return db, nil
}

type SearchInput struct {
	Query   string   `json:"query" jsonschema:"Plain Unicode keywords, AND semantics; punctuation separates words. At most 1000 code points."`
	Sources []string `json:"sources,omitempty" jsonschema:"Optional sources: amp, pi, hermes, chatgpt, claude, notes. Empty means all."`
	Limit   *int     `json:"limit,omitempty" jsonschema:"Default 10; range 1 through 50."`
}
type Hit struct {
	ID            string `json:"id"`
	Source        string `json:"source"`
	Title         string `json:"title"`
	Snippet       string `json:"snippet"`
	SnippetOffset int64  `json:"snippetOffset"`
	rowID         int64
}
type SearchResult struct {
	Hits    []Hit `json:"hits"`
	HasMore bool  `json:"hasMore"`
}

func keywords(query string) ([]string, error) {
	if !utf8.ValidString(query) || utf8.RuneCountInString(query) > 1000 {
		return nil, errors.New("query must be UTF-8 and at most 1000 code points")
	}
	words := strings.FieldsFunc(query, func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsNumber(r) && !unicode.IsMark(r) })
	terms := []string{}
	for _, word := range words {
		if strings.ContainsFunc(word, func(r rune) bool { return unicode.IsLetter(r) || unicode.IsNumber(r) }) {
			terms = append(terms, `"`+word+`"`)
		}
	}
	if len(terms) == 0 {
		return nil, errors.New("query must contain a letter or number")
	}
	return terms, nil
}

func search(ctx context.Context, db *sql.DB, in SearchInput) (SearchResult, error) {
	out := SearchResult{Hits: []Hit{}}
	terms, e := keywords(in.Query)
	if e != nil {
		return out, e
	}
	limit := 10
	if in.Limit != nil {
		limit = *in.Limit
	}
	if limit < 1 || limit > 50 {
		return out, errors.New("limit must be between 1 and 50")
	}
	match := strings.Join(terms, " AND ")
	args := []any{match}
	filter := ""
	if len(in.Sources) > 0 {
		if len(in.Sources) > 6 {
			return out, errors.New("at most six sources")
		}
		for _, s := range in.Sources {
			if !sourceOK(s) {
				return out, errors.New("invalid source")
			}
			args = append(args, s)
		}
		filter = " AND d.source IN (" + strings.TrimSuffix(strings.Repeat("?,", len(in.Sources)), ",") + ")"
	}
	args = append(args, limit+1)
	tx, e := db.BeginTx(ctx, &sql.TxOptions{ReadOnly: true})
	if e != nil {
		return out, e
	}
	defer tx.Rollback()
	rows, e := tx.QueryContext(ctx, `SELECT d.rowid,d.source,d.source_id,substr(d.title,1,1000)
		FROM documents_fts JOIN documents d ON d.rowid=documents_fts.rowid
		WHERE documents_fts MATCH ?`+filter+` ORDER BY bm25(documents_fts),d.source,d.source_id LIMIT ?`, args...)
	if e != nil {
		return out, e
	}
	for rows.Next() {
		var h Hit
		var id string
		if e = rows.Scan(&h.rowID, &h.Source, &id, &h.Title); e != nil {
			rows.Close()
			return out, e
		}
		h.ID = documentID(h.Source, id)
		out.Hits = append(out.Hits, h)
	}
	e = rows.Err()
	rows.Close()
	if e != nil {
		return out, e
	}
	out.HasMore = len(out.Hits) > limit
	if out.HasMore {
		out.Hits = out.Hits[:limit]
	}
	for i := range out.Hits {
		h := &out.Hits[i]
		var bodyHit bool
		e = tx.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM documents_fts WHERE rowid=? AND documents_fts MATCH ?)`, h.rowID, "markdown : ("+strings.Join(terms, " OR ")+")").Scan(&bodyHit)
		if e != nil {
			return out, e
		}
		if !bodyHit {
			e = tx.QueryRowContext(ctx, `SELECT substr(markdown,1,?) FROM documents WHERE rowid=?`, snippetCap, h.rowID).Scan(&h.Snippet)
			if e != nil {
				return out, e
			}
			continue
		}
		// Shrink SQLite's token window, rather than clipping off a late match.
		for _, tokens := range []int{32, 8, 1} {
			e = tx.QueryRowContext(ctx, `SELECT snippet(documents_fts,1,'','','',?) FROM documents_fts WHERE rowid=? AND documents_fts MATCH ?`, tokens, h.rowID, match).Scan(&h.Snippet)
			if e != nil {
				return out, e
			}
			if utf8.RuneCountInString(h.Snippet) <= snippetCap {
				break
			}
		}
		if utf8.RuneCountInString(h.Snippet) > snippetCap {
			h.Snippet = strings.TrimFunc(h.Snippet, func(r rune) bool {
				return unicode.IsSpace(r) || unicode.IsPunct(r) || unicode.IsSymbol(r) || unicode.IsControl(r)
			})
		}
		if utf8.RuneCountInString(h.Snippet) > snippetCap {
			return out, errors.New("matching token exceeds snippet limit")
		}
		e = tx.QueryRowContext(ctx, `SELECT instr(markdown,?)-1 FROM documents WHERE rowid=?`, h.Snippet, h.rowID).Scan(&h.SnippetOffset)
		if e != nil {
			return out, e
		}
		if h.SnippetOffset < 0 {
			return out, errors.New("cannot locate SQLite excerpt")
		}
	}
	return out, tx.Commit()
}

type GetInput struct {
	ID     string `json:"id"`
	Format string `json:"format,omitempty" jsonschema:"markdown (default) or raw; unavailable raw is an error."`
	Offset int64  `json:"offset,omitempty" jsonschema:"Zero-based Unicode code-point offset, default 0."`
}
type Provenance struct {
	SourcePath      string  `json:"sourcePath"`
	SourceUpdatedAt *string `json:"sourceUpdatedAt"`
	IndexedAt       string  `json:"indexedAt"`
}
type GetResult struct {
	ID         string     `json:"id"`
	Source     string     `json:"source"`
	Title      string     `json:"title"`
	Format     string     `json:"format"`
	Content    string     `json:"content"`
	NextOffset *int64     `json:"nextOffset"`
	Revision   string     `json:"revision"`
	Provenance Provenance `json:"provenance"`
	RawFormat  *string    `json:"raw_format,omitempty"`
}

func get(ctx context.Context, db *sql.DB, in GetInput) (GetResult, error) {
	out := GetResult{ID: in.ID, Format: in.Format}
	source, id, e := parseID(in.ID)
	if e != nil {
		return out, e
	}
	out.Source = source
	if out.Format == "" {
		out.Format = "markdown"
	}
	column, revision := "markdown", "content_hash"
	if out.Format == "raw" {
		column, revision = "raw_json", "raw_hash"
	} else if out.Format != "markdown" {
		return out, errors.New("invalid format")
	}
	if in.Offset < 0 || in.Offset > math.MaxInt64-readCap-1 {
		return out, errors.New("invalid offset")
	}
	// SQLite TEXT substr stops at NUL; preserve such documents by slicing in Go.
	page := "CASE WHEN instr(" + column + ",char(0))=0 THEN substr(" + column + ",?+1,16001) ELSE " + column + " END"
	var content, hash, rawFormat sql.NullString
	var total sql.NullInt64
	var hasNUL sql.NullBool
	e = db.QueryRowContext(ctx, `SELECT substr(title,1,1000),source_path,source_updated_at,indexed_at,`+revision+`,raw_format,length(`+column+`),instr(`+column+`,char(0))>0,`+page+` FROM documents WHERE source=? AND source_id=?`, in.Offset, source, id).Scan(&out.Title, &out.Provenance.SourcePath, &out.Provenance.SourceUpdatedAt, &out.Provenance.IndexedAt, &hash, &rawFormat, &total, &hasNUL, &content)
	if errors.Is(e, sql.ErrNoRows) {
		return out, errors.New("document not found")
	}
	if e != nil {
		return out, e
	}
	if !content.Valid {
		return out, errors.New("raw data unavailable")
	}
	runes := []rune(content.String)
	if hasNUL.Bool {
		total.Int64 = int64(len(runes))
	}
	if in.Offset > total.Int64 {
		return out, errors.New("offset past document end")
	}
	if hasNUL.Bool {
		runes = runes[in.Offset:]
	}
	if len(runes) > readCap {
		next := in.Offset + readCap
		out.NextOffset = &next
		runes = runes[:readCap]
	}
	out.Content, out.Revision = string(runes), hash.String
	if out.Format == "raw" {
		out.RawFormat = &rawFormat.String
	}
	return out, nil
}

func handler(db *sql.DB) http.Handler {
	server := mcp.NewServer(&mcp.Implementation{Name: "knowledge-search", Version: "1.0.0"}, nil)
	mcp.AddTool(server, &mcp.Tool{Name: "search", Annotations: &mcp.ToolAnnotations{ReadOnlyHint: true}, InputSchema: json.RawMessage(`{"type":"object","required":["query"],"additionalProperties":false,"properties":{"query":{"type":"string","maxLength":1000},"sources":{"type":"array","maxItems":6,"items":{"type":"string","enum":["amp","pi","hermes","chatgpt","claude","notes"]}},"limit":{"type":"integer","minimum":1,"maximum":50,"default":10}}}`), Description: "Search indexed title and Markdown with plain keyword AND semantics. Punctuation separates words; operators are literal keywords. Returns at most 50 hits, snippets capped at 1000 code points. snippetOffset is the excerpt start in Markdown. Read current content with get; ingestion can change offsets."}, func(ctx context.Context, _ *mcp.CallToolRequest, in SearchInput) (*mcp.CallToolResult, SearchResult, error) {
		ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
		defer cancel()
		out, e := search(ctx, db, in)
		return nil, out, e
	})
	mcp.AddTool(server, &mcp.Tool{Name: "get", Annotations: &mcp.ToolAnnotations{ReadOnlyHint: true}, InputSchema: json.RawMessage(`{"type":"object","required":["id"],"additionalProperties":false,"properties":{"id":{"type":"string"},"format":{"type":"string","enum":["markdown","raw"],"default":"markdown"},"offset":{"type":"integer","minimum":0,"default":0}}}`), Description: "Read at most 16000 Unicode code points. Continue at nextOffset with the same id and format. Each call reads current data: compare revision across pages and discard/restart if changed. Raw is exact source JSON/JSONL/sqlite-json, never a Markdown fallback; individual raw pages may not parse."}, func(ctx context.Context, _ *mcp.CallToolRequest, in GetInput) (*mcp.CallToolResult, GetResult, error) {
		ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
		defer cancel()
		out, e := get(ctx, db, in)
		return nil, out, e
	})
	return mcp.NewStreamableHTTPHandler(func(*http.Request) *mcp.Server { return server }, &mcp.StreamableHTTPOptions{Stateless: true})
}

func main() {
	if os.Getenv("KNOWLEDGE_DB") == "" || os.Getenv("LISTEN_ADDR") == "" {
		log.Fatal("KNOWLEDGE_DB and LISTEN_ADDR are required")
	}
	db, e := openDB(os.Getenv("KNOWLEDGE_DB"))
	if e != nil {
		log.Fatal(e)
	}
	defer db.Close()
	mux := http.NewServeMux()
	mux.Handle("/mcp", handler(db))
	server := &http.Server{Addr: os.Getenv("LISTEN_ADDR"), Handler: http.MaxBytesHandler(mux, 65536), ReadHeaderTimeout: 10 * time.Second}
	log.Fatal(server.ListenAndServe())
}
