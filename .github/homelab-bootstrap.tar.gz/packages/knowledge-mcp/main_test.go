package main

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
	"unicode/utf8"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

const schema = `CREATE TABLE documents(source TEXT,source_id TEXT,title TEXT,source_path TEXT,source_updated_at TEXT,markdown TEXT,raw_json TEXT,raw_format TEXT,content_hash TEXT,raw_hash TEXT,indexed_at TEXT,PRIMARY KEY(source,source_id));
CREATE VIRTUAL TABLE documents_fts USING fts5(title,markdown,content='documents',content_rowid='rowid');
CREATE TRIGGER ai AFTER INSERT ON documents BEGIN INSERT INTO documents_fts(rowid,title,markdown) VALUES(new.rowid,new.title,new.markdown); END;
CREATE TRIGGER ad AFTER DELETE ON documents BEGIN INSERT INTO documents_fts(documents_fts,rowid,title,markdown) VALUES('delete',old.rowid,old.title,old.markdown); END;
CREATE TRIGGER au AFTER UPDATE ON documents BEGIN INSERT INTO documents_fts(documents_fts,rowid,title,markdown) VALUES('delete',old.rowid,old.title,old.markdown); INSERT INTO documents_fts(rowid,title,markdown) VALUES(new.rowid,new.title,new.markdown); END;`

func hash(s string) string { h := sha256.Sum256([]byte(s)); return hex.EncodeToString(h[:]) }
func fixture(t *testing.T) (*sql.DB, *sql.DB) {
	t.Helper()
	p := filepath.Join(t.TempDir(), "archive.sqlite3")
	w, e := sql.Open("sqlite3", p+"?_journal_mode=WAL&_busy_timeout=5000")
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { w.Close() })
	if _, e = w.Exec(schema); e != nil {
		t.Fatal(e)
	}
	r, e := openDB(p)
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { r.Close() })
	return r, w
}
func put(t *testing.T, w *sql.DB, source, id, title, body string, raw *string, format string) {
	t.Helper()
	var rawHash any
	if raw != nil {
		rawHash = hash(*raw)
	}
	_, e := w.Exec(`INSERT INTO documents VALUES(?,?,?,'/fixture/source','2026-09-09',?,?,?,?,?,'2026-09-09') ON CONFLICT(source,source_id) DO UPDATE SET title=excluded.title,markdown=excluded.markdown,raw_json=excluded.raw_json,raw_format=excluded.raw_format,content_hash=excluded.content_hash,raw_hash=excluded.raw_hash`, source, id, title, body, raw, format, hash(body), rawHash)
	if e != nil {
		t.Fatal(e)
	}
}
func mustSearch(t *testing.T, r *sql.DB, in SearchInput) SearchResult {
	t.Helper()
	out, e := search(context.Background(), r, in)
	if e != nil {
		t.Fatal(e)
	}
	return out
}

func TestSnippetOffsetsAndLongTokens(t *testing.T) {
	r, w := fixture(t)
	cases := []struct{ id, title, body, query string }{
		{"late", "title", strings.Repeat("雪 🐝 padding ", 200000) + "needle birch " + strings.Repeat("tail ", 100), "needle birch"},
		{"long", "title", strings.Repeat("z", 12000) + " needle tail", "needle"},
		{"repeated", "title", "雪 needle grove. 雪 needle grove.", "needle"},
		{"title-only", "needle", "  " + strings.Repeat("z", 12000), "needle"},
		{"mixed", "cedar", "🐝 unrelated needle", "cedar needle"},
	}
	for _, c := range cases {
		put(t, w, "amp", c.id, c.title, c.body, nil, "")
	}
	for _, c := range cases {
		out := mustSearch(t, r, SearchInput{Query: c.query})
		found := false
		for _, h := range out.Hits {
			if h.ID != documentID("amp", c.id) {
				continue
			}
			found = true
			if utf8.RuneCountInString(h.Snippet) > snippetCap {
				t.Fatal("unbounded snippet")
			}
			if !strings.HasPrefix(string([]rune(c.body)[h.SnippetOffset:]), h.Snippet) {
				t.Fatal("offset does not locate exact excerpt")
			}
			if c.id == "title-only" {
				if h.SnippetOffset != 0 {
					t.Fatal("title-only offset")
				}
			} else if !strings.Contains(h.Snippet, "needle") {
				t.Fatal("match lost")
			}
			if c.id == "late" && h.SnippetOffset < 2_000_000 {
				t.Fatal("late match lost")
			}
			if c.id == "repeated" && h.SnippetOffset != int64(utf8.RuneCountInString(c.body[:strings.Index(c.body, h.Snippet)])) {
				t.Fatal("not first excerpt occurrence")
			}
		}
		if !found {
			t.Fatal("missing fixture hit")
		}
	}
	put(t, w, "notes", "oversize", "", "a"+strings.Repeat("\u0301", 2000), nil, "")
	if _, e := search(context.Background(), r, SearchInput{Query: "a"}); e == nil {
		t.Fatal("oversize matching token must not silently clip")
	}
	put(t, w, "notes", "nul", "", "雪\x00nulneedle grove", nil, "")
	if _, e := search(context.Background(), r, SearchInput{Query: "nulneedle"}); e == nil {
		t.Fatal("noncontiguous SQLite excerpt must not return an invented offset")
	}
}

func TestKeywordFilterRankingAndLimits(t *testing.T) {
	r, w := fixture(t)
	put(t, w, "amp", "operators", "", "alpha OR beta", nil, "")
	put(t, w, "amp", "plain", "", "alpha beta", nil, "")
	put(t, w, "amp", "one", "", "alpha", nil, "")
	for _, q := range []string{`alpha OR beta`, `"alpha" OR (beta)*`, `alpha:OR^beta`} {
		h := mustSearch(t, r, SearchInput{Query: q}).Hits
		if len(h) != 1 || h[0].ID != documentID("amp", "operators") {
			t.Fatal("FTS operators interpreted")
		}
	}
	if len(mustSearch(t, r, SearchInput{Query: "alpha beta"}).Hits) != 2 {
		t.Fatal("not keyword AND")
	}
	raw := "hiddenrawkeyword"
	put(t, w, "pi", "raw", "", "body", &raw, "jsonl")
	if len(mustSearch(t, r, SearchInput{Query: raw}).Hits) != 0 {
		t.Fatal("raw searched")
	}
	for i := 0; i < 51; i++ {
		put(t, w, "amp", fmt.Sprintf("%02d", i), "", "quartz", nil, "")
	}
	put(t, w, "notes", "weak", "", "quartz "+strings.Repeat("filler ", 300), nil, "")
	put(t, w, "notes", "strong", "", "quartz", nil, "")
	one := 1
	h := mustSearch(t, r, SearchInput{Query: "quartz", Sources: []string{"notes"}, Limit: &one})
	if len(h.Hits) != 1 || h.Hits[0].ID != documentID("notes", "strong") || !h.HasMore {
		t.Fatal("source filter applied after limit")
	}
	h = mustSearch(t, r, SearchInput{Query: "quartz", Sources: []string{"amp"}})
	if len(h.Hits) != 10 || !h.HasMore {
		t.Fatal("default limit")
	}
	for i, x := range h.Hits {
		if x.ID != documentID("amp", fmt.Sprintf("%02d", i)) {
			t.Fatal("unstable tie-break")
		}
	}
	fifty := 50
	h = mustSearch(t, r, SearchInput{Query: "quartz", Sources: []string{"amp"}, Limit: &fifty})
	if len(h.Hits) != 50 || !h.HasMore {
		t.Fatal("max limit")
	}
	for _, in := range []SearchInput{{Query: "*:^()"}, {Query: strings.Repeat("a", 1001)}, {Query: "x", Sources: []string{"bogus"}}, {Query: "x", Limit: new(int)}} {
		if _, e := search(context.Background(), r, in); e == nil {
			t.Fatal("invalid search accepted")
		}
	}
}

func TestGetPagingRawUnicodeNULAndIdentity(t *testing.T) {
	r, w := fixture(t)
	s := client(t, r)
	for _, format := range []string{"json", "jsonl", "sqlite-json"} {
		record := "{\"text\":\"雪🐝é\"}"
		raw := strings.Repeat(record+"\r\n", 4000)
		if format != "jsonl" {
			raw = `{"session":{"id":"fixture"},"messages":[` + strings.TrimSuffix(strings.Repeat(record+",", 4000), ",") + ` ]}`
		}
		put(t, w, "pi", format, "title", "markdown", &raw, format)
		var full strings.Builder
		var offset int64
		for {
			o := call[GetResult](t, s, "get", map[string]any{"id": documentID("pi", format), "format": "raw", "offset": offset})
			if o.Revision != hash(raw) || o.RawFormat == nil || *o.RawFormat != format || utf8.RuneCountInString(o.Content) > readCap {
				t.Fatal("raw metadata/cap")
			}
			full.WriteString(o.Content)
			if o.NextOffset == nil {
				break
			}
			if *o.NextOffset != offset+readCap {
				t.Fatal("not code-point offset")
			}
			offset = *o.NextOffset
		}
		if full.String() != raw {
			t.Fatal("raw reconstruction differs")
		}
	}
	body := strings.Repeat("雪🐝", 8000) + "\x00last"
	put(t, w, "notes", "a/b雪", "title", body, nil, "")
	id := documentID("notes", "a/b雪")
	for _, offset := range []int64{0, 15999, 16000, 16005} {
		o, e := get(context.Background(), r, GetInput{ID: id, Offset: offset})
		if e != nil {
			t.Fatal(e)
		}
		want := []rune(body)[offset:]
		if len(want) > readCap {
			want = want[:readCap]
		}
		if o.Content != string(want) {
			t.Fatal("Unicode/NUL content differs")
		}
	}
	for _, in := range []GetInput{{ID: id, Format: "raw"}, {ID: id, Format: "bogus"}, {ID: id, Offset: -1}, {ID: id, Offset: 16006}, {ID: "invalid"}, {ID: documentID("amp", "missing")}} {
		if _, e := get(context.Background(), r, in); e == nil {
			t.Fatal("invalid get accepted")
		}
	}
	if _, e := w.Exec("DELETE FROM documents WHERE source='notes'"); e != nil {
		t.Fatal(e)
	}
	put(t, w, "amp", "occupy-old-rowid", "", "other", nil, "")
	put(t, w, "notes", "a/b雪", "new", "new", nil, "")
	o, e := get(context.Background(), r, GetInput{ID: id})
	if e != nil || o.Content != "new" {
		t.Fatal("id depends on rowid")
	}
}

func TestReadOnlyAndConcurrentIngestion(t *testing.T) {
	r, w := fixture(t)
	if _, e := r.Exec("DELETE FROM documents"); e == nil {
		t.Fatal("reader wrote")
	}
	conn, e := r.Conn(context.Background())
	if e != nil {
		t.Fatal(e)
	}
	conn.ExecContext(context.Background(), "PRAGMA query_only=OFF")
	if _, e = conn.ExecContext(context.Background(), "INSERT INTO documents(source,source_id) VALUES('notes','bad')"); e == nil {
		t.Fatal("mode=ro bypassed")
	}
	conn.Close()
	put(t, w, "amp", "changing", "", "cedar "+strings.Repeat("雪", 17000), nil, "")
	first, e := get(context.Background(), r, GetInput{ID: documentID("amp", "changing")})
	if e != nil {
		t.Fatal(e)
	}
	put(t, w, "amp", "changing", "", "cedar "+strings.Repeat("🐝", 17000), nil, "")
	next, e := get(context.Background(), r, GetInput{ID: first.ID, Offset: *first.NextOffset})
	if e != nil || first.Revision == next.Revision {
		t.Fatal("continuation drift invisible")
	}
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 0; i < 25; i++ {
			body := fmt.Sprintf("cedar revision%d", i)
			if _, e := w.Exec("UPDATE documents SET markdown=?,content_hash=? WHERE source='amp' AND source_id='changing'", body, hash(body)); e != nil {
				t.Error(e)
				return
			}
			time.Sleep(time.Millisecond)
		}
	}()
	for i := 0; i < 25; i++ {
		out := mustSearch(t, r, SearchInput{Query: "cedar"})
		if len(out.Hits) != 1 {
			t.Fatal("concurrent search lost row")
		}
		if _, e = get(context.Background(), r, GetInput{ID: first.ID}); e != nil {
			t.Fatal(e)
		}
	}
	wg.Wait()
	p := filepath.Join(t.TempDir(), "missing.sqlite3")
	if db, e := openDB(p); e == nil {
		db.Close()
		t.Fatal("missing DB accepted")
	}
	if _, e := os.Stat(p); !os.IsNotExist(e) {
		t.Fatal("reader created DB")
	}
}

func client(t *testing.T, r *sql.DB) *mcp.ClientSession {
	t.Helper()
	server := httptest.NewServer(handler(r))
	t.Cleanup(server.Close)
	c := mcp.NewClient(&mcp.Implementation{Name: "test", Version: "1"}, nil)
	s, e := c.Connect(context.Background(), &mcp.StreamableClientTransport{Endpoint: server.URL}, nil)
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { s.Close() })
	list, e := s.ListTools(context.Background(), nil)
	if e != nil || len(list.Tools) != 2 {
		t.Fatal("tools/list failed")
	}
	for _, tool := range list.Tools {
		if tool.Name != "search" && tool.Name != "get" || tool.Annotations == nil || !tool.Annotations.ReadOnlyHint {
			t.Fatal("unexpected tool contract")
		}
		b, _ := json.Marshal(tool.InputSchema)
		if tool.Name == "search" && !strings.Contains(string(b), `"enum":["amp","pi","hermes","chatgpt","claude","notes"]`) {
			t.Fatal("source enum absent")
		}
	}
	return s
}
func call[T any](t *testing.T, s *mcp.ClientSession, name string, args any) T {
	t.Helper()
	r, e := s.CallTool(context.Background(), &mcp.CallToolParams{Name: name, Arguments: args})
	if e != nil || r.IsError {
		t.Fatalf("%s call failed", name)
	}
	b, e := json.Marshal(r.StructuredContent)
	if e != nil {
		t.Fatal("invalid structured result")
	}
	var out T
	if json.Unmarshal(b, &out) != nil {
		t.Fatal("cannot decode result")
	}
	return out
}
func TestMCPProtocol(t *testing.T) {
	r, w := fixture(t)
	s := client(t, r)
	for _, source := range []string{"amp", "pi", "hermes", "chatgpt", "claude", "notes"} {
		put(t, w, source, "same", "title", "fixturekeyword 雪", nil, "")
		out := call[SearchResult](t, s, "search", map[string]any{"query": "fixturekeyword", "sources": []string{source}})
		if len(out.Hits) != 1 || out.Hits[0].Source != source {
			t.Fatal("source retrieval")
		}
		doc := call[GetResult](t, s, "get", map[string]any{"id": out.Hits[0].ID})
		if doc.Content != "fixturekeyword 雪" || doc.Provenance.SourcePath != "/fixture/source" {
			t.Fatal("get content/provenance")
		}
	}
	for _, args := range []map[string]any{{}, {"query": "*"}, {"query": "fixturekeyword", "limit": 51}, {"query": "fixturekeyword", "sources": []string{"bad"}}} {
		r, e := s.CallTool(context.Background(), &mcp.CallToolParams{Name: "search", Arguments: args})
		if e == nil && !r.IsError {
			t.Fatal("MCP invalid input not error")
		}
	}
	rawError, e := s.CallTool(context.Background(), &mcp.CallToolParams{Name: "get", Arguments: map[string]any{"id": documentID("notes", "same"), "format": "raw"}})
	if e == nil && !rawError.IsError {
		t.Fatal("missing raw fallback")
	}
	r.Close()
	broken, e := s.CallTool(context.Background(), &mcp.CallToolParams{Name: "search", Arguments: map[string]any{"query": "fixturekeyword"}})
	if e == nil && !broken.IsError {
		t.Fatal("database failure returned empty success")
	}
}

func TestLiveArchive(t *testing.T) {
	p := os.Getenv("KNOWLEDGE_TEST_DB")
	if p == "" {
		t.Skip("live read-only check is opt-in")
	}
	r, e := openDB(p)
	if e != nil {
		t.Fatalf("live database unavailable: %v", e)
	}
	defer r.Close()
	s := client(t, r)
	var version string
	if e = r.QueryRow("SELECT sqlite_version()").Scan(&version); e != nil {
		t.Fatal("SQLite version unavailable")
	}
	t.Logf("SQLite=%s", version)
	for _, source := range []string{"amp", "pi", "hermes", "chatgpt", "claude", "notes"} {
		started := time.Now()
		var title string
		if e = r.QueryRow("SELECT title FROM documents WHERE source=? ORDER BY source_id LIMIT 1", source).Scan(&title); e != nil {
			t.Fatal("live source unavailable")
		}
		terms, e := keywords(title)
		if e != nil {
			t.Fatal("live title not searchable")
		}
		out := call[SearchResult](t, s, "search", map[string]any{"query": strings.Trim(terms[0], `"`), "sources": []string{source}, "limit": 1})
		if len(out.Hits) != 1 {
			t.Fatal("live source search empty")
		}
		doc := call[GetResult](t, s, "get", map[string]any{"id": out.Hits[0].ID})
		if doc.Source != source || doc.Provenance.SourcePath == "" || utf8.RuneCountInString(doc.Content) > readCap {
			t.Fatal("live source get invalid")
		}
		_, id, e := parseID(doc.ID)
		if e != nil {
			t.Fatal("live identity invalid")
		}
		var expected, revision string
		if e = r.QueryRow("SELECT substr(markdown,1,16000),content_hash FROM documents WHERE source=? AND source_id=?", source, id).Scan(&expected, &revision); e != nil {
			t.Fatal("live comparison unavailable")
		}
		if revision == doc.Revision && expected != doc.Content {
			t.Fatal("live content mismatch")
		}
		if source == "amp" || source == "pi" || source == "hermes" {
			raw := call[GetResult](t, s, "get", map[string]any{"id": doc.ID, "format": "raw"})
			if raw.RawFormat == nil || utf8.RuneCountInString(raw.Content) > readCap {
				t.Fatal("live raw invalid")
			}
			if e = r.QueryRow("SELECT substr(raw_json,1,16000),raw_hash FROM documents WHERE source=? AND source_id=?", source, id).Scan(&expected, &revision); e != nil {
				t.Fatal("live raw comparison unavailable")
			}
			if revision == raw.Revision && expected != raw.Content {
				t.Fatal("live raw mismatch")
			}
		}
		t.Logf("source=%s search/get/provenance=ok milliseconds=%d", source, time.Since(started).Milliseconds())
	}
	var source, id string
	var size int64
	if e = r.QueryRow("SELECT source,source_id,length(raw_json) FROM documents WHERE raw_json IS NOT NULL ORDER BY length(CAST(raw_json AS BLOB)) DESC LIMIT 1").Scan(&source, &id, &size); e != nil {
		t.Fatal("largest raw lookup failed")
	}
	started := time.Now()
	for _, offset := range []int64{0, size - 1000} {
		doc := call[GetResult](t, s, "get", map[string]any{"id": documentID(source, id), "format": "raw", "offset": offset})
		if utf8.RuneCountInString(doc.Content) > readCap {
			t.Fatal("large raw unbounded")
		}
	}
	t.Logf("largest raw source=%s codepoints=%d first/late pages=ok milliseconds=%d", source, size, time.Since(started).Milliseconds())
}
