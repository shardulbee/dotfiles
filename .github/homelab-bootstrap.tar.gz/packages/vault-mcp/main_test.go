package main

import (
	"context"
	"net/http/httptest"
	"os"
	"strings"
	"syscall"
	"testing"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

func fixture(t *testing.T) *Store {
	t.Helper()
	s, e := openStore(t.TempDir(), t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(s.close)
	return s
}
func TestNoteLifecycle(t *testing.T) {
	s := fixture(t)
	in := Input{Path: "Inbox/Agent test 雪.md", Content: "# Synthetic\n\n雪\n"}
	first, e := s.operation("create", in)
	if e != nil {
		t.Fatal(e)
	}
	stat, _ := s.root.Stat(in.Path)
	again, e := s.operation("create", in)
	if e != nil || again != first {
		t.Fatalf("retry: %v", e)
	}
	stat2, _ := s.root.Stat(in.Path)
	if stat.ModTime() != stat2.ModTime() {
		t.Fatal("unchanged create rewrote file")
	}
	if _, e = s.operation("create", Input{Path: in.Path, Content: "other"}); e == nil {
		t.Fatal("overwrite")
	}
	if _, e = s.operation("edit", Input{Path: in.Path, Content: "new", Revision: "wrong"}); e == nil {
		t.Fatal("stale edit")
	}
	edited, e := s.operation("edit", Input{Path: in.Path, Content: "new", Revision: first.Revision})
	if e != nil || edited.Content != "new" || edited.Revision != hash("new") {
		t.Fatal(e)
	}
	if _, e = s.operation("delete", Input{Path: in.Path, Revision: first.Revision}); e == nil {
		t.Fatal("stale delete")
	}
	deleted, e := s.operation("delete", Input{Path: in.Path, Revision: edited.Revision})
	if e != nil || deleted.Path != in.Path || deleted.Content != "" || deleted.Revision != edited.Revision {
		t.Fatal(e)
	}
	if _, e = s.root.Stat(in.Path); !os.IsNotExist(e) {
		t.Fatal("not deleted")
	}
	dir, e := s.root.Open("Inbox")
	if e != nil {
		t.Fatal(e)
	}
	defer dir.Close()
	entries, _ := dir.ReadDir(-1)
	if len(entries) != 0 {
		t.Fatal("temporary file leaked")
	}
	state, e := s.state.Open(".")
	if e != nil {
		t.Fatal(e)
	}
	defer state.Close()
	entries, e = state.ReadDir(-1)
	if e != nil || len(entries) != 1 || entries[0].Name() != "vault.lock" {
		t.Fatal("state must contain only the shared lock")
	}
}
func TestExplicitContentOverMCP(t *testing.T) {
	s := fixture(t)
	server := httptest.NewServer(handler(s))
	defer server.Close()
	client := mcp.NewClient(&mcp.Implementation{Name: "test", Version: "1"}, nil)
	session, e := client.Connect(context.Background(), &mcp.StreamableClientTransport{Endpoint: server.URL}, nil)
	if e != nil {
		t.Fatal(e)
	}
	defer session.Close()
	list, e := session.ListTools(context.Background(), nil)
	if e != nil {
		t.Fatal(e)
	}
	want := map[string]bool{"read": true, "create": true, "edit": true, "delete": true, "freshness": true}
	if len(list.Tools) != len(want) {
		t.Fatal("unexpected tool count")
	}
	for _, tool := range list.Tools {
		if !want[tool.Name] {
			t.Fatalf("unexpected tool %s", tool.Name)
		}
		delete(want, tool.Name)
		if (tool.Name == "read" || tool.Name == "freshness") && !strings.Contains(tool.Description, "Knowledge Search") {
			t.Fatal("tool description must identify the archive reader")
		}
	}
	call := func(kind string, args map[string]any) *mcp.CallToolResult {
		t.Helper()
		r, e := session.CallTool(context.Background(), &mcp.CallToolParams{Name: kind, Arguments: args})
		if e != nil {
			t.Fatal(e)
		}
		return r
	}
	if !call("create", map[string]any{"path": "empty.md"}).IsError {
		t.Fatal("omitted create content accepted")
	}
	if call("create", map[string]any{"path": "empty.md", "content": "initial"}).IsError {
		t.Fatal("create failed")
	}
	if !call("edit", map[string]any{"path": "empty.md", "revision": hash("initial")}).IsError {
		t.Fatal("omitted edit content accepted")
	}
	if call("edit", map[string]any{"path": "empty.md", "revision": hash("initial"), "content": ""}).IsError {
		t.Fatal("explicit empty edit rejected")
	}
	n, e := s.operation("read", Input{Path: "empty.md"})
	if e != nil || n.Content != "" {
		t.Fatal("empty not written")
	}
}

func TestConcurrentRevision(t *testing.T) {
	s := fixture(t)
	first, e := s.operation("create", Input{Path: "race.md", Content: "old"})
	if e != nil {
		t.Fatal(e)
	}
	start := make(chan struct{})
	results := make(chan error, 2)
	for _, body := range []string{"one", "two"} {
		go func() {
			<-start
			_, e := s.operation("edit", Input{Path: "race.md", Content: body, Revision: first.Revision})
			results <- e
		}()
	}
	close(start)
	successes := 0
	for range 2 {
		if e := <-results; e == nil {
			successes++
		} else if !strings.Contains(e.Error(), "stale") {
			t.Fatal(e)
		}
	}
	if successes != 1 {
		t.Fatalf("successful edits = %d", successes)
	}
}

func TestPathAndLockGuards(t *testing.T) {
	s := fixture(t)
	outside := t.TempDir()
	if e := s.root.Symlink(outside, "escape"); e != nil {
		t.Fatal(e)
	}
	if e := s.root.Mkdir("Agent Sessions", 0700); e != nil {
		t.Fatal(e)
	}
	if e := s.root.Symlink("Agent Sessions", "alias"); e != nil {
		t.Fatal(e)
	}
	for _, p := range []string{"../escape.md", "/tmp/escape.md", "a/../../b.md", "a\\b.md", ".obsidian/config.md", "a/.hidden.md", "Agent Sessions/amp/a.md", "agent sessions/a.md", "escape/a.md", "alias/a.md", "bad.txt", "a//b.md"} {
		if _, e := s.operation("create", Input{Path: p, Content: "bad"}); e == nil {
			t.Errorf("accepted %q", p)
		}
	}
	l, e := s.state.OpenFile("vault.lock", os.O_RDWR, 0600)
	if e != nil {
		t.Fatal(e)
	}
	defer l.Close()
	if e = syscall.Flock(int(l.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); e != nil {
		t.Fatal(e)
	}
	if _, e = s.operation("create", Input{Path: "a.md", Content: "blocked"}); e == nil || !strings.Contains(e.Error(), "busy") {
		t.Fatal("sync lock bypass")
	}
}
