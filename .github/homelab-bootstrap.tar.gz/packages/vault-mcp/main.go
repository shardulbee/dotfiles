package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path"
	"strings"
	"sync"
	"syscall"
	"time"
	"unicode/utf8"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

type Note struct {
	Path     string `json:"path"`
	Content  string `json:"content"`
	Revision string `json:"revision"`
}
type Input struct {
	Path     string `json:"path" jsonschema:"vault-relative Markdown path; hidden paths and Agent Sessions are excluded"`
	Content  string `json:"content,omitempty"`
	Revision string `json:"revision,omitempty" jsonschema:"SHA256 revision returned by read; required for edit/delete"`
}
type Store struct {
	root, state *os.Root
	lock        *os.File
	mu          sync.Mutex
}

func hash(s string) string { v := sha256.Sum256([]byte(s)); return hex.EncodeToString(v[:]) }
func openStore(vault, state string) (*Store, error) {
	r, e := os.OpenRoot(vault)
	if e != nil {
		return nil, e
	}
	s, e := os.OpenRoot(state)
	if e != nil {
		r.Close()
		return nil, e
	}
	l, e := s.OpenFile("vault.lock", os.O_CREATE|os.O_RDWR, 0600)
	if e != nil {
		r.Close()
		s.Close()
		return nil, e
	}
	return &Store{root: r, state: s, lock: l}, nil
}
func (s *Store) close() { s.root.Close(); s.state.Close(); s.lock.Close() }
func valid(p string) bool {
	if !fs.ValidPath(p) || strings.ContainsAny(p, "\\\x00") || !strings.HasSuffix(p, ".md") {
		return false
	}
	for _, part := range strings.Split(p, "/") {
		if strings.HasPrefix(part, ".") || strings.EqualFold(part, "Agent Sessions") {
			return false
		}
	}
	return true
}
func (s *Store) check(p string) error {
	if !valid(p) {
		return errors.New("invalid or protected path")
	}
	// os.Root prevents traversal outside the vault, including symlink races.
	// Reject even in-vault symlinks so aliases cannot reach protected subtrees.
	parts := strings.Split(p, "/")
	for i := range parts {
		st, e := s.root.Lstat(strings.Join(parts[:i+1], "/"))
		if errors.Is(e, fs.ErrNotExist) {
			return nil
		}
		if e != nil {
			return e
		}
		if st.Mode()&os.ModeSymlink != 0 {
			return errors.New("symlink path rejected")
		}
		if i == len(parts)-1 && !st.Mode().IsRegular() {
			return errors.New("not a regular note")
		}
	}
	return nil
}
func read(r *os.Root, p string) (Note, error) {
	b, e := r.ReadFile(p)
	if e != nil {
		return Note{}, e
	}
	return Note{Path: p, Content: string(b), Revision: hash(string(b))}, nil
}
func write(r *os.Root, p, body string, exclusive bool) error {
	if e := r.MkdirAll(path.Dir(p), 0700); e != nil {
		return e
	}
	tmp := path.Join(path.Dir(p), ".vault-"+rand.Text())
	f, e := r.OpenFile(tmp, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	defer r.Remove(tmp)
	if _, e = f.WriteString(body); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	if exclusive {
		// Hard-link publish is atomic and refuses to replace an existing note.
		e = r.Link(tmp, p)
	} else {
		e = r.Rename(tmp, p)
	}
	if e != nil {
		return e
	}
	d, e := r.Open(path.Dir(p))
	if e != nil {
		return e
	}
	defer d.Close()
	return d.Sync()
}
func (s *Store) operation(kind string, in Input) (Note, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	// Same lock as one-shot Obsidian sync. Don't wait behind a long catchup.
	if e := syscall.Flock(int(s.lock.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); e != nil {
		return Note{}, errors.New("vault sync busy; retry")
	}
	defer syscall.Flock(int(s.lock.Fd()), syscall.LOCK_UN)
	if e := s.check(in.Path); e != nil {
		return Note{}, e
	}
	if !utf8.ValidString(in.Content) || len(in.Content) > 2_000_000 {
		return Note{}, errors.New("content must be UTF-8 and at most 2000000 bytes")
	}
	old, e := read(s.root, in.Path)
	if kind == "read" {
		return old, e
	}
	if kind == "create" {
		if e == nil {
			if old.Content == in.Content {
				return old, nil
			}
			return Note{}, errors.New("note exists with different content")
		}
		if !errors.Is(e, fs.ErrNotExist) {
			return Note{}, e
		}
		if e = write(s.root, in.Path, in.Content, true); e != nil {
			return Note{}, e
		}
		return read(s.root, in.Path)
	}
	if e != nil {
		return Note{}, e
	}
	if in.Revision == "" || old.Revision != in.Revision {
		return Note{}, errors.New("stale revision; read before editing")
	}
	if kind == "delete" {
		if e = s.root.Remove(in.Path); e != nil {
			return Note{}, e
		}
		d, e := s.root.Open(path.Dir(in.Path))
		if e != nil {
			return Note{}, e
		}
		defer d.Close()
		if e = d.Sync(); e != nil {
			return Note{}, e
		}
		old.Content = ""
		return old, nil
	}
	if kind != "edit" {
		return Note{}, errors.New("unknown operation")
	}
	if e = write(s.root, in.Path, in.Content, false); e != nil {
		return Note{}, e
	}
	return read(s.root, in.Path)
}
func handler(s *Store) http.Handler {
	server := mcp.NewServer(&mcp.Implementation{Name: "vault-notes", Version: "1.0.0"}, nil)
	for _, kind := range []string{"read", "create", "edit", "delete"} {
		mcp.AddTool(server, &mcp.Tool{Name: kind, Description: map[string]string{
			"read":   "Read current note and SHA256 revision. Read generated sessions through Knowledge Search.",
			"create": "Create note; retry with identical path/content succeeds without rewriting. Does not overwrite.",
			"edit":   "Replace note only when revision matches.",
			"delete": "Delete note only when revision matches.",
		}[kind]}, func(_ context.Context, _ *mcp.CallToolRequest, in struct {
			Path     string  `json:"path"`
			Content  *string `json:"content,omitempty" jsonschema:"required for create/edit; explicit empty string clears body"`
			Revision string  `json:"revision,omitempty" jsonschema:"required for edit/delete; SHA256 from read"`
		}) (*mcp.CallToolResult, Note, error) {
			if (kind == "create" || kind == "edit") && in.Content == nil {
				return nil, Note{}, errors.New("content must be explicitly supplied")
			}
			input := Input{Path: in.Path, Revision: in.Revision}
			if in.Content != nil {
				input.Content = *in.Content
			}
			n, e := s.operation(kind, input)
			return nil, n, e
		})
	}
	mcp.AddTool(server, &mcp.Tool{Name: "freshness", Description: "Last successful vault sync and exporter state update times. Knowledge Search returns each document's indexedAt provenance."}, func(context.Context, *mcp.CallToolRequest, struct{}) (*mcp.CallToolResult, map[string]string, error) {
		values := map[string]string{}
		if b, e := os.ReadFile("/var/lib/obsidian/state/synced-at"); e == nil {
			values["sync"] = strings.TrimSpace(string(b))
		}
		for _, source := range []string{"amp", "pi", "hermes"} {
			st, e := os.Stat("/var/lib/agent-sessions/" + source + "/.state.json")
			if e == nil {
				values[source] = st.ModTime().UTC().Format(time.RFC3339)
			}
		}
		return nil, values, nil
	})
	return mcp.NewStreamableHTTPHandler(func(*http.Request) *mcp.Server { return server }, &mcp.StreamableHTTPOptions{Stateless: true})
}
func main() {
	s, e := openStore(os.Getenv("VAULT_ROOT"), os.Getenv("VAULT_STATE"))
	if e != nil {
		log.Fatal(e)
	}
	defer s.close()
	mux := http.NewServeMux()
	mux.Handle("/mcp", handler(s))
	server := &http.Server{Addr: os.Getenv("LISTEN_ADDR"), Handler: http.MaxBytesHandler(mux, 3_000_000), ReadHeaderTimeout: 10 * time.Second}
	if e = server.ListenAndServe(); e != nil {
		log.Fatal(fmt.Errorf("serve: %w", e))
	}
}
