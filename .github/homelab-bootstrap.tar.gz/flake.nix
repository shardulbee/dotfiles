{
  description = "Shardul's homelab";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";
    disko = {
      url = "github:nix-community/disko";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    nixos-containers = {
      url = "github:bouk/nixos-containers";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    home-manager = {
      url = "github:nix-community/home-manager/release-26.05";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    workstation-nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    workstation-home-manager = {
      url = "github:nix-community/home-manager";
      inputs.nixpkgs.follows = "workstation-nixpkgs";
    };
    darwin = {
      url = "github:nix-darwin/nix-darwin";
      inputs.nixpkgs.follows = "workstation-nixpkgs";
    };
    helium = {
      url = "github:oxcl/nix-flake-helium-browser";
      inputs.nixpkgs.follows = "workstation-nixpkgs";
    };
    xremap-flake = {
      url = "github:xremap/nix-flake";
      inputs.nixpkgs.follows = "workstation-nixpkgs";
    };
    monstar = {
      url = "github:rockorager/monstar/709ebe668e8c08166f30e847a678aae820ff1732";
      inputs.nixpkgs.follows = "workstation-nixpkgs";
    };
    hermes.url = "github:NousResearch/hermes-agent/29112bef099274229cadff79cdff7bf7b99c4b77";
  };

  outputs =
    inputs@{
      self,
      nixpkgs,
      disko,
      home-manager,
      workstation-nixpkgs,
      workstation-home-manager,
      darwin,
      helium,
      xremap-flake,
      monstar,
      hermes,
      ...
    }:
    let
      system = "x86_64-linux";
      pkgs = import nixpkgs { inherit system; };
      workstations = import ./dotfiles {
        nixpkgs = workstation-nixpkgs;
        home-manager = workstation-home-manager;
        inherit
          darwin
          helium
          xremap-flake
          monstar
          hermes
          ;
      };
    in
    {
      nixosConfigurations = workstations.nixosConfigurations // {
        hotbox = nixpkgs.lib.nixosSystem {
          inherit system;
          specialArgs = { inherit inputs; };
          modules = [
            disko.nixosModules.disko
            home-manager.nixosModules.home-manager
            ./nixos/shell-home.nix
            ./nixos/hotbox-deploy.nix
            ./nixos/hotbox.nix
          ];
        };

        sharbox = nixpkgs.lib.nixosSystem {
          inherit system;
          specialArgs = { inherit inputs; };
          modules = [
            disko.nixosModules.disko
            inputs.nixos-containers.nixosModules.host
            home-manager.nixosModules.home-manager
            ./nixos/shell-home.nix
            ./nixos/sharbox.nix
          ];
        };
      };

      inherit (workstations) darwinConfigurations;

      packages.${system} = {
        obsidian-headless = pkgs.callPackage ./nixos/services/knowledge/obsidian-headless.nix { };
        agent-skills-mcp = pkgs.callPackage ./packages/agent-skills-mcp { };
        vault-mcp = pkgs.callPackage ./packages/vault-mcp { };
        knowledge-mcp = pkgs.callPackage ./packages/knowledge-mcp { };
        fastmail-mcp = pkgs.callPackage ./packages/fastmail-mcp { };
        session-backups = pkgs.callPackage ./tools/session-backups { };
      };

      checks.${system} = {
        inherit (self.packages.${system})
          agent-skills-mcp
          fastmail-mcp
          vault-mcp
          knowledge-mcp
          ;
      };

      devShells.${system}.default = pkgs.mkShell {
        packages = [ pkgs.go ];
      };
    };
}
