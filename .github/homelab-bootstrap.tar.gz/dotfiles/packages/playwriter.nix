{ lib, buildNpmPackage, makeWrapper, nodejs, runCommand }:

let
  src = runCommand "playwriter-0.4.0-source" { } ''
    mkdir -p "$out"
    cat > "$out/package.json" <<'EOF'
    {"name":"playwriter-nix-wrapper","private":true,"dependencies":{"playwriter":"0.4.0"}}
    EOF
    cat > "$out/package-lock.json" <<'EOF'
    {
      "name": "playwriter-nix-wrapper",
      "lockfileVersion": 3,
      "requires": true,
      "packages": {
        "": {
          "name": "playwriter-nix-wrapper",
          "dependencies": {
            "playwriter": "0.4.0"
          }
        },
        "node_modules/@babel/runtime": {
          "version": "7.29.7",
          "resolved": "https://registry.npmjs.org/@babel/runtime/-/runtime-7.29.7.tgz",
          "integrity": "sha512-Nq8OhGWiZIZGV6hLHoyAKLLcJihP/xFeBMGJoUrxTX2psI8dCifzLhZISFb+VWS3wFMRDmCGw5R+dOySCqPLhw==",
          "license": "MIT",
          "engines": {
            "node": ">=6.9.0"
          }
        },
        "node_modules/@better-auth/core": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/core/-/core-1.7.2.tgz",
          "integrity": "sha512-j0nM4ygsWbF/fcYRoKtDn8gn8uLXkmC+075HqSqsJEAV828cJR9bvYBCUQ1zmxNyRBk6Iz/qXsA0Zm2oksiOTg==",
          "license": "MIT",
          "dependencies": {
            "@opentelemetry/semantic-conventions": "^1.41.1",
            "@standard-schema/spec": "^1.1.0",
            "zod": "^4.3.6"
          },
          "peerDependencies": {
            "@better-auth/utils": "0.4.2",
            "@better-fetch/fetch": "1.3.1",
            "@cloudflare/workers-types": ">=4",
            "@opentelemetry/api": "^1.9.0",
            "better-call": "1.4.0",
            "jose": "^6.1.0",
            "kysely": "^0.28.5 || ^0.29.0",
            "nanostores": "^1.0.1"
          },
          "peerDependenciesMeta": {
            "@cloudflare/workers-types": {
              "optional": true
            },
            "@opentelemetry/api": {
              "optional": true
            }
          }
        },
        "node_modules/@better-auth/drizzle-adapter": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/drizzle-adapter/-/drizzle-adapter-1.7.2.tgz",
          "integrity": "sha512-A5wE10PIv3aS5LGePecEHntQylKy6OOF17B4dqlE0DwJeqU/IOBSd7/LZhMop9cNJ3WFjKMpazVSf91yYM/NFg==",
          "license": "MIT",
          "peerDependencies": {
            "@better-auth/core": "^1.7.2",
            "@better-auth/utils": "0.4.2",
            "drizzle-orm": "^0.45.2 || >=1.0.0-rc.1 <2.0.0"
          },
          "peerDependenciesMeta": {
            "drizzle-orm": {
              "optional": true
            }
          }
        },
        "node_modules/@better-auth/kysely-adapter": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/kysely-adapter/-/kysely-adapter-1.7.2.tgz",
          "integrity": "sha512-LYdSRLOvZiF+6S0UThu+wE/Qxsq9P2jQs7ZKkY6BIBJqUjYyxVDmi8HFcantBvWWW1/BeQCSsD7YVDG4gICMIQ==",
          "license": "MIT",
          "peerDependencies": {
            "@better-auth/core": "^1.7.2",
            "@better-auth/utils": "0.4.2",
            "kysely": "^0.28.17 || ^0.29.0"
          },
          "peerDependenciesMeta": {
            "kysely": {
              "optional": true
            }
          }
        },
        "node_modules/@better-auth/memory-adapter": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/memory-adapter/-/memory-adapter-1.7.2.tgz",
          "integrity": "sha512-0q1SXMzm5esH9L0xVuM6IxCk59E4G+3HySX4My9gvEwqtmUobykn+iuc/si3Y4xwUO7JODqQ5o+/pPcLDDMIrA==",
          "license": "MIT",
          "peerDependencies": {
            "@better-auth/core": "^1.7.2",
            "@better-auth/utils": "0.4.2"
          }
        },
        "node_modules/@better-auth/mongo-adapter": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/mongo-adapter/-/mongo-adapter-1.7.2.tgz",
          "integrity": "sha512-4879SmUWHUs0OYlvHoCFbycZ7i1bqytkcgAUdt9RLQMvZ5H3LRMTgax2YVlGZEXgwNjY/X7xAoXOecWLhlQWeA==",
          "license": "MIT",
          "peerDependencies": {
            "@better-auth/core": "^1.7.2",
            "@better-auth/utils": "0.4.2",
            "mongodb": "^6.0.0 || ^7.0.0"
          },
          "peerDependenciesMeta": {
            "mongodb": {
              "optional": true
            }
          }
        },
        "node_modules/@better-auth/prisma-adapter": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/prisma-adapter/-/prisma-adapter-1.7.2.tgz",
          "integrity": "sha512-mXTr/83WrNWLrvzIjtgDgdu9iXhOcSG1+qBQOAKlbGSFiOB+z4IMRneQ2wmMOiB8mKY9qGkClVUjKRFXqtHnFQ==",
          "license": "MIT",
          "peerDependencies": {
            "@better-auth/core": "^1.7.2",
            "@better-auth/utils": "0.4.2",
            "@prisma/client": "^5.0.0 || ^6.0.0 || ^7.0.0",
            "prisma": "^5.0.0 || ^6.0.0 || ^7.0.0"
          },
          "peerDependenciesMeta": {
            "@prisma/client": {
              "optional": true
            },
            "prisma": {
              "optional": true
            }
          }
        },
        "node_modules/@better-auth/telemetry": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/@better-auth/telemetry/-/telemetry-1.7.2.tgz",
          "integrity": "sha512-LcWu+O0zrxYDQj8E36vfkJwGPW4k9ZDA/rCo0zST6ihzL+juR7pBowoZIM9E6tK0Vit52mf6412bGT4XM4eTjQ==",
          "license": "MIT",
          "peerDependencies": {
            "@better-auth/core": "^1.7.2",
            "@better-auth/utils": "0.4.2",
            "@better-fetch/fetch": "1.3.1"
          }
        },
        "node_modules/@better-auth/utils": {
          "version": "0.4.2",
          "resolved": "https://registry.npmjs.org/@better-auth/utils/-/utils-0.4.2.tgz",
          "integrity": "sha512-AUxrvu+HaaODsUyzDxFgwd/8RZ1yZaYo42LXKSrU2oGgR38pS1ij8nqQKNgtTWoYGpNevNXtCfgTy6loHveW9A==",
          "license": "MIT",
          "dependencies": {
            "@noble/hashes": "^2.0.1"
          }
        },
        "node_modules/@better-fetch/fetch": {
          "version": "1.3.1",
          "resolved": "https://registry.npmjs.org/@better-fetch/fetch/-/fetch-1.3.1.tgz",
          "integrity": "sha512-ABkD1WhyfPZprKRQI3bhATjeiFuNWC9PXhfGWqL+sg/gKrM977oFrYkdb4msM3hgUGonr7KlOsOFT5TU2rht9g==",
          "license": "MIT"
        },
        "node_modules/@emnapi/runtime": {
          "version": "1.11.3",
          "resolved": "https://registry.npmjs.org/@emnapi/runtime/-/runtime-1.11.3.tgz",
          "integrity": "sha512-Xz4Tpyki7XyrpbUK1jR1AhdAdaXyhhY4lZ3neLodmhpuWfy2PAQN5B46sAiU4liOXGLkHypn/qU+jvfWSCYYLA==",
          "license": "MIT",
          "optional": true,
          "dependencies": {
            "tslib": "^2.4.0"
          }
        },
        "node_modules/@hono/node-server": {
          "version": "1.19.17",
          "resolved": "https://registry.npmjs.org/@hono/node-server/-/node-server-1.19.17.tgz",
          "integrity": "sha512-dSneS5qhiauZWGDCeK4o695Xd9nUNjviSZCMQrj10eetr8Uln1ucn6bbphOM6UynAMMtNIzZNSpL9vnASJwrPQ==",
          "license": "MIT",
          "engines": {
            "node": ">=18.14.1"
          },
          "peerDependencies": {
            "hono": "^4"
          }
        },
        "node_modules/@hono/node-ws": {
          "version": "1.3.1",
          "resolved": "https://registry.npmjs.org/@hono/node-ws/-/node-ws-1.3.1.tgz",
          "integrity": "sha512-vo/MwCnpJAVHBkGzWjCJ28wF45fYHAfbPZcH2rodZODHtch2GHA94KtMfusmVycTUtsLAsaNsHhtY6P8X3RQsA==",
          "license": "MIT",
          "dependencies": {
            "ws": "^8.17.0"
          },
          "engines": {
            "node": ">=18.14.1"
          },
          "peerDependencies": {
            "@hono/node-server": "^1.19.11",
            "hono": "^4.6.0"
          }
        },
        "node_modules/@img/colour": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/@img/colour/-/colour-1.1.0.tgz",
          "integrity": "sha512-Td76q7j57o/tLVdgS746cYARfSyxk8iEfRxewL9h4OMzYhbW4TAcppl0mT4eyqXddh6L/jwoM75mo7ixa/pCeQ==",
          "license": "MIT",
          "optional": true,
          "engines": {
            "node": ">=18"
          }
        },
        "node_modules/@img/sharp-darwin-arm64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-darwin-arm64/-/sharp-darwin-arm64-0.34.5.tgz",
          "integrity": "sha512-imtQ3WMJXbMY4fxb/Ndp6HBTNVtWCUI0WdobyheGf5+ad6xX8VIDO8u2xE4qc/fr08CKG/7dDseFtn6M6g/r3w==",
          "cpu": [
            "arm64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "darwin"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-darwin-arm64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-darwin-x64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-darwin-x64/-/sharp-darwin-x64-0.34.5.tgz",
          "integrity": "sha512-YNEFAF/4KQ/PeW0N+r+aVVsoIY0/qxxikF2SWdp+NRkmMB7y9LBZAVqQ4yhGCm/H3H270OSykqmQMKLBhBJDEw==",
          "cpu": [
            "x64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "darwin"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-darwin-x64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-libvips-darwin-arm64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-darwin-arm64/-/sharp-libvips-darwin-arm64-1.2.4.tgz",
          "integrity": "sha512-zqjjo7RatFfFoP0MkQ51jfuFZBnVE2pRiaydKJ1G/rHZvnsrHAOcQALIi9sA5co5xenQdTugCvtb1cuf78Vf4g==",
          "cpu": [
            "arm64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "darwin"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-darwin-x64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-darwin-x64/-/sharp-libvips-darwin-x64-1.2.4.tgz",
          "integrity": "sha512-1IOd5xfVhlGwX+zXv2N93k0yMONvUlANylbJw1eTah8K/Jtpi15KC+WSiaX/nBmbm2HxRM1gZ0nSdjSsrZbGKg==",
          "cpu": [
            "x64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "darwin"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linux-arm": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linux-arm/-/sharp-libvips-linux-arm-1.2.4.tgz",
          "integrity": "sha512-bFI7xcKFELdiNCVov8e44Ia4u2byA+l3XtsAj+Q8tfCwO6BQ8iDojYdvoPMqsKDkuoOo+X6HZA0s0q11ANMQ8A==",
          "cpu": [
            "arm"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linux-arm64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linux-arm64/-/sharp-libvips-linux-arm64-1.2.4.tgz",
          "integrity": "sha512-excjX8DfsIcJ10x1Kzr4RcWe1edC9PquDRRPx3YVCvQv+U5p7Yin2s32ftzikXojb1PIFc/9Mt28/y+iRklkrw==",
          "cpu": [
            "arm64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linux-ppc64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linux-ppc64/-/sharp-libvips-linux-ppc64-1.2.4.tgz",
          "integrity": "sha512-FMuvGijLDYG6lW+b/UvyilUWu5Ayu+3r2d1S8notiGCIyYU/76eig1UfMmkZ7vwgOrzKzlQbFSuQfgm7GYUPpA==",
          "cpu": [
            "ppc64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linux-riscv64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linux-riscv64/-/sharp-libvips-linux-riscv64-1.2.4.tgz",
          "integrity": "sha512-oVDbcR4zUC0ce82teubSm+x6ETixtKZBh/qbREIOcI3cULzDyb18Sr/Wcyx7NRQeQzOiHTNbZFF1UwPS2scyGA==",
          "cpu": [
            "riscv64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linux-s390x": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linux-s390x/-/sharp-libvips-linux-s390x-1.2.4.tgz",
          "integrity": "sha512-qmp9VrzgPgMoGZyPvrQHqk02uyjA0/QrTO26Tqk6l4ZV0MPWIW6LTkqOIov+J1yEu7MbFQaDpwdwJKhbJvuRxQ==",
          "cpu": [
            "s390x"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linux-x64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linux-x64/-/sharp-libvips-linux-x64-1.2.4.tgz",
          "integrity": "sha512-tJxiiLsmHc9Ax1bz3oaOYBURTXGIRDODBqhveVHonrHJ9/+k89qbLl0bcJns+e4t4rvaNBxaEZsFtSfAdquPrw==",
          "cpu": [
            "x64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linuxmusl-arm64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linuxmusl-arm64/-/sharp-libvips-linuxmusl-arm64-1.2.4.tgz",
          "integrity": "sha512-FVQHuwx1IIuNow9QAbYUzJ+En8KcVm9Lk5+uGUQJHaZmMECZmOlix9HnH7n1TRkXMS0pGxIJokIVB9SuqZGGXw==",
          "cpu": [
            "arm64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-libvips-linuxmusl-x64": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/@img/sharp-libvips-linuxmusl-x64/-/sharp-libvips-linuxmusl-x64-1.2.4.tgz",
          "integrity": "sha512-+LpyBk7L44ZIXwz/VYfglaX/okxezESc6UxDSoyo2Ks6Jxc4Y7sGjpgU9s4PMgqgjj1gZCylTieNamqA1MF7Dg==",
          "cpu": [
            "x64"
          ],
          "license": "LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "linux"
          ],
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-linux-arm": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linux-arm/-/sharp-linux-arm-0.34.5.tgz",
          "integrity": "sha512-9dLqsvwtg1uuXBGZKsxem9595+ujv0sJ6Vi8wcTANSFpwV/GONat5eCkzQo/1O6zRIkh0m/8+5BjrRr7jDUSZw==",
          "cpu": [
            "arm"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linux-arm": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linux-arm64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linux-arm64/-/sharp-linux-arm64-0.34.5.tgz",
          "integrity": "sha512-bKQzaJRY/bkPOXyKx5EVup7qkaojECG6NLYswgktOZjaXecSAeCWiZwwiFf3/Y+O1HrauiE3FVsGxFg8c24rZg==",
          "cpu": [
            "arm64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linux-arm64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linux-ppc64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linux-ppc64/-/sharp-linux-ppc64-0.34.5.tgz",
          "integrity": "sha512-7zznwNaqW6YtsfrGGDA6BRkISKAAE1Jo0QdpNYXNMHu2+0dTrPflTLNkpc8l7MUP5M16ZJcUvysVWWrMefZquA==",
          "cpu": [
            "ppc64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linux-ppc64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linux-riscv64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linux-riscv64/-/sharp-linux-riscv64-0.34.5.tgz",
          "integrity": "sha512-51gJuLPTKa7piYPaVs8GmByo7/U7/7TZOq+cnXJIHZKavIRHAP77e3N2HEl3dgiqdD/w0yUfiJnII77PuDDFdw==",
          "cpu": [
            "riscv64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linux-riscv64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linux-s390x": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linux-s390x/-/sharp-linux-s390x-0.34.5.tgz",
          "integrity": "sha512-nQtCk0PdKfho3eC5MrbQoigJ2gd1CgddUMkabUj+rBevs8tZ2cULOx46E7oyX+04WGfABgIwmMC0VqieTiR4jg==",
          "cpu": [
            "s390x"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linux-s390x": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linux-x64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linux-x64/-/sharp-linux-x64-0.34.5.tgz",
          "integrity": "sha512-MEzd8HPKxVxVenwAa+JRPwEC7QFjoPWuS5NZnBt6B3pu7EG2Ge0id1oLHZpPJdn3OQK+BQDiw9zStiHBTJQQQQ==",
          "cpu": [
            "x64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linux-x64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linuxmusl-arm64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linuxmusl-arm64/-/sharp-linuxmusl-arm64-0.34.5.tgz",
          "integrity": "sha512-fprJR6GtRsMt6Kyfq44IsChVZeGN97gTD331weR1ex1c1rypDEABN6Tm2xa1wE6lYb5DdEnk03NZPqA7Id21yg==",
          "cpu": [
            "arm64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linuxmusl-arm64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-linuxmusl-x64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-linuxmusl-x64/-/sharp-linuxmusl-x64-0.34.5.tgz",
          "integrity": "sha512-Jg8wNT1MUzIvhBFxViqrEhWDGzqymo3sV7z7ZsaWbZNDLXRJZoRGrjulp60YYtV4wfY8VIKcWidjojlLcWrd8Q==",
          "cpu": [
            "x64"
          ],
          "license": "Apache-2.0",
          "optional": true,
          "os": [
            "linux"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-libvips-linuxmusl-x64": "1.2.4"
          }
        },
        "node_modules/@img/sharp-wasm32": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-wasm32/-/sharp-wasm32-0.34.5.tgz",
          "integrity": "sha512-OdWTEiVkY2PHwqkbBI8frFxQQFekHaSSkUIJkwzclWZe64O1X4UlUjqqqLaPbUpMOQk6FBu/HtlGXNblIs0huw==",
          "cpu": [
            "wasm32"
          ],
          "license": "Apache-2.0 AND LGPL-3.0-or-later AND MIT",
          "optional": true,
          "dependencies": {
            "@emnapi/runtime": "^1.7.0"
          },
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-win32-arm64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-win32-arm64/-/sharp-win32-arm64-0.34.5.tgz",
          "integrity": "sha512-WQ3AgWCWYSb2yt+IG8mnC6Jdk9Whs7O0gxphblsLvdhSpSTtmu69ZG1Gkb6NuvxsNACwiPV6cNSZNzt0KPsw7g==",
          "cpu": [
            "arm64"
          ],
          "license": "Apache-2.0 AND LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "win32"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-win32-ia32": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-win32-ia32/-/sharp-win32-ia32-0.34.5.tgz",
          "integrity": "sha512-FV9m/7NmeCmSHDD5j4+4pNI8Cp3aW+JvLoXcTUo0IqyjSfAZJ8dIUmijx1qaJsIiU+Hosw6xM5KijAWRJCSgNg==",
          "cpu": [
            "ia32"
          ],
          "license": "Apache-2.0 AND LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "win32"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@img/sharp-win32-x64": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/@img/sharp-win32-x64/-/sharp-win32-x64-0.34.5.tgz",
          "integrity": "sha512-+29YMsqY2/9eFEiW93eqWnuLcWcufowXewwSNIT6UwZdUUCrM3oFjMWH/Z6/TMmb4hlFenmfAVbpWeup2jryCw==",
          "cpu": [
            "x64"
          ],
          "license": "Apache-2.0 AND LGPL-3.0-or-later",
          "optional": true,
          "os": [
            "win32"
          ],
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          }
        },
        "node_modules/@isaacs/cliui": {
          "version": "8.0.2",
          "resolved": "https://registry.npmjs.org/@isaacs/cliui/-/cliui-8.0.2.tgz",
          "integrity": "sha512-O8jcjabXaleOG9DQ0+ARXWZBTfnP4WNAqzuiJK7ll44AmxGKv/J2M4TPjxjY3znBCfvBXFzucm1twdyFybFqEA==",
          "license": "ISC",
          "dependencies": {
            "string-width": "^5.1.2",
            "string-width-cjs": "npm:string-width@^4.2.0",
            "strip-ansi": "^7.0.1",
            "strip-ansi-cjs": "npm:strip-ansi@^6.0.1",
            "wrap-ansi": "^8.1.0",
            "wrap-ansi-cjs": "npm:wrap-ansi@^7.0.0"
          },
          "engines": {
            "node": ">=12"
          }
        },
        "node_modules/@lowire/loop": {
          "version": "0.0.25",
          "resolved": "https://registry.npmjs.org/@lowire/loop/-/loop-0.0.25.tgz",
          "integrity": "sha512-tBfQ3+m+BelMSRqmdpOqLQPervF6PoS4IV0JE0ga1fJnOaPRnOfjkGecyaR45Hp7VuhY9oBQdVlDkAXoOkjk1w==",
          "license": "Apache-2.0",
          "engines": {
            "node": ">=20"
          }
        },
        "node_modules/@modelcontextprotocol/sdk": {
          "version": "1.30.0",
          "resolved": "https://registry.npmjs.org/@modelcontextprotocol/sdk/-/sdk-1.30.0.tgz",
          "integrity": "sha512-xKd8OIzlqNzcqcNumGAa6g+PW2kjD5vrpcKOnfldAUPP3j7lnqMPwlTXQm8gF+UwH72z0lqaRbjr9hqGz0eITA==",
          "license": "MIT",
          "dependencies": {
            "@hono/node-server": "^1.19.9 || ^2.0.5",
            "ajv": "^8.17.1",
            "ajv-formats": "^3.0.1",
            "content-type": "^1.0.5",
            "cors": "^2.8.5",
            "cross-spawn": "^7.0.5",
            "eventsource": "^3.0.2",
            "eventsource-parser": "^3.0.0",
            "express": "^5.2.1",
            "express-rate-limit": "^8.2.1",
            "hono": "^4.11.4",
            "jose": "^6.1.3",
            "json-schema-typed": "^8.0.2",
            "pkce-challenge": "^5.0.0",
            "raw-body": "^3.0.0",
            "zod": "^3.25 || ^4.0",
            "zod-to-json-schema": "^3.25.1"
          },
          "engines": {
            "node": ">=18"
          },
          "peerDependencies": {
            "@cfworker/json-schema": "^4.1.1",
            "zod": "^3.25 || ^4.0"
          },
          "peerDependenciesMeta": {
            "@cfworker/json-schema": {
              "optional": true
            },
            "zod": {
              "optional": false
            }
          }
        },
        "node_modules/@noble/ciphers": {
          "version": "2.4.0",
          "resolved": "https://registry.npmjs.org/@noble/ciphers/-/ciphers-2.4.0.tgz",
          "integrity": "sha512-AnjFn0Jv92laAkvMrghlFZq4qQCIN/4DxFV/eooqtC2YTjB7kBeLMS2T9KJX4Dn+ZVXLOwK0lSgqDtx9gvxtiw==",
          "license": "MIT",
          "engines": {
            "node": ">= 20.19.0"
          },
          "funding": {
            "url": "https://paulmillr.com/funding/"
          }
        },
        "node_modules/@noble/hashes": {
          "version": "2.4.0",
          "resolved": "https://registry.npmjs.org/@noble/hashes/-/hashes-2.4.0.tgz",
          "integrity": "sha512-X5XaVWZIBCT7HHZGm5I7ZQXDwLG+bGXuSrMQAW+7Zvl87h1kmc1ZB1VSRJcpUfoUrGQp4Fkoxm5kZ+Ms+aW+eA==",
          "license": "MIT",
          "engines": {
            "node": ">= 20.19.0"
          },
          "funding": {
            "url": "https://paulmillr.com/funding/"
          }
        },
        "node_modules/@one-ini/wasm": {
          "version": "0.1.1",
          "resolved": "https://registry.npmjs.org/@one-ini/wasm/-/wasm-0.1.1.tgz",
          "integrity": "sha512-XuySG1E38YScSJoMlqovLru4KTUNSjgVTIjyh7qMX6aNN5HY5Ct5LhRJdxO79JtTzKfzV/bnWpz+zquYrISsvw==",
          "license": "MIT"
        },
        "node_modules/@opentelemetry/semantic-conventions": {
          "version": "1.43.0",
          "resolved": "https://registry.npmjs.org/@opentelemetry/semantic-conventions/-/semantic-conventions-1.43.0.tgz",
          "integrity": "sha512-eSYWTm620tTk45EKSedaUL8MFYI8hW164hIXsgIHyxu3VobUB3fFCu5t0hQby6OoWRPsG1KkKUG2M5UadiLiVg==",
          "license": "Apache-2.0",
          "engines": {
            "node": ">=14"
          }
        },
        "node_modules/@pkgjs/parseargs": {
          "version": "0.11.0",
          "resolved": "https://registry.npmjs.org/@pkgjs/parseargs/-/parseargs-0.11.0.tgz",
          "integrity": "sha512-+1VkjdD0QBLPodGrJUeqarH8VAIvQODIbwh9XpP5Syisf7YoQgsJKPNFoqqLQlu+VQ/tVSshMR6loPMn8U+dPg==",
          "license": "MIT",
          "optional": true,
          "engines": {
            "node": ">=14"
          }
        },
        "node_modules/@playwriter/patchright-core": {
          "version": "1.61.0-playwriter.1",
          "resolved": "https://registry.npmjs.org/@playwriter/patchright-core/-/patchright-core-1.61.0-playwriter.1.tgz",
          "integrity": "sha512-YSZ2wILegTKbQhMf1ZtPfCrfSsxl9d0goHKz1G+HFydOwXfv37q/WdK1uyUvZgkDT1zJYSUSbFESn5MX4E7Zkw==",
          "license": "Apache-2.0",
          "optional": true,
          "bin": {
            "playwright-core": "cli.js"
          },
          "engines": {
            "node": ">=18"
          }
        },
        "node_modules/@standard-schema/spec": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/@standard-schema/spec/-/spec-1.1.0.tgz",
          "integrity": "sha512-l2aFy5jALhniG5HgqrD6jXLi/rUWrKvqN/qJx6yoJsgKhblVd+iqqU4RCXavm/jPityDo5TCvKMnpjKnOriy0w==",
          "license": "MIT"
        },
        "node_modules/@xmorse/playwright-core": {
          "version": "1.59.11",
          "resolved": "https://registry.npmjs.org/@xmorse/playwright-core/-/playwright-core-1.59.11.tgz",
          "integrity": "sha512-4j2kL04q5WoDzFGKTrHJMYTd/vwbMvSbcH/LDoSexWwDurfeeL7J4deku8pJx7aa0n1UuwnYkGhX/UfbkAqVrA==",
          "license": "Apache-2.0",
          "dependencies": {
            "@lowire/loop": "^0.0.25",
            "@modelcontextprotocol/sdk": "^1.29.0",
            "colors": "1.4.0",
            "commander": "^13.0.0",
            "debug": "^4.3.4",
            "diff": "^7.0.0",
            "dotenv": "^16.4.5",
            "get-stream": "^5.2.0",
            "graceful-fs": "^4.2.11",
            "https-proxy-agent": "7.0.6",
            "jpeg-js": "0.4.4",
            "mime": "^3.0.0",
            "minimatch": "^3.1.2",
            "open": "8.4.0",
            "pngjs": "6.0.0",
            "progress": "2.0.3",
            "proxy-from-env": "1.1.0",
            "retry": "^0.13.1",
            "signal-exit": "^4.1.0",
            "socks-proxy-agent": "8.0.5",
            "ws": "8.17.1",
            "yaml": "^2.6.0",
            "yauzl": "3.2.0",
            "yazl": "2.5.1",
            "zod": "^4.3.5",
            "zod-to-json-schema": "^3.25.1"
          },
          "bin": {
            "playwright-core": "cli.js"
          },
          "engines": {
            "node": ">=18"
          }
        },
        "node_modules/@xmorse/playwright-core/node_modules/diff": {
          "version": "7.0.0",
          "resolved": "https://registry.npmjs.org/diff/-/diff-7.0.0.tgz",
          "integrity": "sha512-PJWHUb1RFevKCwaFA9RlG5tCd+FO5iRh9A8HEtkmBH2Li03iJriB6m6JIN4rGz3K3JLawI7/veA1xzRKP6ISBw==",
          "license": "BSD-3-Clause",
          "engines": {
            "node": ">=0.3.1"
          }
        },
        "node_modules/@xmorse/playwright-core/node_modules/ws": {
          "version": "8.17.1",
          "resolved": "https://registry.npmjs.org/ws/-/ws-8.17.1.tgz",
          "integrity": "sha512-6XQFvXTkbfUOZOKKILFG1PDK2NDQs4azKQl26T0YS5CxqWLgXajbPZ+h4gZekJyRqFU8pvnbAbbs/3TgRPy+GQ==",
          "license": "MIT",
          "engines": {
            "node": ">=10.0.0"
          },
          "peerDependencies": {
            "bufferutil": "^4.0.1",
            "utf-8-validate": ">=5.0.2"
          },
          "peerDependenciesMeta": {
            "bufferutil": {
              "optional": true
            },
            "utf-8-validate": {
              "optional": true
            }
          }
        },
        "node_modules/abbrev": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/abbrev/-/abbrev-2.0.0.tgz",
          "integrity": "sha512-6/mh1E2u2YgEsCHdY0Yx5oW+61gZU+1vXaoiHHrpKeuRNNgFvS+/jrwHiQhB5apAf5oB7UB7E19ol2R2LKH8hQ==",
          "license": "ISC",
          "engines": {
            "node": "^14.17.0 || ^16.13.0 || >=18.0.0"
          }
        },
        "node_modules/accepts": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/accepts/-/accepts-2.0.0.tgz",
          "integrity": "sha512-5cvg6CtKwfgdmVqY1WIiXKc3Q1bkRqGLi+2W/6ao+6Y7gu/RCwRuAhGEzh5B4KlszSuTLgZYuqFqo5bImjNKng==",
          "license": "MIT",
          "dependencies": {
            "mime-types": "^3.0.0",
            "negotiator": "^1.0.0"
          },
          "engines": {
            "node": ">= 0.6"
          }
        },
        "node_modules/acorn": {
          "version": "8.18.0",
          "resolved": "https://registry.npmjs.org/acorn/-/acorn-8.18.0.tgz",
          "integrity": "sha512-lGq+9yr1/GuAWaVYIHRjvvySG5/4VfKIvC8EWxStPdcDh/Ka7FG3twP6v4d5BkravUilhIAsG4Qj83t02LWUPQ==",
          "license": "MIT",
          "bin": {
            "acorn": "bin/acorn"
          },
          "engines": {
            "node": ">=0.4.0"
          }
        },
        "node_modules/agent-base": {
          "version": "7.1.4",
          "resolved": "https://registry.npmjs.org/agent-base/-/agent-base-7.1.4.tgz",
          "integrity": "sha512-MnA+YT8fwfJPgBx3m60MNqakm30XOkyIoH1y6huTQvC0PwZG7ki8NacLBcrPbNoo8vEZy7Jpuk7+jMO+CUovTQ==",
          "license": "MIT",
          "engines": {
            "node": ">= 14"
          }
        },
        "node_modules/ajv": {
          "version": "8.20.0",
          "resolved": "https://registry.npmjs.org/ajv/-/ajv-8.20.0.tgz",
          "integrity": "sha512-Thbli+OlOj+iMPYFBVBfJ3OmCAnaSyNn4M1vz9T6Gka5Jt9ba/HIR56joy65tY6kx/FCF5VXNB819Y7/GUrBGA==",
          "license": "MIT",
          "dependencies": {
            "fast-deep-equal": "^3.1.3",
            "fast-uri": "^3.0.1",
            "json-schema-traverse": "^1.0.0",
            "require-from-string": "^2.0.2"
          },
          "funding": {
            "type": "github",
            "url": "https://github.com/sponsors/epoberezkin"
          }
        },
        "node_modules/ajv-formats": {
          "version": "3.0.1",
          "resolved": "https://registry.npmjs.org/ajv-formats/-/ajv-formats-3.0.1.tgz",
          "integrity": "sha512-8iUql50EUR+uUcdRQ3HDqa6EVyo3docL8g5WJ3FNcWmu62IbkGUue/pEyLBW8VGKKucTPgqeks4fIU1DA4yowQ==",
          "license": "MIT",
          "dependencies": {
            "ajv": "^8.0.0"
          },
          "peerDependencies": {
            "ajv": "^8.0.0"
          },
          "peerDependenciesMeta": {
            "ajv": {
              "optional": true
            }
          }
        },
        "node_modules/ansi-regex": {
          "version": "6.3.0",
          "resolved": "https://registry.npmjs.org/ansi-regex/-/ansi-regex-6.3.0.tgz",
          "integrity": "sha512-WpDfL7NO6j7tH88IDBNVdUJxDh9nmCteAVW9dsep846XdwF4naCBK+/tGLX3KJgcpgMRXCFlTM2hKGoK9FsdrQ==",
          "license": "MIT",
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://github.com/chalk/ansi-regex?sponsor=1"
          }
        },
        "node_modules/ansi-styles": {
          "version": "6.2.3",
          "resolved": "https://registry.npmjs.org/ansi-styles/-/ansi-styles-6.2.3.tgz",
          "integrity": "sha512-4Dj6M28JB+oAH8kFkTLUo+a2jwOFkuqb3yucU0CANcRRUbxS0cP0nZYCGjcc3BNXwRIsUVmDGgzawme7zvJHvg==",
          "license": "MIT",
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://github.com/chalk/ansi-styles?sponsor=1"
          }
        },
        "node_modules/async-sema": {
          "version": "3.1.1",
          "resolved": "https://registry.npmjs.org/async-sema/-/async-sema-3.1.1.tgz",
          "integrity": "sha512-tLRNUXati5MFePdAk8dw7Qt7DpxPB60ofAgn8WRhW6a2rcimZnYBP9oxHiv0OHy+Wz7kPMG+t4LGdt31+4EmGg==",
          "license": "MIT"
        },
        "node_modules/balanced-match": {
          "version": "1.0.2",
          "resolved": "https://registry.npmjs.org/balanced-match/-/balanced-match-1.0.2.tgz",
          "integrity": "sha512-3oSeUO0TMV67hN1AmbXsK4yaqU7tjiHlbxRDZOpH0KW9+CeX4bRAaX0Anxt0tx2MrpRpWwQaPwIlISEJhYU5Pw==",
          "license": "MIT"
        },
        "node_modules/better-auth": {
          "version": "1.7.2",
          "resolved": "https://registry.npmjs.org/better-auth/-/better-auth-1.7.2.tgz",
          "integrity": "sha512-gKapKBEvYIGcMxi74RjQ7EbFLiqyQt58vdoJmL1qAlWSkY1Bc2Vqshl524/3u1NxauiOU03M/Ebh762Brmac9A==",
          "license": "MIT",
          "dependencies": {
            "@better-auth/core": "1.7.2",
            "@better-auth/drizzle-adapter": "1.7.2",
            "@better-auth/kysely-adapter": "1.7.2",
            "@better-auth/memory-adapter": "1.7.2",
            "@better-auth/mongo-adapter": "1.7.2",
            "@better-auth/prisma-adapter": "1.7.2",
            "@better-auth/telemetry": "1.7.2",
            "@better-auth/utils": "0.4.2",
            "@better-fetch/fetch": "1.3.1",
            "@noble/ciphers": "^2.2.0",
            "@noble/hashes": "^2.2.0",
            "better-call": "1.4.0",
            "defu": "^6.1.4",
            "jose": "^6.2.3",
            "kysely": "^0.28.17 || ^0.29.0",
            "nanostores": "^1.3.0",
            "zod": "^4.3.6"
          },
          "peerDependencies": {
            "@lynx-js/react": "*",
            "@prisma/client": "^5.0.0 || ^6.0.0 || ^7.0.0",
            "@sveltejs/kit": "^2.0.0",
            "@tanstack/react-start": "^1.0.0",
            "@tanstack/solid-start": "^1.0.0",
            "better-sqlite3": "^12.0.0",
            "drizzle-kit": ">=0.31.4 || >=1.0.0-beta.1",
            "drizzle-orm": "^0.45.2 || >=1.0.0-rc.1 <2.0.0",
            "mongodb": "^6.0.0 || ^7.0.0",
            "mysql2": "^3.0.0",
            "next": "^14.0.0 || ^15.0.0 || ^16.0.0",
            "pg": "^8.0.0",
            "prisma": "^5.0.0 || ^6.0.0 || ^7.0.0",
            "react": "^18.0.0 || ^19.0.0",
            "react-dom": "^18.0.0 || ^19.0.0",
            "solid-js": "^1.0.0",
            "svelte": "^4.0.0 || ^5.0.0",
            "vitest": "^2.0.0 || ^3.0.0 || ^4.0.0",
            "vue": "^3.0.0"
          },
          "peerDependenciesMeta": {
            "@lynx-js/react": {
              "optional": true
            },
            "@prisma/client": {
              "optional": true
            },
            "@sveltejs/kit": {
              "optional": true
            },
            "@tanstack/react-start": {
              "optional": true
            },
            "@tanstack/solid-start": {
              "optional": true
            },
            "better-sqlite3": {
              "optional": true
            },
            "drizzle-kit": {
              "optional": true
            },
            "drizzle-orm": {
              "optional": true
            },
            "mongodb": {
              "optional": true
            },
            "mysql2": {
              "optional": true
            },
            "next": {
              "optional": true
            },
            "pg": {
              "optional": true
            },
            "prisma": {
              "optional": true
            },
            "react": {
              "optional": true
            },
            "react-dom": {
              "optional": true
            },
            "solid-js": {
              "optional": true
            },
            "svelte": {
              "optional": true
            },
            "vitest": {
              "optional": true
            },
            "vue": {
              "optional": true
            }
          }
        },
        "node_modules/better-call": {
          "version": "1.4.0",
          "resolved": "https://registry.npmjs.org/better-call/-/better-call-1.4.0.tgz",
          "integrity": "sha512-bBKOT4vv1kZLDgxVePdilk/Jwkn+dtRRsmi3DzHcDP+WnswyVl6dR59l2HEeP/0cB+bDoopASAesWDPIdd/zZA==",
          "license": "MIT",
          "dependencies": {
            "@better-auth/utils": "^0.5.0",
            "@better-fetch/fetch": "^1.3.1",
            "rou3": "^0.9.1",
            "set-cookie-parser": "^3.1.2"
          },
          "peerDependencies": {
            "zod": "^4.0.0"
          },
          "peerDependenciesMeta": {
            "zod": {
              "optional": true
            }
          }
        },
        "node_modules/better-call/node_modules/@better-auth/utils": {
          "version": "0.5.0",
          "resolved": "https://registry.npmjs.org/@better-auth/utils/-/utils-0.5.0.tgz",
          "integrity": "sha512-BL8W4EfIZFwlu0r54m3v1ztjDhu6dDe/amLTm0xybmbZaNgYUqhD3SjpAsnq0q8YD6/ki4iwIgxJNLP/N3TxiA==",
          "license": "MIT",
          "dependencies": {
            "@noble/hashes": "^2.0.1"
          }
        },
        "node_modules/body-parser": {
          "version": "2.3.0",
          "resolved": "https://registry.npmjs.org/body-parser/-/body-parser-2.3.0.tgz",
          "integrity": "sha512-2cGmJupaNgg+QUwVLAucDuWuoMZ6EX9iHDRswZ5lsNYEmwPaRknMPCLZz07yTzVq/83p4o/wzbDZbBrTvGGTIw==",
          "license": "MIT",
          "dependencies": {
            "bytes": "^3.1.2",
            "content-type": "^2.0.0",
            "debug": "^4.4.3",
            "http-errors": "^2.0.1",
            "iconv-lite": "^0.7.2",
            "on-finished": "^2.4.1",
            "qs": "^6.15.2",
            "raw-body": "^3.0.2",
            "type-is": "^2.1.0"
          },
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/body-parser/node_modules/content-type": {
          "version": "2.1.0",
          "resolved": "https://registry.npmjs.org/content-type/-/content-type-2.1.0.tgz",
          "integrity": "sha512-mj7UPXE0jaqaOsukNZRUEfEi2AcL7C/vwmwcHV0O97eO1E1pxBZuyjlZrx5seTaNBg1U6+o35wpa35Qfcc+7ag==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/brace-expansion": {
          "version": "1.1.18",
          "resolved": "https://registry.npmjs.org/brace-expansion/-/brace-expansion-1.1.18.tgz",
          "integrity": "sha512-Edep/X9fGqVNmzKBVsDYIOtD+z1tuezV70LBjdCst9Tqu76lsnvRiZ6oTic1n+/BIwX6QDGAO94PN4N2SADvtw==",
          "license": "MIT",
          "dependencies": {
            "balanced-match": "^1.0.0",
            "concat-map": "0.0.1"
          }
        },
        "node_modules/buffer-crc32": {
          "version": "0.2.13",
          "resolved": "https://registry.npmjs.org/buffer-crc32/-/buffer-crc32-0.2.13.tgz",
          "integrity": "sha512-VO9Ht/+p3SN7SKWqcrgEzjGbRSJYTx+Q1pTQC0wrWqHx0vpJraQ6GtHx8tvcg1rlK1byhU5gccxgOgj7B0TDkQ==",
          "license": "MIT",
          "engines": {
            "node": "*"
          }
        },
        "node_modules/bytes": {
          "version": "3.1.2",
          "resolved": "https://registry.npmjs.org/bytes/-/bytes-3.1.2.tgz",
          "integrity": "sha512-/Nf7TyzTx6S3yRJObOAV7956r8cr2+Oj8AC5dt8wSP3BQAoeX58NoHyCU8P8zGkNXStjTSi6fzO6F0pBdcYbEg==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/call-bind-apply-helpers": {
          "version": "1.0.2",
          "resolved": "https://registry.npmjs.org/call-bind-apply-helpers/-/call-bind-apply-helpers-1.0.2.tgz",
          "integrity": "sha512-Sp1ablJ0ivDkSzjcaJdxEunN5/XvksFJ2sMBFfq6x0ryhQV/2b/KwFe21cMpmHtPOSij8K99/wSfoEuTObmuMQ==",
          "license": "MIT",
          "dependencies": {
            "es-errors": "^1.3.0",
            "function-bind": "^1.1.2"
          },
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/call-bound": {
          "version": "1.0.4",
          "resolved": "https://registry.npmjs.org/call-bound/-/call-bound-1.0.4.tgz",
          "integrity": "sha512-+ys997U96po4Kx/ABpBCqhA9EuxJaQWDQg7295H4hBphv3IZg0boBKuwYpt4YXp6MZ5AmZQnU/tyMTlRpaSejg==",
          "license": "MIT",
          "dependencies": {
            "call-bind-apply-helpers": "^1.0.2",
            "get-intrinsic": "^1.3.0"
          },
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/color-convert": {
          "version": "2.0.1",
          "resolved": "https://registry.npmjs.org/color-convert/-/color-convert-2.0.1.tgz",
          "integrity": "sha512-RRECPsj7iu/xb5oKYcsFHSppFNnsj/52OVTRKb4zP5onXwVF3zVmmToNcOfGC+CRDpfK/U584fMg38ZHCaElKQ==",
          "license": "MIT",
          "dependencies": {
            "color-name": "~1.1.4"
          },
          "engines": {
            "node": ">=7.0.0"
          }
        },
        "node_modules/color-name": {
          "version": "1.1.4",
          "resolved": "https://registry.npmjs.org/color-name/-/color-name-1.1.4.tgz",
          "integrity": "sha512-dOy+3AuW3a2wNbZHIuMZpTcgjGuLU/uBL/ubcZF9OXbDo8ff4O8yVp5Bf0efS8uEoYo5q4Fx7dY9OgQGXgAsQA==",
          "license": "MIT"
        },
        "node_modules/colors": {
          "version": "1.4.0",
          "resolved": "https://registry.npmjs.org/colors/-/colors-1.4.0.tgz",
          "integrity": "sha512-a+UqTh4kgZg/SlGvfbzDHpgRu7AAQOmmqRHJnxhRZICKFUT91brVhNNt58CMWU9PsBbv3PDCZUHbVxuDiH2mtA==",
          "license": "MIT",
          "engines": {
            "node": ">=0.1.90"
          }
        },
        "node_modules/commander": {
          "version": "13.1.0",
          "resolved": "https://registry.npmjs.org/commander/-/commander-13.1.0.tgz",
          "integrity": "sha512-/rFeCpNJQbhSZjGVwO9RFV3xPqbnERS8MmIQzCtD/zl6gpJuV/bMLuN92oG3F7d8oDEHHRrujSXNUr8fpjntKw==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          }
        },
        "node_modules/concat-map": {
          "version": "0.0.1",
          "resolved": "https://registry.npmjs.org/concat-map/-/concat-map-0.0.1.tgz",
          "integrity": "sha512-/Srv4dswyQNBfohGpz9o6Yb3Gz3SrUDqBH5rTuhGR7ahtlbYKnVxw2bCFMRljaA7EXHaXZ8wsHdodFvbkhKmqg==",
          "license": "MIT"
        },
        "node_modules/config-chain": {
          "version": "1.1.13",
          "resolved": "https://registry.npmjs.org/config-chain/-/config-chain-1.1.13.tgz",
          "integrity": "sha512-qj+f8APARXHrM0hraqXYb2/bOVSV4PvJQlNZ/DVj0QrmNM2q2euizkeuVckQ57J+W0mRH6Hvi+k50M4Jul2VRQ==",
          "license": "MIT",
          "dependencies": {
            "ini": "^1.3.4",
            "proto-list": "~1.2.1"
          }
        },
        "node_modules/content-disposition": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/content-disposition/-/content-disposition-1.1.0.tgz",
          "integrity": "sha512-5jRCH9Z/+DRP7rkvY83B+yGIGX96OYdJmzngqnw2SBSxqCFPd0w2km3s5iawpGX8krnwSGmF0FW5Nhr0Hfai3g==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/content-type": {
          "version": "1.0.5",
          "resolved": "https://registry.npmjs.org/content-type/-/content-type-1.0.5.tgz",
          "integrity": "sha512-nTjqfcBFEipKdXCv4YDQWCfmcLZKm81ldF0pAopTvyrFGVbcR6P/VAAd5G7N+0tTr8QqiU0tFadD6FK4NtJwOA==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.6"
          }
        },
        "node_modules/cookie": {
          "version": "0.7.2",
          "resolved": "https://registry.npmjs.org/cookie/-/cookie-0.7.2.tgz",
          "integrity": "sha512-yki5XnKuf750l50uGTllt6kKILY4nQ1eNIQatoXEByZ5dWgnKqbnqmTrBE5B4N7lrMJKQ2ytWMiTO2o0v6Ew/w==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.6"
          }
        },
        "node_modules/cookie-signature": {
          "version": "1.2.2",
          "resolved": "https://registry.npmjs.org/cookie-signature/-/cookie-signature-1.2.2.tgz",
          "integrity": "sha512-D76uU73ulSXrD1UXF4KE2TMxVVwhsnCgfAyTg9k8P6KGZjlXKrOLe4dJQKI3Bxi5wjesZoFXJWElNWBjPZMbhg==",
          "license": "MIT",
          "engines": {
            "node": ">=6.6.0"
          }
        },
        "node_modules/cors": {
          "version": "2.8.6",
          "resolved": "https://registry.npmjs.org/cors/-/cors-2.8.6.tgz",
          "integrity": "sha512-tJtZBBHA6vjIAaF6EnIaq6laBBP9aq/Y3ouVJjEfoHbRBcHBAHYcMh/w8LDrk2PvIMMq8gmopa5D4V8RmbrxGw==",
          "license": "MIT",
          "dependencies": {
            "object-assign": "^4",
            "vary": "^1"
          },
          "engines": {
            "node": ">= 0.10"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/cross-spawn": {
          "version": "7.0.6",
          "resolved": "https://registry.npmjs.org/cross-spawn/-/cross-spawn-7.0.6.tgz",
          "integrity": "sha512-uV2QOWP2nWzsy2aMp8aRibhi9dlzF5Hgh5SHaB9OiTGEyDTiJJyx0uy51QXdyWbtAHNua4XJzUKca3OzKUd3vA==",
          "license": "MIT",
          "dependencies": {
            "path-key": "^3.1.0",
            "shebang-command": "^2.0.0",
            "which": "^2.0.1"
          },
          "engines": {
            "node": ">= 8"
          }
        },
        "node_modules/debug": {
          "version": "4.4.3",
          "resolved": "https://registry.npmjs.org/debug/-/debug-4.4.3.tgz",
          "integrity": "sha512-RGwwWnwQvkVfavKVt22FGLw+xYSdzARwm0ru6DhTVA3umU5hZc28V3kO4stgYryrTlLpuvgI9GiijltAjNbcqA==",
          "license": "MIT",
          "dependencies": {
            "ms": "^2.1.3"
          },
          "engines": {
            "node": ">=6.0"
          },
          "peerDependenciesMeta": {
            "supports-color": {
              "optional": true
            }
          }
        },
        "node_modules/deepmerge": {
          "version": "4.3.1",
          "resolved": "https://registry.npmjs.org/deepmerge/-/deepmerge-4.3.1.tgz",
          "integrity": "sha512-3sUqbMEc77XqpdNO7FRyRog+eW3ph+GYCbj+rK+uYyRMuwsVy0rMiVtPn+QJlKFvWP/1PYpapqYn0Me2knFn+A==",
          "license": "MIT",
          "engines": {
            "node": ">=0.10.0"
          }
        },
        "node_modules/define-lazy-prop": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/define-lazy-prop/-/define-lazy-prop-2.0.0.tgz",
          "integrity": "sha512-Ds09qNh8yw3khSjiJjiUInaGX9xlqZDY7JVryGxdxV7NPeuqQfplOpQ66yJFZut3jLa5zOwkXw1g9EI2uKh4Og==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/defu": {
          "version": "6.1.7",
          "resolved": "https://registry.npmjs.org/defu/-/defu-6.1.7.tgz",
          "integrity": "sha512-7z22QmUWiQ/2d0KkdYmANbRUVABpZ9SNYyH5vx6PZ+nE5bcC0l7uFvEfHlyld/HcGBFTL536ClDt3DEcSlEJAQ==",
          "license": "MIT"
        },
        "node_modules/depd": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/depd/-/depd-2.0.0.tgz",
          "integrity": "sha512-g7nH6P6dyDioJogAAGprGpCtVImJhpPk/roCzdb3fIh61/s/nPsfR6onyMwkCAR/OlC3yBC0lESvUoQEAssIrw==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/detect-libc": {
          "version": "2.1.2",
          "resolved": "https://registry.npmjs.org/detect-libc/-/detect-libc-2.1.2.tgz",
          "integrity": "sha512-Btj2BOOO83o3WyH59e8MgXsxEQVcarkUOpEYrubB0urwnN10yQ364rsiByU11nZlqWYZm05i/of7io4mzihBtQ==",
          "license": "Apache-2.0",
          "optional": true,
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/diff": {
          "version": "8.0.4",
          "resolved": "https://registry.npmjs.org/diff/-/diff-8.0.4.tgz",
          "integrity": "sha512-DPi0FmjiSU5EvQV0++GFDOJ9ASQUVFh5kD+OzOnYdi7n3Wpm9hWWGfB/O2blfHcMVTL5WkQXSnRiK9makhrcnw==",
          "license": "BSD-3-Clause",
          "engines": {
            "node": ">=0.3.1"
          }
        },
        "node_modules/dom-accessibility-api": {
          "version": "0.7.1",
          "resolved": "https://registry.npmjs.org/dom-accessibility-api/-/dom-accessibility-api-0.7.1.tgz",
          "integrity": "sha512-vdnCeZD+3wZ+8h8xXL/ZtBlvvoobOFyPzSiIfO6sGOZDqjFx4aLMAjZhl4rawj5xYz3UwP6Tgvyh0iH4IOCVnQ==",
          "license": "MIT"
        },
        "node_modules/dom-serializer": {
          "version": "1.4.1",
          "resolved": "https://registry.npmjs.org/dom-serializer/-/dom-serializer-1.4.1.tgz",
          "integrity": "sha512-VHwB3KfrcOOkelEG2ZOfxqLZdfkil8PtJi4P8N2MMXucZq2yLp75ClViUlOVwyoHEDjYU433Aq+5zWP61+RGag==",
          "license": "MIT",
          "dependencies": {
            "domelementtype": "^2.0.1",
            "domhandler": "^4.2.0",
            "entities": "^2.0.0"
          },
          "funding": {
            "url": "https://github.com/cheeriojs/dom-serializer?sponsor=1"
          }
        },
        "node_modules/dom-serializer/node_modules/entities": {
          "version": "2.2.0",
          "resolved": "https://registry.npmjs.org/entities/-/entities-2.2.0.tgz",
          "integrity": "sha512-p92if5Nz619I0w+akJrLZH0MX0Pb5DX39XOwQTtXSdQQOaYH03S1uIQp4mhOZtAXrxq4ViO67YTiLBo2638o9A==",
          "license": "BSD-2-Clause",
          "funding": {
            "url": "https://github.com/fb55/entities?sponsor=1"
          }
        },
        "node_modules/domelementtype": {
          "version": "2.3.0",
          "resolved": "https://registry.npmjs.org/domelementtype/-/domelementtype-2.3.0.tgz",
          "integrity": "sha512-OLETBj6w0OsagBwdXnPdN0cnMfF9opN69co+7ZrbfPGrdpPVNBUj02spi6B1N7wChLQiPn4CSH/zJvXw56gmHw==",
          "funding": [
            {
              "type": "github",
              "url": "https://github.com/sponsors/fb55"
            }
          ],
          "license": "BSD-2-Clause"
        },
        "node_modules/domhandler": {
          "version": "4.3.1",
          "resolved": "https://registry.npmjs.org/domhandler/-/domhandler-4.3.1.tgz",
          "integrity": "sha512-GrwoxYN+uWlzO8uhUXRl0P+kHE4GtVPfYzVLcUxPL7KNdHKj66vvlhiweIHqYYXWlw+T8iLMp42Lm67ghw4WMQ==",
          "license": "BSD-2-Clause",
          "dependencies": {
            "domelementtype": "^2.2.0"
          },
          "engines": {
            "node": ">= 4"
          },
          "funding": {
            "url": "https://github.com/fb55/domhandler?sponsor=1"
          }
        },
        "node_modules/domutils": {
          "version": "2.8.0",
          "resolved": "https://registry.npmjs.org/domutils/-/domutils-2.8.0.tgz",
          "integrity": "sha512-w96Cjofp72M5IIhpjgobBimYEfoPjx1Vx0BSX9P30WBdZW2WIKU0T1Bd0kz2eNZ9ikjKgHbEyKx8BB6H1L3h3A==",
          "license": "BSD-2-Clause",
          "dependencies": {
            "dom-serializer": "^1.0.1",
            "domelementtype": "^2.2.0",
            "domhandler": "^4.2.0"
          },
          "funding": {
            "url": "https://github.com/fb55/domutils?sponsor=1"
          }
        },
        "node_modules/dotenv": {
          "version": "16.6.1",
          "resolved": "https://registry.npmjs.org/dotenv/-/dotenv-16.6.1.tgz",
          "integrity": "sha512-uBq4egWHTcTt33a72vpSG0z3HnPuIl6NqYcTrKEg2azoEyl2hpW0zqlxysq2pK9HlDIHyHyakeYaYnSAwd8bow==",
          "license": "BSD-2-Clause",
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://dotenvx.com"
          }
        },
        "node_modules/dunder-proto": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/dunder-proto/-/dunder-proto-1.0.1.tgz",
          "integrity": "sha512-KIN/nDJBQRcXw0MLVhZE9iQHmG68qAVIBg9CqmUYjmQIhgij9U5MFvrqkUL5FbtyyzZuOeOt0zdeRe4UY7ct+A==",
          "license": "MIT",
          "dependencies": {
            "call-bind-apply-helpers": "^1.0.1",
            "es-errors": "^1.3.0",
            "gopd": "^1.2.0"
          },
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/eastasianwidth": {
          "version": "0.2.0",
          "resolved": "https://registry.npmjs.org/eastasianwidth/-/eastasianwidth-0.2.0.tgz",
          "integrity": "sha512-I88TYZWc9XiYHRQ4/3c5rjjfgkjhLyW2luGIheGERbNQ6OY7yTybanSpDXZa8y7VUP9YmDcYa+eyq4ca7iLqWA==",
          "license": "MIT"
        },
        "node_modules/editorconfig": {
          "version": "1.0.7",
          "resolved": "https://registry.npmjs.org/editorconfig/-/editorconfig-1.0.7.tgz",
          "integrity": "sha512-e0GOtq/aTQhVdNyDU9e02+wz9oDDM+SIOQxWME2QRjzRX5yyLAuHDE+0aE8vHb9XRC8XD37eO2u57+F09JqFhw==",
          "license": "MIT",
          "dependencies": {
            "@one-ini/wasm": "0.1.1",
            "commander": "^10.0.0",
            "minimatch": "^9.0.1",
            "semver": "^7.5.3"
          },
          "bin": {
            "editorconfig": "bin/editorconfig"
          },
          "engines": {
            "node": ">=14"
          }
        },
        "node_modules/editorconfig/node_modules/brace-expansion": {
          "version": "2.1.4",
          "resolved": "https://registry.npmjs.org/brace-expansion/-/brace-expansion-2.1.4.tgz",
          "integrity": "sha512-hGfVzPxthbf3+2yjg/RBs60cB0FhqBS/zvdV/4wn4/BmN0bNMMHPc4V/BbFieqf1TKAGGAHnY4eSjajCl0f2Xg==",
          "license": "MIT",
          "dependencies": {
            "balanced-match": "^1.0.0"
          }
        },
        "node_modules/editorconfig/node_modules/commander": {
          "version": "10.0.1",
          "resolved": "https://registry.npmjs.org/commander/-/commander-10.0.1.tgz",
          "integrity": "sha512-y4Mg2tXshplEbSGzx7amzPwKKOCGuoSRP/CjEdwwk0FOGlUbq6lKuoyDZTNZkmxHdJtp54hdfY/JUrdL7Xfdug==",
          "license": "MIT",
          "engines": {
            "node": ">=14"
          }
        },
        "node_modules/editorconfig/node_modules/minimatch": {
          "version": "9.0.9",
          "resolved": "https://registry.npmjs.org/minimatch/-/minimatch-9.0.9.tgz",
          "integrity": "sha512-OBwBN9AL4dqmETlpS2zasx+vTeWclWzkblfZk7KTA5j3jeOONz/tRCnZomUyvNg83wL5Zv9Ss6HMJXAgL8R2Yg==",
          "license": "ISC",
          "dependencies": {
            "brace-expansion": "^2.0.2"
          },
          "engines": {
            "node": ">=16 || 14 >=14.17"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          }
        },
        "node_modules/ee-first": {
          "version": "1.1.1",
          "resolved": "https://registry.npmjs.org/ee-first/-/ee-first-1.1.1.tgz",
          "integrity": "sha512-WMwm9LhRUo+WUaRN+vRuETqG89IgZphVSNkdFgeb6sS/E4OrDIN7t48CAewSHXc6C8lefD8KKfr5vY61brQlow==",
          "license": "MIT"
        },
        "node_modules/emoji-regex": {
          "version": "9.2.2",
          "resolved": "https://registry.npmjs.org/emoji-regex/-/emoji-regex-9.2.2.tgz",
          "integrity": "sha512-L18DaJsXSUk2+42pv8mLs5jJT2hqFkFE4j21wOmgbUqsZ2hL72NsUU785g9RXgo3s0ZNgVl42TiHp3ZtOv/Vyg==",
          "license": "MIT"
        },
        "node_modules/encodeurl": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/encodeurl/-/encodeurl-2.0.0.tgz",
          "integrity": "sha512-Q0n9HRi4m6JuGIV1eFlmvJB7ZEVxu93IrMyiMsGC0lrMJMWzRgx6WGquyfQgZVb31vhGgXnfmPNNXmxnOkRBrg==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/end-of-stream": {
          "version": "1.4.5",
          "resolved": "https://registry.npmjs.org/end-of-stream/-/end-of-stream-1.4.5.tgz",
          "integrity": "sha512-ooEGc6HP26xXq/N+GCGOT0JKCLDGrq2bQUZrQ7gyrJiZANJ/8YDTxTpQBXGMn+WbIQXNVpyWymm7KYVICQnyOg==",
          "license": "MIT",
          "dependencies": {
            "once": "^1.4.0"
          }
        },
        "node_modules/entities": {
          "version": "3.0.1",
          "resolved": "https://registry.npmjs.org/entities/-/entities-3.0.1.tgz",
          "integrity": "sha512-WiyBqoomrwMdFG1e0kqvASYfnlb0lp8M5o5Fw2OFq1hNZxxcNk8Ik0Xm7LxzBhuidnZB/UtBqVCgUz3kBOP51Q==",
          "license": "BSD-2-Clause",
          "engines": {
            "node": ">=0.12"
          },
          "funding": {
            "url": "https://github.com/fb55/entities?sponsor=1"
          }
        },
        "node_modules/es-define-property": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/es-define-property/-/es-define-property-1.0.1.tgz",
          "integrity": "sha512-e3nRfgfUZ4rNGL232gUgX06QNyyez04KdjFrF+LTRoOXmrOgFKDg4BCdsjW8EnT69eqdYGmRpJwiPVYNrCaW3g==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/es-errors": {
          "version": "1.3.0",
          "resolved": "https://registry.npmjs.org/es-errors/-/es-errors-1.3.0.tgz",
          "integrity": "sha512-Zf5H2Kxt2xjTvbJvP2ZWLEICxA6j+hAmMzIlypy4xcBg1vKVnx89Wy0GbS+kf5cwCVFFzdCFh2XSCFNULS6csw==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/es-object-atoms": {
          "version": "1.1.2",
          "resolved": "https://registry.npmjs.org/es-object-atoms/-/es-object-atoms-1.1.2.tgz",
          "integrity": "sha512-HWcBoN6NileqtSydK2FqHbS/LoDd2pqrnQHLyJzBj4kOp/ky2MWMN694xOfkK8/SnUsW2DH7EfyVlydKCsm1Zw==",
          "license": "MIT",
          "dependencies": {
            "es-errors": "^1.3.0"
          },
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/escape-html": {
          "version": "1.0.3",
          "resolved": "https://registry.npmjs.org/escape-html/-/escape-html-1.0.3.tgz",
          "integrity": "sha512-NiSupZ4OeuGwr68lGIeym/ksIZMJodUGOSCZ/FSnTxcrekbvqrgdUxlJOMpijaKZVjAJrWrGs/6Jy8OMuyj9ow==",
          "license": "MIT"
        },
        "node_modules/etag": {
          "version": "1.8.1",
          "resolved": "https://registry.npmjs.org/etag/-/etag-1.8.1.tgz",
          "integrity": "sha512-aIL5Fx7mawVa300al2BnEE4iNvo1qETxLrPI/o05L7z6go7fCw1J6EQmbK4FmJ2AS7kgVF/KEZWufBfdClMcPg==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.6"
          }
        },
        "node_modules/eventsource": {
          "version": "3.0.7",
          "resolved": "https://registry.npmjs.org/eventsource/-/eventsource-3.0.7.tgz",
          "integrity": "sha512-CRT1WTyuQoD771GW56XEZFQ/ZoSfWid1alKGDYMmkt2yl8UXrVR4pspqWNEcqKvVIzg6PAltWjxcSSPrboA4iA==",
          "license": "MIT",
          "dependencies": {
            "eventsource-parser": "^3.0.1"
          },
          "engines": {
            "node": ">=18.0.0"
          }
        },
        "node_modules/eventsource-parser": {
          "version": "3.1.1",
          "resolved": "https://registry.npmjs.org/eventsource-parser/-/eventsource-parser-3.1.1.tgz",
          "integrity": "sha512-EKN1vKAMcZ8MlYMpaNuxN6R9yakzH6uajHcHVTqWJzvu5pWw9DyhbP35HH8MVBQ+dZjAfDxk+A8NiR9KWaXiyQ==",
          "license": "MIT",
          "engines": {
            "node": ">=18.0.0"
          }
        },
        "node_modules/express": {
          "version": "5.2.1",
          "resolved": "https://registry.npmjs.org/express/-/express-5.2.1.tgz",
          "integrity": "sha512-hIS4idWWai69NezIdRt2xFVofaF4j+6INOpJlVOLDO8zXGpUVEVzIYk12UUi2JzjEzWL3IOAxcTubgz9Po0yXw==",
          "license": "MIT",
          "dependencies": {
            "accepts": "^2.0.0",
            "body-parser": "^2.2.1",
            "content-disposition": "^1.0.0",
            "content-type": "^1.0.5",
            "cookie": "^0.7.1",
            "cookie-signature": "^1.2.1",
            "debug": "^4.4.0",
            "depd": "^2.0.0",
            "encodeurl": "^2.0.0",
            "escape-html": "^1.0.3",
            "etag": "^1.8.1",
            "finalhandler": "^2.1.0",
            "fresh": "^2.0.0",
            "http-errors": "^2.0.0",
            "merge-descriptors": "^2.0.0",
            "mime-types": "^3.0.0",
            "on-finished": "^2.4.1",
            "once": "^1.4.0",
            "parseurl": "^1.3.3",
            "proxy-addr": "^2.0.7",
            "qs": "^6.14.0",
            "range-parser": "^1.2.1",
            "router": "^2.2.0",
            "send": "^1.1.0",
            "serve-static": "^2.2.0",
            "statuses": "^2.0.1",
            "type-is": "^2.0.1",
            "vary": "^1.1.2"
          },
          "engines": {
            "node": ">= 18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/express-rate-limit": {
          "version": "8.7.0",
          "resolved": "https://registry.npmjs.org/express-rate-limit/-/express-rate-limit-8.7.0.tgz",
          "integrity": "sha512-hOwV7WOxXfjRpAM1DSJWZDXx3GhplwD8IfwuwvogD8i1Qnkgosw/H45s4ZnFAUHDAhPjlY9hLBvJhKmGMyY26g==",
          "license": "MIT",
          "dependencies": {
            "debug": "^4.4.3",
            "ip-address": "^10.2.0"
          },
          "engines": {
            "node": ">= 16"
          },
          "funding": {
            "url": "https://github.com/sponsors/express-rate-limit"
          },
          "peerDependencies": {
            "express": ">= 4.11"
          }
        },
        "node_modules/fast-deep-equal": {
          "version": "3.1.3",
          "resolved": "https://registry.npmjs.org/fast-deep-equal/-/fast-deep-equal-3.1.3.tgz",
          "integrity": "sha512-f3qQ9oQy9j2AhBe/H9VC91wLmKBCCU/gDOnKNAYG5hswO7BLKj09Hc5HYNz9cGI++xlpDCIgDaitVs03ATR84Q==",
          "license": "MIT"
        },
        "node_modules/fast-uri": {
          "version": "3.1.6",
          "resolved": "https://registry.npmjs.org/fast-uri/-/fast-uri-3.1.6.tgz",
          "integrity": "sha512-7Ical1vFEMr0onbVzEDIreM22I4khW+fzyQPwvAFWBp1iwdshSZRsL4jjRvPG9JP1uiqMHRto+YU6R2/CzDz5Q==",
          "funding": [
            {
              "type": "github",
              "url": "https://github.com/sponsors/fastify"
            },
            {
              "type": "opencollective",
              "url": "https://opencollective.com/fastify"
            }
          ],
          "license": "BSD-3-Clause"
        },
        "node_modules/finalhandler": {
          "version": "2.1.1",
          "resolved": "https://registry.npmjs.org/finalhandler/-/finalhandler-2.1.1.tgz",
          "integrity": "sha512-S8KoZgRZN+a5rNwqTxlZZePjT/4cnm0ROV70LedRHZ0p8u9fRID0hJUZQpkKLzro8LfmC8sx23bY6tVNxv8pQA==",
          "license": "MIT",
          "dependencies": {
            "debug": "^4.4.0",
            "encodeurl": "^2.0.0",
            "escape-html": "^1.0.3",
            "on-finished": "^2.4.1",
            "parseurl": "^1.3.3",
            "statuses": "^2.0.1"
          },
          "engines": {
            "node": ">= 18.0.0"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/foreground-child": {
          "version": "3.3.1",
          "resolved": "https://registry.npmjs.org/foreground-child/-/foreground-child-3.3.1.tgz",
          "integrity": "sha512-gIXjKqtFuWEgzFRJA9WCQeSJLZDjgJUOMCMzxtvFq/37KojM1BFGufqsCy0r4qSQmYLsZYMeyRqzIWOMup03sw==",
          "license": "ISC",
          "dependencies": {
            "cross-spawn": "^7.0.6",
            "signal-exit": "^4.0.1"
          },
          "engines": {
            "node": ">=14"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          }
        },
        "node_modules/forwarded": {
          "version": "0.2.0",
          "resolved": "https://registry.npmjs.org/forwarded/-/forwarded-0.2.0.tgz",
          "integrity": "sha512-buRG0fpBtRHSTCOASe6hD258tEubFoRLb4ZNA6NxMVHNw2gOcwHo9wyablzMzOA5z9xA9L1KNjk/Nt6MT9aYow==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.6"
          }
        },
        "node_modules/fresh": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/fresh/-/fresh-2.0.0.tgz",
          "integrity": "sha512-Rx/WycZ60HOaqLKAi6cHRKKI7zxWbJ31MhntmtwMoaTeF7XFH9hhBp8vITaMidfljRQ6eYWCKkaTK+ykVJHP2A==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/function-bind": {
          "version": "1.1.2",
          "resolved": "https://registry.npmjs.org/function-bind/-/function-bind-1.1.2.tgz",
          "integrity": "sha512-7XHNxH7qX9xG5mIwxkhumTox/MIRNcOgDrxWsMt2pAr23WHp6MrRlN7FBSFpCpr+oVO0F744iUgR82nJMfG2SA==",
          "license": "MIT",
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/get-intrinsic": {
          "version": "1.3.0",
          "resolved": "https://registry.npmjs.org/get-intrinsic/-/get-intrinsic-1.3.0.tgz",
          "integrity": "sha512-9fSjSaos/fRIVIp+xSJlE6lfwhES7LNtKaCBIamHsjr2na1BiABJPo0mOjjz8GJDURarmCPGqaiVg5mfjb98CQ==",
          "license": "MIT",
          "dependencies": {
            "call-bind-apply-helpers": "^1.0.2",
            "es-define-property": "^1.0.1",
            "es-errors": "^1.3.0",
            "es-object-atoms": "^1.1.1",
            "function-bind": "^1.1.2",
            "get-proto": "^1.0.1",
            "gopd": "^1.2.0",
            "has-symbols": "^1.1.0",
            "hasown": "^2.0.2",
            "math-intrinsics": "^1.1.0"
          },
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/get-proto": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/get-proto/-/get-proto-1.0.1.tgz",
          "integrity": "sha512-sTSfBjoXBp89JvIKIefqw7U2CCebsc74kiY6awiGogKtoSGbgjYE/G/+l9sF3MWFPNc9IcoOC4ODfKHfxFmp0g==",
          "license": "MIT",
          "dependencies": {
            "dunder-proto": "^1.0.1",
            "es-object-atoms": "^1.0.0"
          },
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/get-stream": {
          "version": "5.2.0",
          "resolved": "https://registry.npmjs.org/get-stream/-/get-stream-5.2.0.tgz",
          "integrity": "sha512-nBF+F1rAZVCu/p7rjzgA+Yb4lfYXrpl7a6VmJrU8wF9I1CKvP/QwPNZHnOlwbTkY6dvtFIzFMSyQXbLoTQPRpA==",
          "license": "MIT",
          "dependencies": {
            "pump": "^3.0.0"
          },
          "engines": {
            "node": ">=8"
          },
          "funding": {
            "url": "https://github.com/sponsors/sindresorhus"
          }
        },
        "node_modules/glob": {
          "version": "10.5.0",
          "resolved": "https://registry.npmjs.org/glob/-/glob-10.5.0.tgz",
          "integrity": "sha512-DfXN8DfhJ7NH3Oe7cFmu3NCu1wKbkReJ8TorzSAFbSKrlNaQSKfIzqYqVY8zlbs2NLBbWpRiU52GX2PbaBVNkg==",
          "deprecated": "Old versions of glob are not supported, and contain widely publicized security vulnerabilities, which have been fixed in the current version. Please update. Support for old versions may be purchased (at exorbitant rates) by contacting i@izs.me",
          "license": "ISC",
          "dependencies": {
            "foreground-child": "^3.1.0",
            "jackspeak": "^3.1.2",
            "minimatch": "^9.0.4",
            "minipass": "^7.1.2",
            "package-json-from-dist": "^1.0.0",
            "path-scurry": "^1.11.1"
          },
          "bin": {
            "glob": "dist/esm/bin.mjs"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          }
        },
        "node_modules/glob/node_modules/brace-expansion": {
          "version": "2.1.4",
          "resolved": "https://registry.npmjs.org/brace-expansion/-/brace-expansion-2.1.4.tgz",
          "integrity": "sha512-hGfVzPxthbf3+2yjg/RBs60cB0FhqBS/zvdV/4wn4/BmN0bNMMHPc4V/BbFieqf1TKAGGAHnY4eSjajCl0f2Xg==",
          "license": "MIT",
          "dependencies": {
            "balanced-match": "^1.0.0"
          }
        },
        "node_modules/glob/node_modules/minimatch": {
          "version": "9.0.9",
          "resolved": "https://registry.npmjs.org/minimatch/-/minimatch-9.0.9.tgz",
          "integrity": "sha512-OBwBN9AL4dqmETlpS2zasx+vTeWclWzkblfZk7KTA5j3jeOONz/tRCnZomUyvNg83wL5Zv9Ss6HMJXAgL8R2Yg==",
          "license": "ISC",
          "dependencies": {
            "brace-expansion": "^2.0.2"
          },
          "engines": {
            "node": ">=16 || 14 >=14.17"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          }
        },
        "node_modules/goke": {
          "version": "6.14.1",
          "resolved": "https://registry.npmjs.org/goke/-/goke-6.14.1.tgz",
          "integrity": "sha512-ttrqT/tfynw+0AnV7+0GZQomYr2/mlQ+UCmXL2jJEF6GNXSVPXLOvTVnyqTP9xKbW9oTsrLkAXmr42hQEKZ20Q==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          }
        },
        "node_modules/gopd": {
          "version": "1.2.0",
          "resolved": "https://registry.npmjs.org/gopd/-/gopd-1.2.0.tgz",
          "integrity": "sha512-ZUKRh6/kUFoAiTAtTYPZJ3hw9wNxx+BIBOijnlG9PnrJsCcSjs1wyyD6vJpaYtgnzDrKYRSqf3OO6Rfa93xsRg==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/graceful-fs": {
          "version": "4.2.11",
          "resolved": "https://registry.npmjs.org/graceful-fs/-/graceful-fs-4.2.11.tgz",
          "integrity": "sha512-RbJ5/jmFcNNCcDV5o9eTnBLJ/HszWV0P73bc+Ff4nS/rJj+YaS6IGyiOL0VoBYX+l1Wrl3k63h/KrH+nhJ0XvQ==",
          "license": "ISC"
        },
        "node_modules/has-symbols": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/has-symbols/-/has-symbols-1.1.0.tgz",
          "integrity": "sha512-1cDNdwJ2Jaohmb3sg4OmKaMBwuC48sYni5HUw2DvsC8LjGTLK9h+eb1X6RyuOHe4hT0ULCW68iomhjUoKUqlPQ==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/hasown": {
          "version": "2.0.4",
          "resolved": "https://registry.npmjs.org/hasown/-/hasown-2.0.4.tgz",
          "integrity": "sha512-T2UbfbBEF32wiepXIsMlTW9+dDYC6wMh/t/vYA4tuOMKqWz/n3vr1NFSxQiyP+zk2mXsoMA/i/7qV6LKut1t1A==",
          "license": "MIT",
          "dependencies": {
            "function-bind": "^1.1.2"
          },
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/hono": {
          "version": "4.13.5",
          "resolved": "https://registry.npmjs.org/hono/-/hono-4.13.5.tgz",
          "integrity": "sha512-O6+/eCYRkzzzy0rPWwKLiGBR1nFuUPZynnwjxN1MBA62NNqbT0wQEzQyK2gSO5yDIDB336sXQleAhOHrzlYyKw==",
          "license": "MIT",
          "engines": {
            "node": ">=16.9.0"
          }
        },
        "node_modules/htmlparser2": {
          "version": "7.2.0",
          "resolved": "https://registry.npmjs.org/htmlparser2/-/htmlparser2-7.2.0.tgz",
          "integrity": "sha512-H7MImA4MS6cw7nbyURtLPO1Tms7C5H602LRETv95z1MxO/7CP7rDVROehUYeYBUYEON94NXXDEPmZuq+hX4sog==",
          "funding": [
            "https://github.com/fb55/htmlparser2?sponsor=1",
            {
              "type": "github",
              "url": "https://github.com/sponsors/fb55"
            }
          ],
          "license": "MIT",
          "dependencies": {
            "domelementtype": "^2.0.1",
            "domhandler": "^4.2.2",
            "domutils": "^2.8.0",
            "entities": "^3.0.1"
          }
        },
        "node_modules/http-errors": {
          "version": "2.0.1",
          "resolved": "https://registry.npmjs.org/http-errors/-/http-errors-2.0.1.tgz",
          "integrity": "sha512-4FbRdAX+bSdmo4AUFuS0WNiPz8NgFt+r8ThgNWmlrjQjt1Q7ZR9+zTlce2859x4KSXrwIsaeTqDoKQmtP8pLmQ==",
          "license": "MIT",
          "dependencies": {
            "depd": "~2.0.0",
            "inherits": "~2.0.4",
            "setprototypeof": "~1.2.0",
            "statuses": "~2.0.2",
            "toidentifier": "~1.0.1"
          },
          "engines": {
            "node": ">= 0.8"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/https-proxy-agent": {
          "version": "7.0.6",
          "resolved": "https://registry.npmjs.org/https-proxy-agent/-/https-proxy-agent-7.0.6.tgz",
          "integrity": "sha512-vK9P5/iUfdl95AI+JVyUuIcVtd4ofvtrOr3HNtM2yxC9bnMbEdp3x01OhQNnjb8IJYi38VlTE3mBXwcfvywuSw==",
          "license": "MIT",
          "dependencies": {
            "agent-base": "^7.1.2",
            "debug": "4"
          },
          "engines": {
            "node": ">= 14"
          }
        },
        "node_modules/iconv-lite": {
          "version": "0.7.3",
          "resolved": "https://registry.npmjs.org/iconv-lite/-/iconv-lite-0.7.3.tgz",
          "integrity": "sha512-IKXpvIzjnC9XTAUbVBcMfGS0EPaIXtW6v+zr+RRp+hqULEpo0owZax6wyRwPOJbWbzjYspQwusTsfVr0ifh4uQ==",
          "license": "MIT",
          "dependencies": {
            "safer-buffer": ">= 2.1.2 < 3.0.0"
          },
          "engines": {
            "node": ">=0.10.0"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/inherits": {
          "version": "2.0.4",
          "resolved": "https://registry.npmjs.org/inherits/-/inherits-2.0.4.tgz",
          "integrity": "sha512-k/vGaX4/Yla3WzyMCvTQOXYeIHvqOKtnqBduzTHpzpQZzAskKMhZ2K+EnBiSM9zGSoIFeMpXKxa4dYeZIQqewQ==",
          "license": "ISC"
        },
        "node_modules/ini": {
          "version": "1.3.8",
          "resolved": "https://registry.npmjs.org/ini/-/ini-1.3.8.tgz",
          "integrity": "sha512-JV/yugV2uzW5iMRSiZAyDtQd+nxtUnjeLt0acNdw98kKLrvuRVyB80tsREOE7yvGVgalhZ6RNXCmEHkUKBKxew==",
          "license": "ISC"
        },
        "node_modules/ip-address": {
          "version": "10.7.0",
          "resolved": "https://registry.npmjs.org/ip-address/-/ip-address-10.7.0.tgz",
          "integrity": "sha512-BGFsyJd5mpXp3rK6jIdADLNgpJUK1jnjzvYF8lK+VyDab9JAmqN0YOKDdP17HlgKb2+ehPgDc8EtnRLbGCAMhA==",
          "license": "MIT",
          "engines": {
            "node": ">= 12"
          }
        },
        "node_modules/ipaddr.js": {
          "version": "1.9.1",
          "resolved": "https://registry.npmjs.org/ipaddr.js/-/ipaddr.js-1.9.1.tgz",
          "integrity": "sha512-0KI/607xoxSToH7GjN1FfSbLoU0+btTicjsQSWQlh/hZykN8KpmMf7uYwPW3R+akZ6R/w18ZlXSHBYXiYUPO3g==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.10"
          }
        },
        "node_modules/is-docker": {
          "version": "2.2.1",
          "resolved": "https://registry.npmjs.org/is-docker/-/is-docker-2.2.1.tgz",
          "integrity": "sha512-F+i2BKsFrH66iaUFc0woD8sLy8getkwTwtOBjvs56Cx4CgJDeKQeqfz8wAYiSb8JOprWhHH5p77PbmYCvvUuXQ==",
          "license": "MIT",
          "bin": {
            "is-docker": "cli.js"
          },
          "engines": {
            "node": ">=8"
          },
          "funding": {
            "url": "https://github.com/sponsors/sindresorhus"
          }
        },
        "node_modules/is-fullwidth-code-point": {
          "version": "3.0.0",
          "resolved": "https://registry.npmjs.org/is-fullwidth-code-point/-/is-fullwidth-code-point-3.0.0.tgz",
          "integrity": "sha512-zymm5+u+sCsSWyD9qNaejV3DFvhCKclKdizYaJUuHA83RLjb7nSuGnddCHGv0hk+KY7BMAlsWeK4Ueg6EV6XQg==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/is-json": {
          "version": "2.0.1",
          "resolved": "https://registry.npmjs.org/is-json/-/is-json-2.0.1.tgz",
          "integrity": "sha512-6BEnpVn1rcf3ngfmViLM6vjUjGErbdrL4rwlv+u1NO1XO8kqT4YGL8+19Q+Z/bas8tY90BTWMk2+fW1g6hQjbA==",
          "license": "ISC"
        },
        "node_modules/is-promise": {
          "version": "4.0.0",
          "resolved": "https://registry.npmjs.org/is-promise/-/is-promise-4.0.0.tgz",
          "integrity": "sha512-hvpoI6korhJMnej285dSg6nu1+e6uxs7zG3BYAm5byqDsgJNWwxzM6z6iZiAgQR4TJ30JmBTOwqZUw3WlyH3AQ==",
          "license": "MIT"
        },
        "node_modules/is-wsl": {
          "version": "2.2.0",
          "resolved": "https://registry.npmjs.org/is-wsl/-/is-wsl-2.2.0.tgz",
          "integrity": "sha512-fKzAra0rGJUUBwGBgNkHZuToZcn+TtXHpeCgmkMJMMYx1sQDYaCSyjJBSCa2nH1DGm7s3n1oBnohoVTBaN7Lww==",
          "license": "MIT",
          "dependencies": {
            "is-docker": "^2.0.0"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/isexe": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/isexe/-/isexe-2.0.0.tgz",
          "integrity": "sha512-RHxMLp9lnKHGHRng9QFhRCMbYAcVpn69smSGcq3f36xjgVVWThj4qqLbTLlq7Ssj8B+fIQ1EuCEGI2lKsyQeIw==",
          "license": "ISC"
        },
        "node_modules/jackspeak": {
          "version": "3.4.3",
          "resolved": "https://registry.npmjs.org/jackspeak/-/jackspeak-3.4.3.tgz",
          "integrity": "sha512-OGlZQpz2yfahA/Rd1Y8Cd9SIEsqvXkLVoSw/cgwhnhFMDbsQFeZYoJJ7bIZBS9BcamUW96asq/npPWugM+RQBw==",
          "license": "BlueOak-1.0.0",
          "dependencies": {
            "@isaacs/cliui": "^8.0.2"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          },
          "optionalDependencies": {
            "@pkgjs/parseargs": "^0.11.0"
          }
        },
        "node_modules/jose": {
          "version": "6.2.10",
          "resolved": "https://registry.npmjs.org/jose/-/jose-6.2.10.tgz",
          "integrity": "sha512-iiW7J9qRFlGxvCOIBDBDxFePQSn7ZMAnrYGhrrOo6siO/MIqwfyilLR27pkfDgUk+raLuzADS8A3S/KLBisc0g==",
          "license": "MIT",
          "funding": {
            "url": "https://github.com/sponsors/panva"
          }
        },
        "node_modules/jpeg-js": {
          "version": "0.4.4",
          "resolved": "https://registry.npmjs.org/jpeg-js/-/jpeg-js-0.4.4.tgz",
          "integrity": "sha512-WZzeDOEtTOBK4Mdsar0IqEU5sMr3vSV2RqkAIzUEV2BHnUfKGyswWFPFwK5EeDo93K3FohSHbLAjj0s1Wzd+dg==",
          "license": "BSD-3-Clause"
        },
        "node_modules/js-beautify": {
          "version": "1.15.4",
          "resolved": "https://registry.npmjs.org/js-beautify/-/js-beautify-1.15.4.tgz",
          "integrity": "sha512-9/KXeZUKKJwqCXUdBxFJ3vPh467OCckSBmYDwSK/EtV090K+iMJ7zx2S3HLVDIWFQdqMIsZWbnaGiba18aWhaA==",
          "license": "MIT",
          "dependencies": {
            "config-chain": "^1.1.13",
            "editorconfig": "^1.0.4",
            "glob": "^10.4.2",
            "js-cookie": "^3.0.5",
            "nopt": "^7.2.1"
          },
          "bin": {
            "css-beautify": "js/bin/css-beautify.js",
            "html-beautify": "js/bin/html-beautify.js",
            "js-beautify": "js/bin/js-beautify.js"
          },
          "engines": {
            "node": ">=14"
          }
        },
        "node_modules/js-cookie": {
          "version": "3.0.8",
          "resolved": "https://registry.npmjs.org/js-cookie/-/js-cookie-3.0.8.tgz",
          "integrity": "sha512-yeJd4aNAdYZQjaon2bpD/Gb0B/omw7HQOsynXXcOiWVCacbBcPlgn8S/d1X6blFSaHao7ozqtW7NZW19xpCtIw==",
          "license": "MIT"
        },
        "node_modules/json-schema-traverse": {
          "version": "1.0.0",
          "resolved": "https://registry.npmjs.org/json-schema-traverse/-/json-schema-traverse-1.0.0.tgz",
          "integrity": "sha512-NM8/P9n3XjXhIZn1lLhkFaACTOURQXjWhV4BA/RnOv8xvgqtqpAX9IO4mRQxSx1Rlo4tqzeqb0sOlruaOy3dug==",
          "license": "MIT"
        },
        "node_modules/json-schema-typed": {
          "version": "8.0.2",
          "resolved": "https://registry.npmjs.org/json-schema-typed/-/json-schema-typed-8.0.2.tgz",
          "integrity": "sha512-fQhoXdcvc3V28x7C7BMs4P5+kNlgUURe2jmUT1T//oBRMDrqy1QPelJimwZGo7Hg9VPV3EQV5Bnq4hbFy2vetA==",
          "license": "BSD-2-Clause"
        },
        "node_modules/kysely": {
          "version": "0.29.5",
          "resolved": "https://registry.npmjs.org/kysely/-/kysely-0.29.5.tgz",
          "integrity": "sha512-ooa+eSbBNPTo3MycPEuW5jdrxQdQwdtB3LC3h43FiXQbIry5tR0C5lDG7eealK0E4D7XjrnOP5DIUg/LyjRMYQ==",
          "license": "MIT",
          "engines": {
            "node": ">=22.0.0"
          }
        },
        "node_modules/lru-cache": {
          "version": "10.4.3",
          "resolved": "https://registry.npmjs.org/lru-cache/-/lru-cache-10.4.3.tgz",
          "integrity": "sha512-JNAzZcXrCt42VGLuYz0zfAzDfAvJWW6AfYlDBQyDV5DClI2m5sAmK+OIO7s59XfsRsWHp02jAJrRadPRGTt6SQ==",
          "license": "ISC"
        },
        "node_modules/math-intrinsics": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/math-intrinsics/-/math-intrinsics-1.1.0.tgz",
          "integrity": "sha512-/IXtbwEk5HTPyEwyKX6hGkYXxM9nbj64B+ilVJnC/R6B0pH5G4V3b0pVbL7DBj4tkhBAppbQUlf6F6Xl9LHu1g==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.4"
          }
        },
        "node_modules/media-typer": {
          "version": "1.1.1",
          "resolved": "https://registry.npmjs.org/media-typer/-/media-typer-1.1.1.tgz",
          "integrity": "sha512-yz3xRaG20c6/BOzvYoDaGtPmGscs7YivItZEEqe6GbwNfHuxu9YNmvnEkMzKldAGY4/80pRcQRZSEnhquk9XuQ==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/merge-descriptors": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/merge-descriptors/-/merge-descriptors-2.0.0.tgz",
          "integrity": "sha512-Snk314V5ayFLhp3fkUREub6WtjBfPdCPY1Ln8/8munuLuiYhsABgBVWsozAG+MWMbVEvcdcpbi9R7ww22l9Q3g==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "url": "https://github.com/sponsors/sindresorhus"
          }
        },
        "node_modules/mime": {
          "version": "3.0.0",
          "resolved": "https://registry.npmjs.org/mime/-/mime-3.0.0.tgz",
          "integrity": "sha512-jSCU7/VB1loIWBZe14aEYHU/+1UMEHoaO7qxCOVJOw9GgH72VAWppxNcjU+x9a2k3GSIBXNKxXQFqRvvZ7vr3A==",
          "license": "MIT",
          "bin": {
            "mime": "cli.js"
          },
          "engines": {
            "node": ">=10.0.0"
          }
        },
        "node_modules/mime-db": {
          "version": "1.54.0",
          "resolved": "https://registry.npmjs.org/mime-db/-/mime-db-1.54.0.tgz",
          "integrity": "sha512-aU5EJuIN2WDemCcAp2vFBfp/m4EAhWJnUNSSw0ixs7/kXbd6Pg64EmwJkNdFhB8aWt1sH2CTXrLxo/iAGV3oPQ==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.6"
          }
        },
        "node_modules/mime-types": {
          "version": "3.0.2",
          "resolved": "https://registry.npmjs.org/mime-types/-/mime-types-3.0.2.tgz",
          "integrity": "sha512-Lbgzdk0h4juoQ9fCKXW4by0UJqj+nOOrI9MJ1sSj4nI8aI2eo1qmvQEie4VD1glsS250n15LsWsYtCugiStS5A==",
          "license": "MIT",
          "dependencies": {
            "mime-db": "^1.54.0"
          },
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/minimatch": {
          "version": "3.1.5",
          "resolved": "https://registry.npmjs.org/minimatch/-/minimatch-3.1.5.tgz",
          "integrity": "sha512-VgjWUsnnT6n+NUk6eZq77zeFdpW2LWDzP6zFGrCbHXiYNul5Dzqk2HHQ5uFH2DNW5Xbp8+jVzaeNt94ssEEl4w==",
          "license": "ISC",
          "dependencies": {
            "brace-expansion": "^1.1.7"
          },
          "engines": {
            "node": "*"
          }
        },
        "node_modules/minipass": {
          "version": "7.1.3",
          "resolved": "https://registry.npmjs.org/minipass/-/minipass-7.1.3.tgz",
          "integrity": "sha512-tEBHqDnIoM/1rXME1zgka9g6Q2lcoCkxHLuc7ODJ5BxbP5d4c2Z5cGgtXAku59200Cx7diuHTOYfSBD8n6mm8A==",
          "license": "BlueOak-1.0.0",
          "engines": {
            "node": ">=16 || 14 >=14.17"
          }
        },
        "node_modules/ms": {
          "version": "2.1.3",
          "resolved": "https://registry.npmjs.org/ms/-/ms-2.1.3.tgz",
          "integrity": "sha512-6FlzubTLZG3J2a/NVCAleEhjzq5oxgHyaCU9yYXvcLsvoVaHJq/s5xXI6/XXP6tz7R9xAOtHnSO/tXtF3WRTlA==",
          "license": "MIT"
        },
        "node_modules/nanostores": {
          "version": "1.5.2",
          "resolved": "https://registry.npmjs.org/nanostores/-/nanostores-1.5.2.tgz",
          "integrity": "sha512-B0UbxzK1s0CN8Xht6r+7iT5+xV8PTaRERR1nATeplRv1Rw5YLWfVAid0hkqY3EceqpG4RjTk8GAwIxQY39Rnwg==",
          "funding": [
            {
              "type": "github",
              "url": "https://github.com/sponsors/ai"
            }
          ],
          "license": "MIT",
          "engines": {
            "node": "^20.0.0 || >=22.0.0"
          }
        },
        "node_modules/negotiator": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/negotiator/-/negotiator-1.1.0.tgz",
          "integrity": "sha512-NMPBRMJgiQHjbd8phG3Vebdx4kZ1H121rbl5IkMqeOsahptB9BKo/d7oJ3zTXqTgagn2bWlNSXkh0QUGM31RYg==",
          "license": "MIT",
          "dependencies": {
            "content-type": "^2.1.0"
          },
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/negotiator/node_modules/content-type": {
          "version": "2.1.0",
          "resolved": "https://registry.npmjs.org/content-type/-/content-type-2.1.0.tgz",
          "integrity": "sha512-mj7UPXE0jaqaOsukNZRUEfEi2AcL7C/vwmwcHV0O97eO1E1pxBZuyjlZrx5seTaNBg1U6+o35wpa35Qfcc+7ag==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/nopt": {
          "version": "7.2.1",
          "resolved": "https://registry.npmjs.org/nopt/-/nopt-7.2.1.tgz",
          "integrity": "sha512-taM24ViiimT/XntxbPyJQzCG+p4EKOpgD3mxFwW38mGjVUrfERQOeY4EDHjdnptttfHuHQXFx+lTP08Q+mLa/w==",
          "license": "ISC",
          "dependencies": {
            "abbrev": "^2.0.0"
          },
          "bin": {
            "nopt": "bin/nopt.js"
          },
          "engines": {
            "node": "^14.17.0 || ^16.13.0 || >=18.0.0"
          }
        },
        "node_modules/object-assign": {
          "version": "4.1.1",
          "resolved": "https://registry.npmjs.org/object-assign/-/object-assign-4.1.1.tgz",
          "integrity": "sha512-rJgTQnkUnH1sFw8yT6VSU3zD3sWmu6sZhIseY8VX+GRu3P6F7Fu+JNDoXfklElbLJSnc3FUQHVe4cU5hj+BcUg==",
          "license": "MIT",
          "engines": {
            "node": ">=0.10.0"
          }
        },
        "node_modules/object-inspect": {
          "version": "1.13.4",
          "resolved": "https://registry.npmjs.org/object-inspect/-/object-inspect-1.13.4.tgz",
          "integrity": "sha512-W67iLl4J2EXEGTbfeHCffrjDfitvLANg0UlX3wFUUSTx92KXRFegMHUVgSqE+wvhAbi4WqjGg9czysTV2Epbew==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/on-finished": {
          "version": "2.4.1",
          "resolved": "https://registry.npmjs.org/on-finished/-/on-finished-2.4.1.tgz",
          "integrity": "sha512-oVlzkg3ENAhCk2zdv7IJwd/QUD4z2RxRwpkcGY8psCVcCYZNq4wYnVWALHM+brtuJjePWiYF/ClmuDr8Ch5+kg==",
          "license": "MIT",
          "dependencies": {
            "ee-first": "1.1.1"
          },
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/once": {
          "version": "1.4.0",
          "resolved": "https://registry.npmjs.org/once/-/once-1.4.0.tgz",
          "integrity": "sha512-lNaJgI+2Q5URQBkccEKHTQOPaXdUxnZZElQTZY0MFUAuaEqe1E+Nyvgdz/aIyNi6Z9MzO5dv1H8n58/GELp3+w==",
          "license": "ISC",
          "dependencies": {
            "wrappy": "1"
          }
        },
        "node_modules/open": {
          "version": "8.4.0",
          "resolved": "https://registry.npmjs.org/open/-/open-8.4.0.tgz",
          "integrity": "sha512-XgFPPM+B28FtCCgSb9I+s9szOC1vZRSwgWsRUA5ylIxRTgKozqjOCrVOqGsYABPYK5qnfqClxZTFBa8PKt2v6Q==",
          "license": "MIT",
          "dependencies": {
            "define-lazy-prop": "^2.0.0",
            "is-docker": "^2.1.1",
            "is-wsl": "^2.2.0"
          },
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://github.com/sponsors/sindresorhus"
          }
        },
        "node_modules/package-json-from-dist": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/package-json-from-dist/-/package-json-from-dist-1.0.1.tgz",
          "integrity": "sha512-UEZIS3/by4OC8vL3P2dTXRETpebLI2NiI5vIrjaD/5UtrkFX/tNbwjTSRAGC/+7CAo2pIcBaRgWmcBBHcsaCIw==",
          "license": "BlueOak-1.0.0"
        },
        "node_modules/parseurl": {
          "version": "1.3.3",
          "resolved": "https://registry.npmjs.org/parseurl/-/parseurl-1.3.3.tgz",
          "integrity": "sha512-CiyeOxFT/JZyN5m0z9PfXw4SCBJ6Sygz1Dpl0wqjlhDEGGBP1GnsUVEL0p63hoG1fcj3fHynXi9NYO4nWOL+qQ==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/path-key": {
          "version": "3.1.1",
          "resolved": "https://registry.npmjs.org/path-key/-/path-key-3.1.1.tgz",
          "integrity": "sha512-ojmeN0qd+y0jszEtoY48r0Peq5dwMEkIlCOu6Q5f41lfkswXuKtYrhgoTpLnyIcHm24Uhqx+5Tqm2InSwLhE6Q==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/path-scurry": {
          "version": "1.11.1",
          "resolved": "https://registry.npmjs.org/path-scurry/-/path-scurry-1.11.1.tgz",
          "integrity": "sha512-Xa4Nw17FS9ApQFJ9umLiJS4orGjm7ZzwUrwamcGQuHSzDyth9boKDaycYdDcZDuqYATXw4HFXgaqWTctW/v1HA==",
          "license": "BlueOak-1.0.0",
          "dependencies": {
            "lru-cache": "^10.2.0",
            "minipass": "^5.0.0 || ^6.0.2 || ^7.0.0"
          },
          "engines": {
            "node": ">=16 || 14 >=14.18"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          }
        },
        "node_modules/path-to-regexp": {
          "version": "8.4.2",
          "resolved": "https://registry.npmjs.org/path-to-regexp/-/path-to-regexp-8.4.2.tgz",
          "integrity": "sha512-qRcuIdP69NPm4qbACK+aDogI5CBDMi1jKe0ry5rSQJz8JVLsC7jV8XpiJjGRLLol3N+R5ihGYcrPLTno6pAdBA==",
          "license": "MIT",
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/pend": {
          "version": "1.2.0",
          "resolved": "https://registry.npmjs.org/pend/-/pend-1.2.0.tgz",
          "integrity": "sha512-F3asv42UuXchdzt+xXqfW1OGlVBe+mxa2mqI0pg5yAHZPvFmY3Y6drSf/GQ1A86WgWEN9Kzh/WrgKa6iGcHXLg==",
          "license": "MIT"
        },
        "node_modules/picocolors": {
          "version": "1.1.1",
          "resolved": "https://registry.npmjs.org/picocolors/-/picocolors-1.1.1.tgz",
          "integrity": "sha512-xceH2snhtb5M9liqDsmEw56le376mTZkEX/jEb/RxNFyegNul7eNslCXP9FDj/Lcu0X8KEyMceP2ntpaHrDEVA==",
          "license": "ISC"
        },
        "node_modules/pkce-challenge": {
          "version": "5.0.1",
          "resolved": "https://registry.npmjs.org/pkce-challenge/-/pkce-challenge-5.0.1.tgz",
          "integrity": "sha512-wQ0b/W4Fr01qtpHlqSqspcj3EhBvimsdh0KlHhH8HRZnMsEa0ea2fTULOXOS9ccQr3om+GcGRk4e+isrZWV8qQ==",
          "license": "MIT",
          "engines": {
            "node": ">=16.20.0"
          }
        },
        "node_modules/playwriter": {
          "version": "0.4.0",
          "resolved": "https://registry.npmjs.org/playwriter/-/playwriter-0.4.0.tgz",
          "integrity": "sha512-Pn0sxzfrX5Ln0Fa7cXhUnMO6biLRbOQ4HiviXWKAgLjIpNBa3XZuge3c+mHAOi/WK+3AAhECpPAYrlFkgfJLqw==",
          "dependencies": {
            "@hono/node-server": "^1.19.6",
            "@hono/node-ws": "^1.2.0",
            "@modelcontextprotocol/sdk": "^1.29.0",
            "@xmorse/playwright-core": "^1.59.10",
            "acorn": "^8.15.0",
            "async-sema": "^3.1.1",
            "better-auth": "^1.6.20",
            "diff": "^8.0.2",
            "dom-accessibility-api": "^0.7.1",
            "goke": "^6.12.1",
            "hono": "^4.12.12",
            "picocolors": "^1.1.1",
            "posthtml": "^0.16.7",
            "posthtml-beautify": "^0.7.0",
            "string-dedent": "^3.0.2",
            "strip-ansi": "^7.1.2",
            "ws": "^8.18.3",
            "zod": "^4.3.5",
            "zustand": "^5.0.8"
          },
          "bin": {
            "playwriter": "bin.js"
          },
          "optionalDependencies": {
            "@playwriter/patchright-core": "^1.61.0-playwriter.1",
            "sharp": "^0.34.5"
          }
        },
        "node_modules/pngjs": {
          "version": "6.0.0",
          "resolved": "https://registry.npmjs.org/pngjs/-/pngjs-6.0.0.tgz",
          "integrity": "sha512-TRzzuFRRmEoSW/p1KVAmiOgPco2Irlah+bGFCeNfJXxxYGwSw7YwAOAcd7X28K/m5bjBWKsC29KyoMfHbypayg==",
          "license": "MIT",
          "engines": {
            "node": ">=12.13.0"
          }
        },
        "node_modules/posthtml": {
          "version": "0.16.7",
          "resolved": "https://registry.npmjs.org/posthtml/-/posthtml-0.16.7.tgz",
          "integrity": "sha512-7Hc+IvlQ7hlaIfQFZnxlRl0jnpWq2qwibORBhQYIb0QbNtuicc5ZxvKkVT71HJ4Py1wSZ/3VR1r8LfkCtoCzhw==",
          "license": "MIT",
          "dependencies": {
            "posthtml-parser": "^0.11.0",
            "posthtml-render": "^3.0.0"
          },
          "engines": {
            "node": ">=12.0.0"
          }
        },
        "node_modules/posthtml-beautify": {
          "version": "0.7.0",
          "resolved": "https://registry.npmjs.org/posthtml-beautify/-/posthtml-beautify-0.7.0.tgz",
          "integrity": "sha512-g9+tYK5Z1WiYHgEOXt3jmVd6ioG5Hk6wVIw8rYVMqzFBeJzELHcxUk0bxTfYYP715Qrrh/xkwHyXrDL+ETKUgQ==",
          "license": "MIT",
          "dependencies": {
            "@babel/runtime": "^7.10.2",
            "deepmerge": "^4.2.2",
            "js-beautify": "^1.11.0",
            "posthtml-parser": "^0.4.2",
            "posthtml-render": "^1.2.2"
          },
          "engines": {
            "node": ">=10"
          }
        },
        "node_modules/posthtml-beautify/node_modules/dom-serializer": {
          "version": "0.2.2",
          "resolved": "https://registry.npmjs.org/dom-serializer/-/dom-serializer-0.2.2.tgz",
          "integrity": "sha512-2/xPb3ORsQ42nHYiSunXkDjPLBaEj/xTwUO4B7XCZQTRk7EBtTOPaygh10YAAh2OI1Qrp6NWfpAhzswj0ydt9g==",
          "license": "MIT",
          "dependencies": {
            "domelementtype": "^2.0.1",
            "entities": "^2.0.0"
          }
        },
        "node_modules/posthtml-beautify/node_modules/dom-serializer/node_modules/domelementtype": {
          "version": "2.3.0",
          "resolved": "https://registry.npmjs.org/domelementtype/-/domelementtype-2.3.0.tgz",
          "integrity": "sha512-OLETBj6w0OsagBwdXnPdN0cnMfF9opN69co+7ZrbfPGrdpPVNBUj02spi6B1N7wChLQiPn4CSH/zJvXw56gmHw==",
          "funding": [
            {
              "type": "github",
              "url": "https://github.com/sponsors/fb55"
            }
          ],
          "license": "BSD-2-Clause"
        },
        "node_modules/posthtml-beautify/node_modules/dom-serializer/node_modules/entities": {
          "version": "2.2.0",
          "resolved": "https://registry.npmjs.org/entities/-/entities-2.2.0.tgz",
          "integrity": "sha512-p92if5Nz619I0w+akJrLZH0MX0Pb5DX39XOwQTtXSdQQOaYH03S1uIQp4mhOZtAXrxq4ViO67YTiLBo2638o9A==",
          "license": "BSD-2-Clause",
          "funding": {
            "url": "https://github.com/fb55/entities?sponsor=1"
          }
        },
        "node_modules/posthtml-beautify/node_modules/domelementtype": {
          "version": "1.3.1",
          "resolved": "https://registry.npmjs.org/domelementtype/-/domelementtype-1.3.1.tgz",
          "integrity": "sha512-BSKB+TSpMpFI/HOxCNr1O8aMOTZ8hT3pM3GQ0w/mWRmkhEDSFJkkyzz4XQsBV44BChwGkrDfMyjVD0eA2aFV3w==",
          "license": "BSD-2-Clause"
        },
        "node_modules/posthtml-beautify/node_modules/domhandler": {
          "version": "2.4.2",
          "resolved": "https://registry.npmjs.org/domhandler/-/domhandler-2.4.2.tgz",
          "integrity": "sha512-JiK04h0Ht5u/80fdLMCEmV4zkNh2BcoMFBmZ/91WtYZ8qVXSKjiw7fXMgFPnHcSZgOo3XdinHvmnDUeMf5R4wA==",
          "license": "BSD-2-Clause",
          "dependencies": {
            "domelementtype": "1"
          }
        },
        "node_modules/posthtml-beautify/node_modules/domutils": {
          "version": "1.7.0",
          "resolved": "https://registry.npmjs.org/domutils/-/domutils-1.7.0.tgz",
          "integrity": "sha512-Lgd2XcJ/NjEw+7tFvfKxOzCYKZsdct5lczQ2ZaQY8Djz7pfAD3Gbp8ySJWtreII/vDlMVmxwa6pHmdxIYgttDg==",
          "license": "BSD-2-Clause",
          "dependencies": {
            "dom-serializer": "0",
            "domelementtype": "1"
          }
        },
        "node_modules/posthtml-beautify/node_modules/entities": {
          "version": "1.1.2",
          "resolved": "https://registry.npmjs.org/entities/-/entities-1.1.2.tgz",
          "integrity": "sha512-f2LZMYl1Fzu7YSBKg+RoROelpOaNrcGmE9AZubeDfrCEia483oW4MI4VyFd5VNHIgQ/7qm1I0wUHK1eJnn2y2w==",
          "license": "BSD-2-Clause"
        },
        "node_modules/posthtml-beautify/node_modules/htmlparser2": {
          "version": "3.10.1",
          "resolved": "https://registry.npmjs.org/htmlparser2/-/htmlparser2-3.10.1.tgz",
          "integrity": "sha512-IgieNijUMbkDovyoKObU1DUhm1iwNYE/fuifEoEHfd1oZKZDaONBSkal7Y01shxsM49R4XaMdGez3WnF9UfiCQ==",
          "license": "MIT",
          "dependencies": {
            "domelementtype": "^1.3.1",
            "domhandler": "^2.3.0",
            "domutils": "^1.5.1",
            "entities": "^1.1.1",
            "inherits": "^2.0.1",
            "readable-stream": "^3.1.1"
          }
        },
        "node_modules/posthtml-beautify/node_modules/posthtml-parser": {
          "version": "0.4.2",
          "resolved": "https://registry.npmjs.org/posthtml-parser/-/posthtml-parser-0.4.2.tgz",
          "integrity": "sha512-BUIorsYJTvS9UhXxPTzupIztOMVNPa/HtAm9KHni9z6qEfiJ1bpOBL5DfUOL9XAc3XkLIEzBzpph+Zbm4AdRAg==",
          "license": "MIT",
          "dependencies": {
            "htmlparser2": "^3.9.2"
          }
        },
        "node_modules/posthtml-beautify/node_modules/posthtml-render": {
          "version": "1.4.0",
          "resolved": "https://registry.npmjs.org/posthtml-render/-/posthtml-render-1.4.0.tgz",
          "integrity": "sha512-W1779iVHGfq0Fvh2PROhCe2QhB8mEErgqzo1wpIt36tCgChafP+hbXIhLDOM8ePJrZcFs0vkNEtdibEWVqChqw==",
          "license": "MIT",
          "engines": {
            "node": ">=10"
          }
        },
        "node_modules/posthtml-parser": {
          "version": "0.11.0",
          "resolved": "https://registry.npmjs.org/posthtml-parser/-/posthtml-parser-0.11.0.tgz",
          "integrity": "sha512-QecJtfLekJbWVo/dMAA+OSwY79wpRmbqS5TeXvXSX+f0c6pW4/SE6inzZ2qkU7oAMCPqIDkZDvd/bQsSFUnKyw==",
          "license": "MIT",
          "dependencies": {
            "htmlparser2": "^7.1.1"
          },
          "engines": {
            "node": ">=12"
          }
        },
        "node_modules/posthtml-render": {
          "version": "3.0.0",
          "resolved": "https://registry.npmjs.org/posthtml-render/-/posthtml-render-3.0.0.tgz",
          "integrity": "sha512-z+16RoxK3fUPgwaIgH9NGnK1HKY9XIDpydky5eQGgAFVXTCSezalv9U2jQuNV+Z9qV1fDWNzldcw4eK0SSbqKA==",
          "license": "MIT",
          "dependencies": {
            "is-json": "^2.0.1"
          },
          "engines": {
            "node": ">=12"
          }
        },
        "node_modules/progress": {
          "version": "2.0.3",
          "resolved": "https://registry.npmjs.org/progress/-/progress-2.0.3.tgz",
          "integrity": "sha512-7PiHtLll5LdnKIMw100I+8xJXR5gW2QwWYkT6iJva0bXitZKa/XMrSbdmg3r2Xnaidz9Qumd0VPaMrZlF9V9sA==",
          "license": "MIT",
          "engines": {
            "node": ">=0.4.0"
          }
        },
        "node_modules/proto-list": {
          "version": "1.2.4",
          "resolved": "https://registry.npmjs.org/proto-list/-/proto-list-1.2.4.tgz",
          "integrity": "sha512-vtK/94akxsTMhe0/cbfpR+syPuszcuwhqVjJq26CuNDgFGj682oRBXOP5MJpv2r7JtE8MsiepGIqvvOTBwn2vA==",
          "license": "ISC"
        },
        "node_modules/proxy-addr": {
          "version": "2.0.7",
          "resolved": "https://registry.npmjs.org/proxy-addr/-/proxy-addr-2.0.7.tgz",
          "integrity": "sha512-llQsMLSUDUPT44jdrU/O37qlnifitDP+ZwrmmZcoSKyLKvtZxpyV0n2/bD/N4tBAAZ/gJEdZU7KMraoK1+XYAg==",
          "license": "MIT",
          "dependencies": {
            "forwarded": "0.2.0",
            "ipaddr.js": "1.9.1"
          },
          "engines": {
            "node": ">= 0.10"
          }
        },
        "node_modules/proxy-from-env": {
          "version": "1.1.0",
          "resolved": "https://registry.npmjs.org/proxy-from-env/-/proxy-from-env-1.1.0.tgz",
          "integrity": "sha512-D+zkORCbA9f1tdWRK0RaCR3GPv50cMxcrz4X8k5LTSUD1Dkw47mKJEZQNunItRTkWwgtaUSo1RVFRIG9ZXiFYg==",
          "license": "MIT"
        },
        "node_modules/pump": {
          "version": "3.0.4",
          "resolved": "https://registry.npmjs.org/pump/-/pump-3.0.4.tgz",
          "integrity": "sha512-VS7sjc6KR7e1ukRFhQSY5LM2uBWAUPiOPa/A3mkKmiMwSmRFUITt0xuj+/lesgnCv+dPIEYlkzrcyXgquIHMcA==",
          "license": "MIT",
          "dependencies": {
            "end-of-stream": "^1.1.0",
            "once": "^1.3.1"
          }
        },
        "node_modules/qs": {
          "version": "6.15.3",
          "resolved": "https://registry.npmjs.org/qs/-/qs-6.15.3.tgz",
          "integrity": "sha512-O9gl3zCl5h5blw1KGUzQKhA5oUXSl8rwUIM5o0S3nCXMliSvy5Dzx7/DJcI+SwgICv+IneSZwhBh1oSyEHA71A==",
          "license": "BSD-3-Clause",
          "dependencies": {
            "es-define-property": "^1.0.1",
            "side-channel": "^1.1.1"
          },
          "engines": {
            "node": ">=0.6"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/range-parser": {
          "version": "1.3.0",
          "resolved": "https://registry.npmjs.org/range-parser/-/range-parser-1.3.0.tgz",
          "integrity": "sha512-hek2mFQpPuI4E1BBKrSto+BU3e3x4xuarsbiwr3+lf7p44juvFMV0XFWQAP3xUyqXA4RrXLIoaSUGbSt056ZMw==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.6"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/raw-body": {
          "version": "3.0.2",
          "resolved": "https://registry.npmjs.org/raw-body/-/raw-body-3.0.2.tgz",
          "integrity": "sha512-K5zQjDllxWkf7Z5xJdV0/B0WTNqx6vxG70zJE4N0kBs4LovmEYWJzQGxC9bS9RAKu3bgM40lrd5zoLJ12MQ5BA==",
          "license": "MIT",
          "dependencies": {
            "bytes": "~3.1.2",
            "http-errors": "~2.0.1",
            "iconv-lite": "~0.7.0",
            "unpipe": "~1.0.0"
          },
          "engines": {
            "node": ">= 0.10"
          }
        },
        "node_modules/readable-stream": {
          "version": "3.6.2",
          "resolved": "https://registry.npmjs.org/readable-stream/-/readable-stream-3.6.2.tgz",
          "integrity": "sha512-9u/sniCrY3D5WdsERHzHE4G2YCXqoG5FTHUiCC4SIbr6XcLZBY05ya9EKjYek9O5xOAwjGq+1JdGBAS7Q9ScoA==",
          "license": "MIT",
          "dependencies": {
            "inherits": "^2.0.3",
            "string_decoder": "^1.1.1",
            "util-deprecate": "^1.0.1"
          },
          "engines": {
            "node": ">= 6"
          }
        },
        "node_modules/require-from-string": {
          "version": "2.0.2",
          "resolved": "https://registry.npmjs.org/require-from-string/-/require-from-string-2.0.2.tgz",
          "integrity": "sha512-Xf0nWe6RseziFMu+Ap9biiUbmplq6S9/p+7w7YXP/JBHhrUDDUhwa+vANyubuqfZWTveU//DYVGsDG7RKL/vEw==",
          "license": "MIT",
          "engines": {
            "node": ">=0.10.0"
          }
        },
        "node_modules/retry": {
          "version": "0.13.1",
          "resolved": "https://registry.npmjs.org/retry/-/retry-0.13.1.tgz",
          "integrity": "sha512-XQBQ3I8W1Cge0Seh+6gjj03LbmRFWuoszgK9ooCpwYIrhhoO80pfq4cUkU5DkknwfOfFteRwlZ56PYOGYyFWdg==",
          "license": "MIT",
          "engines": {
            "node": ">= 4"
          }
        },
        "node_modules/rou3": {
          "version": "0.9.2",
          "resolved": "https://registry.npmjs.org/rou3/-/rou3-0.9.2.tgz",
          "integrity": "sha512-3SOzvaAg8rkHrXtRjpCvCvbyO5to9oOO27Z/XqHEYXfMRVSw/qMIVdmaOk9W2lcRLtR6dlqTjo9hDeJk70QBYQ==",
          "license": "MIT"
        },
        "node_modules/router": {
          "version": "2.2.0",
          "resolved": "https://registry.npmjs.org/router/-/router-2.2.0.tgz",
          "integrity": "sha512-nLTrUKm2UyiL7rlhapu/Zl45FwNgkZGaCpZbIHajDYgwlJCOzLSk+cIPAnsEqV955GjILJnKbdQC1nVPz+gAYQ==",
          "license": "MIT",
          "dependencies": {
            "debug": "^4.4.0",
            "depd": "^2.0.0",
            "is-promise": "^4.0.0",
            "parseurl": "^1.3.3",
            "path-to-regexp": "^8.0.0"
          },
          "engines": {
            "node": ">= 18"
          }
        },
        "node_modules/safe-buffer": {
          "version": "5.2.1",
          "resolved": "https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.2.1.tgz",
          "integrity": "sha512-rp3So07KcdmmKbGvgaNxQSJr7bGVSVk5S9Eq1F+ppbRo70+YeaDxkw5Dd8NPN+GD6bjnYm2VuPuCXmpuYvmCXQ==",
          "funding": [
            {
              "type": "github",
              "url": "https://github.com/sponsors/feross"
            },
            {
              "type": "patreon",
              "url": "https://www.patreon.com/feross"
            },
            {
              "type": "consulting",
              "url": "https://feross.org/support"
            }
          ],
          "license": "MIT"
        },
        "node_modules/safer-buffer": {
          "version": "2.1.2",
          "resolved": "https://registry.npmjs.org/safer-buffer/-/safer-buffer-2.1.2.tgz",
          "integrity": "sha512-YZo3K82SD7Riyi0E1EQPojLz7kpepnSQI9IyPbHHg1XXXevb5dJI7tpyN2ADxGcQbHG7vcyRHk0cbwqcQriUtg==",
          "license": "MIT"
        },
        "node_modules/semver": {
          "version": "7.8.5",
          "resolved": "https://registry.npmjs.org/semver/-/semver-7.8.5.tgz",
          "integrity": "sha512-Y7/KDsb8LjooZpwaqGyulO6DQlksgCncchHGk+sZIY4SBvUocMBEFH5Ur1fI4dV+Jvl0w6cjvucaIi40puRioA==",
          "license": "ISC",
          "bin": {
            "semver": "bin/semver.js"
          },
          "engines": {
            "node": ">=10"
          }
        },
        "node_modules/send": {
          "version": "1.2.1",
          "resolved": "https://registry.npmjs.org/send/-/send-1.2.1.tgz",
          "integrity": "sha512-1gnZf7DFcoIcajTjTwjwuDjzuz4PPcY2StKPlsGAQ1+YH20IRVrBaXSWmdjowTJ6u8Rc01PoYOGHXfP1mYcZNQ==",
          "license": "MIT",
          "dependencies": {
            "debug": "^4.4.3",
            "encodeurl": "^2.0.0",
            "escape-html": "^1.0.3",
            "etag": "^1.8.1",
            "fresh": "^2.0.0",
            "http-errors": "^2.0.1",
            "mime-types": "^3.0.2",
            "ms": "^2.1.3",
            "on-finished": "^2.4.1",
            "range-parser": "^1.2.1",
            "statuses": "^2.0.2"
          },
          "engines": {
            "node": ">= 18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/serve-static": {
          "version": "2.2.1",
          "resolved": "https://registry.npmjs.org/serve-static/-/serve-static-2.2.1.tgz",
          "integrity": "sha512-xRXBn0pPqQTVQiC8wyQrKs2MOlX24zQ0POGaj0kultvoOCstBQM5yvOhAVSUwOMjQtTvsPWoNCHfPGwaaQJhTw==",
          "license": "MIT",
          "dependencies": {
            "encodeurl": "^2.0.0",
            "escape-html": "^1.0.3",
            "parseurl": "^1.3.3",
            "send": "^1.2.0"
          },
          "engines": {
            "node": ">= 18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/set-cookie-parser": {
          "version": "3.1.2",
          "resolved": "https://registry.npmjs.org/set-cookie-parser/-/set-cookie-parser-3.1.2.tgz",
          "integrity": "sha512-5/r/lTwbJ3zQ+qwdUFZYeRNqda7P5HD8zQKqlSjdGt1/S0cjLAphHusj4Y58ahDtWn/g32xrIS58/ikOvwl0Lw==",
          "license": "MIT"
        },
        "node_modules/setprototypeof": {
          "version": "1.2.0",
          "resolved": "https://registry.npmjs.org/setprototypeof/-/setprototypeof-1.2.0.tgz",
          "integrity": "sha512-E5LDX7Wrp85Kil5bhZv46j8jOeboKq5JMmYM3gVGdGH8xFpPWXUMsNrlODCrkoxMEeNi/XZIwuRvY4XNwYMJpw==",
          "license": "ISC"
        },
        "node_modules/sharp": {
          "version": "0.34.5",
          "resolved": "https://registry.npmjs.org/sharp/-/sharp-0.34.5.tgz",
          "integrity": "sha512-Ou9I5Ft9WNcCbXrU9cMgPBcCK8LiwLqcbywW3t4oDV37n1pzpuNLsYiAV8eODnjbtQlSDwZ2cUEeQz4E54Hltg==",
          "hasInstallScript": true,
          "license": "Apache-2.0",
          "optional": true,
          "dependencies": {
            "@img/colour": "^1.0.0",
            "detect-libc": "^2.1.2",
            "semver": "^7.7.3"
          },
          "engines": {
            "node": "^18.17.0 || ^20.3.0 || >=21.0.0"
          },
          "funding": {
            "url": "https://opencollective.com/libvips"
          },
          "optionalDependencies": {
            "@img/sharp-darwin-arm64": "0.34.5",
            "@img/sharp-darwin-x64": "0.34.5",
            "@img/sharp-libvips-darwin-arm64": "1.2.4",
            "@img/sharp-libvips-darwin-x64": "1.2.4",
            "@img/sharp-libvips-linux-arm": "1.2.4",
            "@img/sharp-libvips-linux-arm64": "1.2.4",
            "@img/sharp-libvips-linux-ppc64": "1.2.4",
            "@img/sharp-libvips-linux-riscv64": "1.2.4",
            "@img/sharp-libvips-linux-s390x": "1.2.4",
            "@img/sharp-libvips-linux-x64": "1.2.4",
            "@img/sharp-libvips-linuxmusl-arm64": "1.2.4",
            "@img/sharp-libvips-linuxmusl-x64": "1.2.4",
            "@img/sharp-linux-arm": "0.34.5",
            "@img/sharp-linux-arm64": "0.34.5",
            "@img/sharp-linux-ppc64": "0.34.5",
            "@img/sharp-linux-riscv64": "0.34.5",
            "@img/sharp-linux-s390x": "0.34.5",
            "@img/sharp-linux-x64": "0.34.5",
            "@img/sharp-linuxmusl-arm64": "0.34.5",
            "@img/sharp-linuxmusl-x64": "0.34.5",
            "@img/sharp-wasm32": "0.34.5",
            "@img/sharp-win32-arm64": "0.34.5",
            "@img/sharp-win32-ia32": "0.34.5",
            "@img/sharp-win32-x64": "0.34.5"
          }
        },
        "node_modules/shebang-command": {
          "version": "2.0.0",
          "resolved": "https://registry.npmjs.org/shebang-command/-/shebang-command-2.0.0.tgz",
          "integrity": "sha512-kHxr2zZpYtdmrN1qDjrrX/Z1rR1kG8Dx+gkpK1G4eXmvXswmcE1hTWBWYUzlraYw1/yZp6YuDY77YtvbN0dmDA==",
          "license": "MIT",
          "dependencies": {
            "shebang-regex": "^3.0.0"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/shebang-regex": {
          "version": "3.0.0",
          "resolved": "https://registry.npmjs.org/shebang-regex/-/shebang-regex-3.0.0.tgz",
          "integrity": "sha512-7++dFhtcx3353uBaq8DDR4NuxBetBzC7ZQOhmTQInHEd6bSrXdiEyzCvG07Z44UYdLShWUyXt5M/yhz8ekcb1A==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/side-channel": {
          "version": "1.1.1",
          "resolved": "https://registry.npmjs.org/side-channel/-/side-channel-1.1.1.tgz",
          "integrity": "sha512-6x6dK6zJdpTzF4sQeNYxwtvBzf6Eg4GtlesS94HOvTudUeyK2WXAaIfmDgsyslYrRBeFIlsi54AYsFGUuhmvrQ==",
          "license": "MIT",
          "dependencies": {
            "es-errors": "^1.3.0",
            "object-inspect": "^1.13.4",
            "side-channel-list": "^1.0.1",
            "side-channel-map": "^1.0.1",
            "side-channel-weakmap": "^1.0.2"
          },
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/side-channel-list": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/side-channel-list/-/side-channel-list-1.0.1.tgz",
          "integrity": "sha512-mjn/0bi/oUURjc5Xl7IaWi/OJJJumuoJFQJfDDyO46+hBWsfaVM65TBHq2eoZBhzl9EchxOijpkbRC8SVBQU0w==",
          "license": "MIT",
          "dependencies": {
            "es-errors": "^1.3.0",
            "object-inspect": "^1.13.4"
          },
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/side-channel-map": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/side-channel-map/-/side-channel-map-1.0.1.tgz",
          "integrity": "sha512-VCjCNfgMsby3tTdo02nbjtM/ewra6jPHmpThenkTYh8pG9ucZ/1P8So4u4FGBek/BjpOVsDCMoLA/iuBKIFXRA==",
          "license": "MIT",
          "dependencies": {
            "call-bound": "^1.0.2",
            "es-errors": "^1.3.0",
            "get-intrinsic": "^1.2.5",
            "object-inspect": "^1.13.3"
          },
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/side-channel-weakmap": {
          "version": "1.0.2",
          "resolved": "https://registry.npmjs.org/side-channel-weakmap/-/side-channel-weakmap-1.0.2.tgz",
          "integrity": "sha512-WPS/HvHQTYnHisLo9McqBHOJk2FkHO/tlpvldyrnem4aeQp4hai3gythswg6p01oSoTl58rcpiFAjF2br2Ak2A==",
          "license": "MIT",
          "dependencies": {
            "call-bound": "^1.0.2",
            "es-errors": "^1.3.0",
            "get-intrinsic": "^1.2.5",
            "object-inspect": "^1.13.3",
            "side-channel-map": "^1.0.1"
          },
          "engines": {
            "node": ">= 0.4"
          },
          "funding": {
            "url": "https://github.com/sponsors/ljharb"
          }
        },
        "node_modules/signal-exit": {
          "version": "4.1.0",
          "resolved": "https://registry.npmjs.org/signal-exit/-/signal-exit-4.1.0.tgz",
          "integrity": "sha512-bzyZ1e88w9O1iNJbKnOlvYTrWPDl46O1bG0D3XInv+9tkPrxrN8jUUTiFlDkkmKWgn1M6CfIA13SuGqOa9Korw==",
          "license": "ISC",
          "engines": {
            "node": ">=14"
          },
          "funding": {
            "url": "https://github.com/sponsors/isaacs"
          }
        },
        "node_modules/smart-buffer": {
          "version": "4.2.0",
          "resolved": "https://registry.npmjs.org/smart-buffer/-/smart-buffer-4.2.0.tgz",
          "integrity": "sha512-94hK0Hh8rPqQl2xXc3HsaBoOXKV20MToPkcXvwbISWLEs+64sBq5kFgn2kJDHb1Pry9yrP0dxrCI9RRci7RXKg==",
          "license": "MIT",
          "engines": {
            "node": ">= 6.0.0",
            "npm": ">= 3.0.0"
          }
        },
        "node_modules/socks": {
          "version": "2.8.9",
          "resolved": "https://registry.npmjs.org/socks/-/socks-2.8.9.tgz",
          "integrity": "sha512-LJhUYUvItdQ0LkJTmPeaEObWXAqFyfmP85x0tch/ez9cahmhlBBLbIqDFnvBnUJGagb0JbIQrkBs1wJ+yRYpEw==",
          "license": "MIT",
          "dependencies": {
            "ip-address": "^10.1.1",
            "smart-buffer": "^4.2.0"
          },
          "engines": {
            "node": ">= 10.0.0",
            "npm": ">= 3.0.0"
          }
        },
        "node_modules/socks-proxy-agent": {
          "version": "8.0.5",
          "resolved": "https://registry.npmjs.org/socks-proxy-agent/-/socks-proxy-agent-8.0.5.tgz",
          "integrity": "sha512-HehCEsotFqbPW9sJ8WVYB6UbmIMv7kUUORIF2Nncq4VQvBfNBLibW9YZR5dlYCSUhwcD628pRllm7n+E+YTzJw==",
          "license": "MIT",
          "dependencies": {
            "agent-base": "^7.1.2",
            "debug": "^4.3.4",
            "socks": "^2.8.3"
          },
          "engines": {
            "node": ">= 14"
          }
        },
        "node_modules/statuses": {
          "version": "2.0.2",
          "resolved": "https://registry.npmjs.org/statuses/-/statuses-2.0.2.tgz",
          "integrity": "sha512-DvEy55V3DB7uknRo+4iOGT5fP1slR8wQohVdknigZPMpMstaKJQWhwiYBACJE3Ul2pTnATihhBYnRhZQHGBiRw==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/string_decoder": {
          "version": "1.3.0",
          "resolved": "https://registry.npmjs.org/string_decoder/-/string_decoder-1.3.0.tgz",
          "integrity": "sha512-hkRX8U1WjJFd8LsDJ2yQ/wWWxaopEsABU1XfkM8A+j0+85JAGppt16cr1Whg6KIbb4okU6Mql6BOj+uup/wKeA==",
          "license": "MIT",
          "dependencies": {
            "safe-buffer": "~5.2.0"
          }
        },
        "node_modules/string-dedent": {
          "version": "3.0.2",
          "resolved": "https://registry.npmjs.org/string-dedent/-/string-dedent-3.0.2.tgz",
          "integrity": "sha512-M4q+HpHCtGXlbyzYDOcOo7V185dlq6YXvGUPcWZqL4vttCX9gFYoWIOxcPd7v5CAYcTJsGLs3ZJCAH2TXONF/g==",
          "license": "MIT",
          "engines": {
            "node": ">=0.12.0"
          }
        },
        "node_modules/string-width": {
          "version": "5.1.2",
          "resolved": "https://registry.npmjs.org/string-width/-/string-width-5.1.2.tgz",
          "integrity": "sha512-HnLOCR3vjcY8beoNLtcjZ5/nxn2afmME6lhrDrebokqMap+XbeW8n9TXpPDOqdGK5qcI3oT0GKTW6wC7EMiVqA==",
          "license": "MIT",
          "dependencies": {
            "eastasianwidth": "^0.2.0",
            "emoji-regex": "^9.2.2",
            "strip-ansi": "^7.0.1"
          },
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://github.com/sponsors/sindresorhus"
          }
        },
        "node_modules/string-width-cjs": {
          "name": "string-width",
          "version": "4.2.3",
          "resolved": "https://registry.npmjs.org/string-width/-/string-width-4.2.3.tgz",
          "integrity": "sha512-wKyQRQpjJ0sIp62ErSZdGsjMJWsap5oRNihHhu6G7JVO/9jIB6UyevL+tXuOqrng8j/cxKTWyWUwvSTriiZz/g==",
          "license": "MIT",
          "dependencies": {
            "emoji-regex": "^8.0.0",
            "is-fullwidth-code-point": "^3.0.0",
            "strip-ansi": "^6.0.1"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/string-width-cjs/node_modules/ansi-regex": {
          "version": "5.0.1",
          "resolved": "https://registry.npmjs.org/ansi-regex/-/ansi-regex-5.0.1.tgz",
          "integrity": "sha512-quJQXlTSUGL2LH9SUXo8VwsY4soanhgo6LNSm84E1LBcE8s3O0wpdiRzyR9z/ZZJMlMWv37qOOb9pdJlMUEKFQ==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/string-width-cjs/node_modules/emoji-regex": {
          "version": "8.0.0",
          "resolved": "https://registry.npmjs.org/emoji-regex/-/emoji-regex-8.0.0.tgz",
          "integrity": "sha512-MSjYzcWNOA0ewAHpz0MxpYFvwg6yjy1NG3xteoqz644VCo/RPgnr1/GGt+ic3iJTzQ8Eu3TdM14SawnVUmGE6A==",
          "license": "MIT"
        },
        "node_modules/string-width-cjs/node_modules/strip-ansi": {
          "version": "6.0.1",
          "resolved": "https://registry.npmjs.org/strip-ansi/-/strip-ansi-6.0.1.tgz",
          "integrity": "sha512-Y38VPSHcqkFrCpFnQ9vuSXmquuv5oXOKpGeT6aGrr3o3Gc9AlVa6JBfUSOCnbxGGZF+/0ooI7KrPuUSztUdU5A==",
          "license": "MIT",
          "dependencies": {
            "ansi-regex": "^5.0.1"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/strip-ansi": {
          "version": "7.2.0",
          "resolved": "https://registry.npmjs.org/strip-ansi/-/strip-ansi-7.2.0.tgz",
          "integrity": "sha512-yDPMNjp4WyfYBkHnjIRLfca1i6KMyGCtsVgoKe/z1+6vukgaENdgGBZt+ZmKPc4gavvEZ5OgHfHdrazhgNyG7w==",
          "license": "MIT",
          "dependencies": {
            "ansi-regex": "^6.2.2"
          },
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://github.com/chalk/strip-ansi?sponsor=1"
          }
        },
        "node_modules/strip-ansi-cjs": {
          "name": "strip-ansi",
          "version": "6.0.1",
          "resolved": "https://registry.npmjs.org/strip-ansi/-/strip-ansi-6.0.1.tgz",
          "integrity": "sha512-Y38VPSHcqkFrCpFnQ9vuSXmquuv5oXOKpGeT6aGrr3o3Gc9AlVa6JBfUSOCnbxGGZF+/0ooI7KrPuUSztUdU5A==",
          "license": "MIT",
          "dependencies": {
            "ansi-regex": "^5.0.1"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/strip-ansi-cjs/node_modules/ansi-regex": {
          "version": "5.0.1",
          "resolved": "https://registry.npmjs.org/ansi-regex/-/ansi-regex-5.0.1.tgz",
          "integrity": "sha512-quJQXlTSUGL2LH9SUXo8VwsY4soanhgo6LNSm84E1LBcE8s3O0wpdiRzyR9z/ZZJMlMWv37qOOb9pdJlMUEKFQ==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/toidentifier": {
          "version": "1.0.1",
          "resolved": "https://registry.npmjs.org/toidentifier/-/toidentifier-1.0.1.tgz",
          "integrity": "sha512-o5sSPKEkg/DIQNmH43V0/uerLrpzVedkUh8tGNvaeXpfpuwjKenlSox/2O/BTlZUtEe+JG7s5YhEz608PlAHRA==",
          "license": "MIT",
          "engines": {
            "node": ">=0.6"
          }
        },
        "node_modules/tslib": {
          "version": "2.8.1",
          "resolved": "https://registry.npmjs.org/tslib/-/tslib-2.8.1.tgz",
          "integrity": "sha512-oJFu94HQb+KVduSUQL7wnpmqnfmLsOA/nAh6b6EH0wCEoK0/mPeXU6c3wKDV83MkOuHPRHtSXKKU99IBazS/2w==",
          "license": "0BSD",
          "optional": true
        },
        "node_modules/type-is": {
          "version": "2.1.0",
          "resolved": "https://registry.npmjs.org/type-is/-/type-is-2.1.0.tgz",
          "integrity": "sha512-faYHw0anBbc/kWF3zFTEnxSFOAGUX9GFbOBthvDdLsIlEoWOFOtS0zgCiQYwIskL9iGXZL3kAXD8OoZ4GmMATA==",
          "license": "MIT",
          "dependencies": {
            "content-type": "^2.0.0",
            "media-typer": "^1.1.0",
            "mime-types": "^3.0.0"
          },
          "engines": {
            "node": ">= 18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/type-is/node_modules/content-type": {
          "version": "2.1.0",
          "resolved": "https://registry.npmjs.org/content-type/-/content-type-2.1.0.tgz",
          "integrity": "sha512-mj7UPXE0jaqaOsukNZRUEfEi2AcL7C/vwmwcHV0O97eO1E1pxBZuyjlZrx5seTaNBg1U6+o35wpa35Qfcc+7ag==",
          "license": "MIT",
          "engines": {
            "node": ">=18"
          },
          "funding": {
            "type": "opencollective",
            "url": "https://opencollective.com/express"
          }
        },
        "node_modules/unpipe": {
          "version": "1.0.0",
          "resolved": "https://registry.npmjs.org/unpipe/-/unpipe-1.0.0.tgz",
          "integrity": "sha512-pjy2bYhSsufwWlKwPc+l3cN7+wuJlK6uz0YdJEOlQDbl6jo/YlPi4mb8agUkVC8BF7V8NuzeyPNqRksA3hztKQ==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/util-deprecate": {
          "version": "1.0.2",
          "resolved": "https://registry.npmjs.org/util-deprecate/-/util-deprecate-1.0.2.tgz",
          "integrity": "sha512-EPD5q1uXyFxJpCrLnCc1nHnq3gOa6DZBocAIiI2TaSCA7VCJ1UJDMagCzIkXNsUYfD1daK//LTEQ8xiIbrHtcw==",
          "license": "MIT"
        },
        "node_modules/vary": {
          "version": "1.1.2",
          "resolved": "https://registry.npmjs.org/vary/-/vary-1.1.2.tgz",
          "integrity": "sha512-BNGbWLfd0eUPabhkXUVm0j8uuvREyTh5ovRa/dyow/BqAbZJyC+5fU+IzQOzmAKzYqYRAISoRhdQr3eIZ/PXqg==",
          "license": "MIT",
          "engines": {
            "node": ">= 0.8"
          }
        },
        "node_modules/which": {
          "version": "2.0.2",
          "resolved": "https://registry.npmjs.org/which/-/which-2.0.2.tgz",
          "integrity": "sha512-BLI3Tl1TW3Pvl70l3yq3Y64i+awpwXqsGBYWkkqMtnbXgrMD+yj7rhW0kuEDxzJaYXGjEW5ogapKNMEKNMjibA==",
          "license": "ISC",
          "dependencies": {
            "isexe": "^2.0.0"
          },
          "bin": {
            "node-which": "bin/node-which"
          },
          "engines": {
            "node": ">= 8"
          }
        },
        "node_modules/wrap-ansi": {
          "version": "8.1.0",
          "resolved": "https://registry.npmjs.org/wrap-ansi/-/wrap-ansi-8.1.0.tgz",
          "integrity": "sha512-si7QWI6zUMq56bESFvagtmzMdGOtoxfR+Sez11Mobfc7tm+VkUckk9bW2UeffTGVUbOksxmSw0AA2gs8g71NCQ==",
          "license": "MIT",
          "dependencies": {
            "ansi-styles": "^6.1.0",
            "string-width": "^5.0.1",
            "strip-ansi": "^7.0.1"
          },
          "engines": {
            "node": ">=12"
          },
          "funding": {
            "url": "https://github.com/chalk/wrap-ansi?sponsor=1"
          }
        },
        "node_modules/wrap-ansi-cjs": {
          "name": "wrap-ansi",
          "version": "7.0.0",
          "resolved": "https://registry.npmjs.org/wrap-ansi/-/wrap-ansi-7.0.0.tgz",
          "integrity": "sha512-YVGIj2kamLSTxw6NsZjoBxfSwsn0ycdesmc4p+Q21c5zPuZ1pl+NfxVdxPtdHvmNVOQ6XSYG4AUtyt/Fi7D16Q==",
          "license": "MIT",
          "dependencies": {
            "ansi-styles": "^4.0.0",
            "string-width": "^4.1.0",
            "strip-ansi": "^6.0.0"
          },
          "engines": {
            "node": ">=10"
          },
          "funding": {
            "url": "https://github.com/chalk/wrap-ansi?sponsor=1"
          }
        },
        "node_modules/wrap-ansi-cjs/node_modules/ansi-regex": {
          "version": "5.0.1",
          "resolved": "https://registry.npmjs.org/ansi-regex/-/ansi-regex-5.0.1.tgz",
          "integrity": "sha512-quJQXlTSUGL2LH9SUXo8VwsY4soanhgo6LNSm84E1LBcE8s3O0wpdiRzyR9z/ZZJMlMWv37qOOb9pdJlMUEKFQ==",
          "license": "MIT",
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/wrap-ansi-cjs/node_modules/ansi-styles": {
          "version": "4.3.0",
          "resolved": "https://registry.npmjs.org/ansi-styles/-/ansi-styles-4.3.0.tgz",
          "integrity": "sha512-zbB9rCJAT1rbjiVDb2hqKFHNYLxgtk8NURxZ3IZwD3F6NtxbXZQCnnSi1Lkx+IDohdPlFp222wVALIheZJQSEg==",
          "license": "MIT",
          "dependencies": {
            "color-convert": "^2.0.1"
          },
          "engines": {
            "node": ">=8"
          },
          "funding": {
            "url": "https://github.com/chalk/ansi-styles?sponsor=1"
          }
        },
        "node_modules/wrap-ansi-cjs/node_modules/emoji-regex": {
          "version": "8.0.0",
          "resolved": "https://registry.npmjs.org/emoji-regex/-/emoji-regex-8.0.0.tgz",
          "integrity": "sha512-MSjYzcWNOA0ewAHpz0MxpYFvwg6yjy1NG3xteoqz644VCo/RPgnr1/GGt+ic3iJTzQ8Eu3TdM14SawnVUmGE6A==",
          "license": "MIT"
        },
        "node_modules/wrap-ansi-cjs/node_modules/string-width": {
          "version": "4.2.3",
          "resolved": "https://registry.npmjs.org/string-width/-/string-width-4.2.3.tgz",
          "integrity": "sha512-wKyQRQpjJ0sIp62ErSZdGsjMJWsap5oRNihHhu6G7JVO/9jIB6UyevL+tXuOqrng8j/cxKTWyWUwvSTriiZz/g==",
          "license": "MIT",
          "dependencies": {
            "emoji-regex": "^8.0.0",
            "is-fullwidth-code-point": "^3.0.0",
            "strip-ansi": "^6.0.1"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/wrap-ansi-cjs/node_modules/strip-ansi": {
          "version": "6.0.1",
          "resolved": "https://registry.npmjs.org/strip-ansi/-/strip-ansi-6.0.1.tgz",
          "integrity": "sha512-Y38VPSHcqkFrCpFnQ9vuSXmquuv5oXOKpGeT6aGrr3o3Gc9AlVa6JBfUSOCnbxGGZF+/0ooI7KrPuUSztUdU5A==",
          "license": "MIT",
          "dependencies": {
            "ansi-regex": "^5.0.1"
          },
          "engines": {
            "node": ">=8"
          }
        },
        "node_modules/wrappy": {
          "version": "1.0.2",
          "resolved": "https://registry.npmjs.org/wrappy/-/wrappy-1.0.2.tgz",
          "integrity": "sha512-l4Sp/DRseor9wL6EvV2+TuQn63dMkPjZ/sp9XkghTEbV9KlPS1xUsZ3u7/IQO4wxtcFB4bgpQPRcR3QCvezPcQ==",
          "license": "ISC"
        },
        "node_modules/ws": {
          "version": "8.21.3",
          "resolved": "https://registry.npmjs.org/ws/-/ws-8.21.3.tgz",
          "integrity": "sha512-201TZ/kPWxoPr/OKWjquZR1SWKXcvxdH+e1xrx89b3YbmzLMFCLfnaG1HFIgWzJOEWZ7MvpK++odZufgYR50Rw==",
          "license": "MIT",
          "engines": {
            "node": ">=10.0.0"
          },
          "peerDependencies": {
            "bufferutil": "^4.0.1",
            "utf-8-validate": ">=5.0.2"
          },
          "peerDependenciesMeta": {
            "bufferutil": {
              "optional": true
            },
            "utf-8-validate": {
              "optional": true
            }
          }
        },
        "node_modules/yaml": {
          "version": "2.9.0",
          "resolved": "https://registry.npmjs.org/yaml/-/yaml-2.9.0.tgz",
          "integrity": "sha512-2AvhNX3mb8zd6Zy7INTtSpl1F15HW6Wnqj0srWlkKLcpYl/gMIMJiyuGq2KeI2YFxUPjdlB+3Lc10seMLtL4cA==",
          "license": "ISC",
          "bin": {
            "yaml": "bin.mjs"
          },
          "engines": {
            "node": ">= 14.6"
          },
          "funding": {
            "url": "https://github.com/sponsors/eemeli"
          }
        },
        "node_modules/yauzl": {
          "version": "3.2.0",
          "resolved": "https://registry.npmjs.org/yauzl/-/yauzl-3.2.0.tgz",
          "integrity": "sha512-Ow9nuGZE+qp1u4JIPvg+uCiUr7xGQWdff7JQSk5VGYTAZMDe2q8lxJ10ygv10qmSj031Ty/6FNJpLO4o1Sgc+w==",
          "license": "MIT",
          "dependencies": {
            "buffer-crc32": "~0.2.3",
            "pend": "~1.2.0"
          },
          "engines": {
            "node": ">=12"
          }
        },
        "node_modules/yazl": {
          "version": "2.5.1",
          "resolved": "https://registry.npmjs.org/yazl/-/yazl-2.5.1.tgz",
          "integrity": "sha512-phENi2PLiHnHb6QBVot+dJnaAZ0xosj7p3fWl+znIjBDlnMI2PsZCJZ306BPTFOaHf5qdDEI8x5qFrSOBN5vrw==",
          "license": "MIT",
          "dependencies": {
            "buffer-crc32": "~0.2.3"
          }
        },
        "node_modules/zod": {
          "version": "4.5.2",
          "resolved": "https://registry.npmjs.org/zod/-/zod-4.5.2.tgz",
          "integrity": "sha512-XkYXCol10+ba/6F/cueWV+TezUeOqXW0hdeJt5CdXjTYeAgAQg5N03RQdJ80mhfFE72+pblvYMW4wy2Qp4Qbrg==",
          "license": "MIT",
          "funding": {
            "url": "https://github.com/sponsors/colinhacks"
          }
        },
        "node_modules/zod-to-json-schema": {
          "version": "3.25.2",
          "resolved": "https://registry.npmjs.org/zod-to-json-schema/-/zod-to-json-schema-3.25.2.tgz",
          "integrity": "sha512-O/PgfnpT1xKSDeQYSCfRI5Gy3hPf91mKVDuYLUHZJMiDFptvP41MSnWofm8dnCm0256ZNfZIM7DSzuSMAFnjHA==",
          "license": "ISC",
          "peerDependencies": {
            "zod": "^3.25.28 || ^4"
          }
        },
        "node_modules/zustand": {
          "version": "5.0.15",
          "resolved": "https://registry.npmjs.org/zustand/-/zustand-5.0.15.tgz",
          "integrity": "sha512-MpSEjRiBkA9crSYeOUH32rJC7SVqAbm0Fqcqge/bUi2PPoLcBWKOsG+C8mevmpr8TwXHBVkChbbJiyvkE+i/3A==",
          "license": "MIT",
          "engines": {
            "node": ">=12.20.0"
          },
          "peerDependencies": {
            "@types/react": ">=18.0.0",
            "immer": ">=9.0.6",
            "react": ">=18.0.0",
            "use-sync-external-store": ">=1.2.0"
          },
          "peerDependenciesMeta": {
            "@types/react": {
              "optional": true
            },
            "immer": {
              "optional": true
            },
            "react": {
              "optional": true
            },
            "use-sync-external-store": {
              "optional": true
            }
          }
        }
      }
    }
    EOF
  '';
in
buildNpmPackage rec {
  pname = "playwriter";
  version = "0.4.0";
  inherit src;
  npmDepsHash = "sha256-upH7g6sQ11bO1T1ojAP5FqoXrY2nIjpt2Q71ro8FHcQ=";
  dontNpmBuild = true;
  nativeBuildInputs = [ makeWrapper ];

  installPhase = ''
    runHook preInstall
    mkdir -p "$out/lib/playwriter" "$out/bin"
    cp -R node_modules "$out/lib/playwriter/"
    makeWrapper ${nodejs}/bin/node "$out/bin/playwriter" \
      --add-flags "$out/lib/playwriter/node_modules/playwriter/bin.js"
    runHook postInstall
  '';

  meta = {
    description = "Control a browser with Playwright-style code from AI agents";
    homepage = "https://github.com/remorses/playwriter";
    license = lib.licenses.mit;
    mainProgram = "playwriter";
    platforms = nodejs.meta.platforms;
  };
}
