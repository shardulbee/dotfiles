{ monstar }:
{
  lib,
  options,
  pkgs,
  ...
}:

let
  monstarTerminfo = pkgs.runCommand "monstar-terminfo" { nativeBuildInputs = [ pkgs.ncurses ]; } ''
    mkdir -p "$out/share/terminfo"
    tic -x -o "$out/share/terminfo" ${monstar.outPath}/dist/monstar.terminfo
  '';
in
{
  programs = {
    atuin = {
      enable = true;
      enableFishIntegration = true;
      flags = [ "--disable-up-arrow" ];
    };
    direnv = {
      enable = true;
      enableFishIntegration = true;
    };
    fish = {
      enable = true;
      functions = {
        fish_greeting = "";
        fish_vcs_prompt = "";
      };
      interactiveShellInit = ''
        fish_add_path -gm "$HOME/.local/bin" "$HOME/bin" /opt/homebrew/bin
      '';
      shellInitLast = ''
        test -f "$HOME/.config/fish/local.fish"; and source "$HOME/.config/fish/local.fish"
      '';
    };
    fzf = {
      enable = true;
      enableFishIntegration = true;
    }
    // lib.optionalAttrs (lib.hasAttrByPath [ "programs" "fzf" "historyWidget" "command" ] options) {
      historyWidget.command = "";
    };
    zoxide = {
      enable = true;
      enableFishIntegration = true;
    };
  };

  home = {
    packages = with pkgs; [
      jjui
      jujutsu
      monstarTerminfo
      tmux
    ];
    sessionPath = [ "$HOME/.local/bin" ];
    sessionVariables.EDITOR = "nvim";
  };

  xdg.configFile = {
    "jj/config.toml".text = ''
      [user]
      name = "Shardul Baral"
      email = "16765155+shardulbee@users.noreply.github.com"

      [ui]
      default-command = 'log'

      [revset-aliases]
      'closest_bookmark(to)' = 'heads(::to & bookmarks())'

      [aliases]
      # Move the closest bookmark to the current commit. Useful when working on a
      # named branch, creating a bunch of commits, and then needing to update the
      # bookmark before pushing.
      tug = ["bookmark", "move", "--from", "closest_bookmark(@-)", "--to", "@-"]

      [template-aliases]
      'format_timestamp(timestamp)' = 'timestamp.ago()'
    '';
    "jjui/config.lua".source = ./config/jjui.lua;
    "tmux/tmux.conf".source = ./config/tmux.conf;
  };
}
