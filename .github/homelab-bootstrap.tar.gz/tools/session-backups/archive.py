#!/usr/bin/env python3
"""Explicit-ID Amp conversation archive. No discovery, deletion, or scheduling."""

import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
from pathlib import Path

DEFAULT_ROOT = Path.home() / ".local/state/amp-archive-experiment/archive"
THREAD_ID = re.compile(r"T-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}")


def private_dir(path):
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.is_symlink() or path.stat().st_uid != os.getuid():
        raise ValueError("Archive directories must be owned, non-symlink directories")
    path.chmod(0o700)


def write(path, data):
    with path.open("xb") as stream:
        os.chmod(path, 0o600)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def references(value, path="$", result=None):
    """Inventory candidates, not an assertion that all attachments were found."""
    if result is None:
        result = []
    if isinstance(value, dict):
        for key, item in value.items():
            location = f"{path}.{key}"
            if re.search(r"attach|image|asset|sourcePath", key, re.IGNORECASE):
                result.append({"path": location, "kind": "field", "value": item})
            references(item, location, result)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            references(item, f"{path}[{index}]", result)
    elif isinstance(value, str):
        for url in re.findall(r"(?:https?://|file://|attachment://)[^\s<>\"`]+", value):
            result.append({"path": path, "kind": "url-candidate", "value": url})
    return result


def cli(amp, *args, timeout=120):
    try:
        result = subprocess.run(
            [amp, *args], capture_output=True, timeout=timeout, check=False
        )
    except (OSError, subprocess.TimeoutExpired):
        raise RuntimeError(
            "Amp invocation failed or timed out; existing snapshots retained"
        ) from None
    if result.returncode:
        # Do not echo CLI stderr: it can contain private conversation data.
        raise RuntimeError("Amp returned an error; existing snapshots retained")
    return result.stdout


def capture(root, amp, thread, version=None, inventory_references=True):
    if not THREAD_ID.fullmatch(thread):
        raise ValueError("Expected an explicit T-UUID thread ID")
    private_dir(root)
    directory = root / thread
    private_dir(directory)
    raw = cli(amp, "threads", "export", thread)
    try:
        payload = json.loads(raw)
        if payload.get("id") != thread or not isinstance(payload.get("messages"), list):
            raise ValueError()
    except (ValueError, AttributeError):
        raise RuntimeError(
            "Unexpected JSON export contract; existing snapshots retained"
        ) from None
    markdown = cli(amp, "threads", "markdown", thread)
    if not markdown.strip():
        raise RuntimeError("Empty Markdown export; existing snapshots retained")
    if version is None:
        version = cli(amp, "--version").decode().strip()
    now = datetime.datetime.now(datetime.timezone.utc)
    name = now.strftime("%Y%m%dT%H%M%S.%fZ")
    stage = Path(tempfile.mkdtemp(prefix=".pending-", dir=directory))
    pointer = directory / (".latest-" + stage.name)
    try:
        write(stage / "thread.json", raw)
        write(stage / "thread.md", markdown)
        if inventory_references:
            write(stage / "references.json", encoded(references(payload)))
        write(
            stage / "metadata.json",
            encoded(
                {
                    "schemaVersion": 1,
                    "threadId": thread,
                    "capturedAt": now.isoformat(),
                    "ampVersion": version,
                    "messageCount": len(payload["messages"]),
                    "sha256": {
                        "thread.json": hashlib.sha256(raw).hexdigest(),
                        "thread.md": hashlib.sha256(markdown).hexdigest(),
                    },
                    "scope": "Conversation only; attachment bytes and executor filesystem not backed up",
                    "consistency": "JSON and Markdown fetched separately; active threads may differ",
                }
            ),
        )
        sync_dir(stage)
        os.rename(stage, directory / name)
        sync_dir(directory)
        write(pointer, (name + "\n").encode())
        os.replace(pointer, directory / "latest")
        sync_dir(directory)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
        pointer.unlink(missing_ok=True)
    return name


def latest_files(root):
    for thread in sorted(root.glob("T-*")):
        if not THREAD_ID.fullmatch(thread.name) or not (thread / "latest").is_file():
            continue
        name = (thread / "latest").read_text().strip()
        if not re.fullmatch(r"\d{8}T\d{6}\.\d{6}Z", name):
            raise RuntimeError("Invalid snapshot pointer")
        yield thread.name, thread / name


def rebuild(root):
    private_dir(root)
    fd, temporary = tempfile.mkstemp(prefix=".index-", dir=root)
    os.close(fd)
    temporary = Path(temporary)
    count = 0
    try:
        with sqlite3.connect(temporary) as db:
            db.execute("CREATE VIRTUAL TABLE threads USING fts5(id UNINDEXED, body)")
            for thread, snapshot in latest_files(root):
                db.execute(
                    "INSERT INTO threads VALUES (?, ?)",
                    (thread, (snapshot / "thread.md").read_text()),
                )
                count += 1
        db.close()
        with temporary.open("rb") as stream:
            os.fsync(stream.fileno())
        os.replace(temporary, root / "search.sqlite3")
        sync_dir(root)
    finally:
        temporary.unlink(missing_ok=True)
    return count


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--amp", default=str(Path.home() / ".amp/bin/amp"))
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("capture").add_argument("threads", nargs="+")
    commands.add_parser("index")
    commands.add_parser("search").add_argument("query")
    args = parser.parse_args()
    try:
        if args.command == "capture":
            for thread in args.threads:
                print(thread, capture(args.root, args.amp, thread))
        elif args.command == "index":
            print("Indexed threads:", rebuild(args.root))
        else:
            db = sqlite3.connect(
                (args.root / "search.sqlite3").resolve().as_uri() + "?mode=ro", uri=True
            )
            try:
                for row in db.execute(
                    "SELECT id FROM threads WHERE threads MATCH ?", (args.query,)
                ):
                    print(row[0])
            finally:
                db.close()
    except (RuntimeError, ValueError, OSError, sqlite3.Error):
        parser.exit(
            1,
            "Archive operation failed. No prior snapshots deleted. Check CLI access and local files privately.\n",
        )


if __name__ == "__main__":
    main()
