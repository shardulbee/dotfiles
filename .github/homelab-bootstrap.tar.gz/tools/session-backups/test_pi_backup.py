import hashlib
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import archive
import pi_backup
import verify


class PiTests(unittest.TestCase):
    def setUp(self):
        self.umask = os.umask(0o077)
        self.addCleanup(os.umask, self.umask)
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "backups"
        self.source = Path(self.temporary.name) / "source"
        self.source.mkdir()
        (self.source / "session.jsonl").write_bytes(b'{"test":true}\n')
        (self.source / "link").symlink_to("session.jsonl")
        self.run = subprocess.run

    def local_rsync(self, command, **kwargs):
        self.assertIn("StrictHostKeyChecking=yes", command[command.index("-e") + 1])
        self.assertIn(
            command[-2], [f"{host}:.pi/agent/sessions/" for host in pi_backup.HOSTS]
        )
        command = [*command[:-2], str(self.source) + "/", command[-1]]
        return self.run(command, **kwargs)

    def test_real_rsync_format_permissions_retention_and_verification(self):
        # Allow-list only the transport substitution; exercise the real rsync flags.
        with patch.object(pi_backup.subprocess, "run", side_effect=self.local_rsync):
            first = pi_backup.capture(self.root, "turbogadget")
            pi_backup.capture(self.root, "sharchy")
            second = pi_backup.capture(self.root, "turbogadget")
        self.assertNotEqual(first, second)
        self.assertTrue(first.is_dir())
        self.assertEqual(verify.verify_pi(self.root), {"turbogadget": 1, "sharchy": 1})
        entries = json.loads((first / "manifest.json").read_bytes())
        self.assertEqual(
            entries,
            [
                {"path": "link", "type": "symlink", "target": "session.jsonl"},
                {
                    "path": "session.jsonl",
                    "type": "file",
                    "bytes": 14,
                    "sha256": hashlib.sha256(b'{"test":true}\n').hexdigest(),
                },
            ],
        )
        self.assertFalse(list(self.root.rglob(".pending-*")))
        self.assertFalse(list(self.root.rglob("in-progress")))
        (second / "sessions/session.jsonl").write_bytes(b"corrupted")
        with self.assertRaises(ValueError):
            verify.verify_pi(self.root)

    def test_source_deletion_during_copy_fails_without_publishing(self):
        with patch.object(pi_backup.subprocess, "run", side_effect=self.local_rsync):
            first = pi_backup.capture(self.root, "turbogadget")

        def changed(command, **kwargs):
            if "-anrc" in command:
                (self.source / "session.jsonl").unlink()
            return self.local_rsync(command, **kwargs)

        with (
            patch.object(pi_backup.subprocess, "run", side_effect=changed),
            self.assertRaises(RuntimeError),
        ):
            pi_backup.capture(self.root, "turbogadget")
        base = self.root / "turbogadget"
        self.assertEqual(
            json.loads((base / "latest.json").read_bytes())["snapshot"], first.name
        )
        self.assertTrue((base / "in-progress").is_file())
        self.assertEqual(len(list(base.glob(".pending-*"))), 1)
        with self.assertRaises(RuntimeError):
            pi_backup.capture(self.root, "turbogadget")

    def test_transfer_failure_retains_pending_without_latest(self):
        with (
            patch.object(
                pi_backup.subprocess,
                "run",
                side_effect=subprocess.CalledProcessError(23, "rsync"),
            ),
            self.assertRaises(subprocess.CalledProcessError),
        ):
            pi_backup.capture(self.root, "sharchy")
        self.assertFalse((self.root / "sharchy/latest.json").exists())
        self.assertTrue((self.root / "sharchy/in-progress").exists())

    def test_rejects_host_paths(self):
        with self.assertRaises(ValueError):
            pi_backup.capture(self.root, "../../bad")
        self.assertFalse(self.root.exists())

    def test_amp_verification_is_read_only_and_detects_corruption(self):
        thread = "T-00000000-0000-0000-0000-000000000000"
        with patch.object(
            archive,
            "cli",
            side_effect=[archive.encoded({"id": thread, "messages": []}), b"test"],
        ):
            name = archive.capture(self.root, "amp", thread, "test")
        before = {p: p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(verify.verify_amp(self.root), 1)
        self.assertEqual(
            before, {p: p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        )
        (self.root / thread / name / "thread.md").write_bytes(b"corrupted")
        with self.assertRaises(ValueError):
            verify.verify_amp(self.root)


if __name__ == "__main__":
    unittest.main()
