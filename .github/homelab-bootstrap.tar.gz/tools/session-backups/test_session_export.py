import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import session_export as export
import knowledge


class ExportTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.home = self.root / "hermes"
        self.home.mkdir()
        self.output = self.root / "output"
        self.output.mkdir()

    def test_cli_defaults_are_database_and_external_state_only(self):
        with (
            patch.object(export.sys, "argv", ["agent-session-export", "amp"]),
            patch.object(export, "run", return_value={}) as run,
            patch("builtins.print"),
        ):
            export.main()
        self.assertEqual(run.call_args.args[0], Path("/var/lib/agent-sessions/amp"))
        self.assertEqual(
            run.call_args.kwargs["database"], Path("/var/lib/knowledge/archive.sqlite3")
        )

    def database(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(path)
        self.addCleanup(db.close)
        db.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA wal_autocheckpoint=0;
            CREATE TABLE sessions (id TEXT PRIMARY KEY, source TEXT, title TEXT,
                started_at REAL, ended_at REAL, parent_session_id TEXT);
            CREATE TABLE messages (id INTEGER PRIMARY KEY, session_id TEXT,
                role TEXT, content TEXT, timestamp REAL, active INTEGER, compacted INTEGER);
            INSERT INTO sessions VALUES ('../雪', 'cli', 'Title\n---', 10, NULL, NULL);
            INSERT INTO messages VALUES (2, '../雪', 'assistant', 'answer 雪', 12, 0, 1);
            INSERT INTO messages VALUES (1, '../雪', 'user', 'question', 11, 1, 0);
            INSERT INTO messages VALUES (3, '../雪', 'tool', 'PRIVATE TOOL OUTPUT', 13, 1, 0);
        """)
        return db

    def test_wal_profiles_content_updates_and_deleted_history(self):
        db = self.database(self.home / "state.db")
        self.database(self.home / "profiles/second/state.db")
        result = export.hermes_scan(self.home, {})
        self.assertEqual(result["profiles"], 2)
        self.assertEqual(len(result["changed"]), 2)
        name = export.filename(["hermes", "hermes", "default", "../雪"])
        body = result["changed"][name]
        self.assertIn('id: "../雪"', body)
        self.assertIn('"active": 0', body)
        self.assertLess(body.index("question"), body.index("answer 雪"))
        self.assertNotIn("PRIVATE TOOL OUTPUT", body)
        self.assertIn('title: "Title\\n---"', body)
        known = result["current"]
        same = export.hermes_scan(self.home, known)
        self.assertEqual(same["changed"], {})
        # Same ID/count/timestamp, edited text: timestamp-only incrementality fails.
        db.execute("UPDATE messages SET content='edited λ' WHERE id=1")
        db.commit()
        changed = export.hermes_scan(self.home, known)
        self.assertEqual(list(changed["changed"]), [name])
        self.assertIn("edited λ", changed["changed"][name])
        # Deleting an old message must also change the export.
        db.execute("DELETE FROM messages WHERE id=2")
        db.commit()
        deleted = export.hermes_scan(self.home, changed["current"])
        self.assertNotIn("answer 雪", deleted["changed"][name])
        db.execute("DELETE FROM sessions")
        db.commit()
        missing = export.hermes_scan(self.home, deleted["current"])
        self.assertNotIn(name, missing["current"])
        self.assertEqual(db.execute("select count(*) from messages").fetchone()[0], 2)

    def test_concurrent_wal_write_does_not_mix_session_snapshots(self):
        db = self.database(self.home / "state.db")
        db.execute(
            "INSERT INTO sessions VALUES ('second', 'cli', 'old title', 20, NULL, NULL)"
        )
        db.execute(
            "INSERT INTO messages VALUES (4, 'second', 'user', 'old text', 21, 1, 0)"
        )
        db.commit()
        render = export.document

        def concurrent(metadata, messages):
            if metadata["id"] == "../雪":
                db.execute("UPDATE sessions SET title='new title' WHERE id='second'")
                db.execute("UPDATE messages SET content='new text' WHERE id=4")
                db.commit()
            return render(metadata, messages)

        with patch.object(export, "document", side_effect=concurrent):
            result = export.hermes_scan(self.home, {})
        body = result["changed"][
            export.filename(["hermes", "hermes", "default", "second"])
        ]
        self.assertIn('title: "old title"', body)
        self.assertIn("old text", body)
        self.assertNotIn("new text", body)

    def test_atomic_failure_retains_manifest(self):
        path = self.output / ".state.json"
        export.atomic(path, '{"marker":"old"}')
        with patch.object(export.os, "replace", side_effect=OSError("disk")):
            with self.assertRaises(OSError):
                export.atomic(path, '{"marker":"new"}')
        self.assertEqual(json.loads(path.read_text()), {"marker": "old"})
        self.assertEqual(list(self.output.glob(".export-*")), [])
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_pi_shapes_identity_and_incremental_parse(self):
        path = self.root / "session.jsonl"
        records = [
            {
                "type": "session",
                "id": "session-雪",
                "timestamp": "2026-09-09T00:00:00Z",
                "cwd": "/project",
            },
            {
                "type": "message",
                "id": "m1",
                "timestamp": "time1",
                "message": {"role": "user", "content": "hello"},
            },
            {
                "type": "message",
                "id": "m2",
                "parentId": "m1",
                "message": {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "雪"},
                        {"type": "thinking", "thinking": "HIDDEN"},
                        {"type": "toolCall", "arguments": {"secret": "HIDDEN"}},
                        {"type": "image", "data": "HIDDEN"},
                    ],
                },
            },
            {
                "type": "message",
                "message": {"role": "toolResult", "content": "HIDDEN" * 10000},
            },
        ]
        path.write_text("\n".join(json.dumps(r) for r in records))
        context = ("host", "project/session.jsonl", "capture-time")
        name = export.filename(["pi", "host", context[1]])
        items = [(name, path, context)]
        first = export.local_scan(items, export.pi_document, {})
        body = first["changed"][name]
        self.assertIn("雪", body)
        self.assertIn('"parent_id": "m1"', body)
        self.assertIn('captured_at: "capture-time"', body)
        self.assertNotIn("HIDDEN", body)
        with patch.object(
            export, "pi_document", side_effect=AssertionError("must skip")
        ):
            self.assertEqual(
                export.local_scan(items, export.pi_document, first["current"])[
                    "changed"
                ],
                {},
            )
        path.write_text(path.read_text().replace("hello", "updated"))
        self.assertIn(
            "updated",
            export.local_scan(items, export.pi_document, first["current"])["changed"][
                name
            ],
        )
        self.assertNotEqual(name, export.filename(["pi", "another-host", context[1]]))
        self.assertNotEqual(
            export.filename(["a--b", "c"]), export.filename(["a", "b--c"])
        )

    def test_database_only_unchanged_markers_and_missing_session_retention(self):
        native = self.database(self.home / "state.db")
        path = self.root / "archive.sqlite3"
        db = knowledge.connect(path)
        self.addCleanup(db.close)
        with patch.object(
            export,
            "remote_hermes",
            side_effect=lambda host, known, archived: export.hermes_scan(
                self.home, known, archived
            ),
        ):

            def run():
                return export.run(self.output, "hermes", self.root, "host", path)

            self.assertEqual(run()["upserted"], 1)
            before = tuple(db.execute("SELECT * FROM documents").fetchone())
            self.assertIn(
                "PRIVATE TOOL OUTPUT",
                db.execute("SELECT raw_json FROM documents").fetchone()[0],
            )
            manifest = self.output / ".state.json"
            stamp = manifest.stat().st_mtime_ns
            same = run()
            self.assertEqual((same["changed"], same["upserted"]), (0, 0))
            self.assertEqual(manifest.stat().st_mtime_ns, stamp)
            self.assertEqual(
                tuple(db.execute("SELECT * FROM documents").fetchone()), before
            )
            native.execute("UPDATE messages SET content='changed source' WHERE id=1")
            native.commit()
            self.assertEqual(run()["upserted"], 1)
            self.assertIn(
                "changed source",
                db.execute("SELECT markdown FROM documents").fetchone()[0],
            )
            native.execute("DELETE FROM sessions")
            native.commit()
            self.assertEqual(run()["missing"], 1)
            self.assertEqual(
                db.execute("SELECT count(*) FROM documents").fetchone()[0], 1
            )
        self.assertEqual(list(self.root.rglob("*.md")), [])

    def test_amp_provenance_and_text_only(self):
        path = self.root / "thread.json"
        path.write_text(
            json.dumps(
                {
                    "id": "T-example",
                    "created": 1,
                    "updatedAt": 2,
                    "messages": [
                        {
                            "messageId": 4,
                            "role": "assistant",
                            "content": [
                                {"type": "text", "text": "reply"},
                                {"type": "tool_result", "text": "OMIT"},
                            ],
                        }
                    ],
                }
            )
        )
        (self.root / "metadata.json").write_text('{"capturedAt":"captured"}')
        body = export.amp_document(path, ("T-example", self.root))
        self.assertIn("reply", body)
        self.assertNotIn("OMIT", body)
        self.assertIn("updated: 2", body)
        self.assertIn("https://ampcode.com/threads/T-example", body)
        with self.assertRaises(ValueError):
            export.amp_document(path, ("wrong-id", self.root))


if __name__ == "__main__":
    unittest.main()
