# Session backups

Sharbox refreshes Amp sessions every minute and Hermes/Pi exports every five
minutes. Incremental Amp refresh retains raw JSON versions before DB ingestion.
Pi pulls are manual only; all original archives remain.

## Retained latest snapshots

`~/.local/state/session-backups/<source>/latest` points to the last verified
generation. Amp data is under `latest/archive/`; Pi data is under
`latest/pi/<host>/`. A successful run atomically switches the pointer, then
removes older scheduled generations. Failed runs leave the last good copy alone
and can be retried manually. An interrupted generation is cleaned
up after the next successful run. During capture, space is needed for both old
and new.

The Amp snapshot reflects
the currently discoverable threads, including archived threads; it does not retain
threads that have disappeared from a successful complete inventory.

The journal prints success/failure only. Detailed successful run logs stay private
inside each generation. To invoke directly, run `session-backup-latest amp`,
`session-backup-latest turbogadget`, or `session-backup-latest sharchy` as `shardul`.

## Incremental session ingestion

Session exporters write raw archives and the SQLite database, never the vault.
Cleaned Markdown retains original IDs, host/profile, timestamps, and provenance.
Hermes identities distinguish the default home from every named profile. Pi
identities include host and relative session path, preserving separate workspaces.

`agent-session-export-{hermes,amp,pi}.timer` refreshes Amp one minute after its
previous run finishes, Hermes/Pi after five minutes. Each service has a five-minute
timeout and a nonblocking source-specific lock. A failed run retries on the next timer; sources
are independent. The Amp reader also shares the manual snapshot publisher's lock so its
source generation cannot disappear during a read.

- Hermes runs a read-only, WAL-aware SQLite transaction on the VM over existing
  SSH access, separately for the default home and each `profiles/*/state.db`.
  It hashes full session/message rows for the archive and user/assistant text for
  Markdown to catch edits, rewinds, and deletions that counters/timestamps miss.
  Only changed records/documents cross SSH. Original databases remain on Hermes.
- Amp fully paginates `threads search author:me --json`, compares ISO `updatedAt`,
  and downloads JSON only for changed/new sessions. Each poll makes one CLI search
  call per 100-row page plus the empty page, then at most 16 export calls using
  four workers, with 30-second CLI timeouts. Oldest refreshed sessions get priority
  so deferred changes catch up. These are CLI call counts, not measured HTTP
  request counts. Matching retained snapshots seed the corpus and raw store without
  downloads. Fresh raw JSON is saved before advancing the marker under
  `~/.local/state/agent-session-raw/amp/<thread>/<sha256>.json`; prior versions remain.
  A manual full snapshot can reconcile edits that do not advance update markers.
  No ordering or early cutoff is assumed. Two complete scans must omit a thread
  before removing its polling marker; its DB record remains. Offset pagination
  still is not a transactional inventory.
  Do not substitute `threads list`: its misleading `updated` field represents
  `userLastInteractedAt`, and its message count excludes tool-result-only messages.
  Neither detects assistant-only progress. Search exposes the same `updatedAt`
  field as exports. Search-index lag can still delay discovery.
- Pi normalizes each host's newest completed manual or retained scheduled
  snapshot. Refresh never connects to laptops. Run `pi-backup <host>` manually to
  capture newer data, then refresh or wait for the next export timer.

Local immutable snapshots use path/size/mtime to skip unchanged parsing.
Locks and `.state.json` live under `/var/lib/agent-sessions/<source>/`.
DB ingestion commits before advancing markers; missing sessions remain in the DB.

Exports include user/assistant text, role and available message timestamps/IDs.
Tool output, reasoning, and attachment bytes are omitted rather than flooding
search. Hermes active/compacted flags and Pi parent IDs distinguish retained
historical branches; these are histories, not reconstructed current model context.

```sh
agent-session-export hermes
agent-session-export amp
agent-session-export pi
systemctl list-timers 'agent-session-export-*'
```

Manual full Amp backup downloads JSON and Markdown for every thread. It remains
available as a reconciliation tool. One-minute freshness is best effort, not guaranteed during a backlog,
failed requests, pagination races, or mutations that do not advance update markers.

## SQLite archive

`/var/lib/knowledge/archive.sqlite3` is primary retained session data and a
refreshable note snapshot, owned by `shardul` with private directory/file modes.
Ingestion alone writes it. Note edits belong to the Obsidian service; nothing
copies DB content back to the vault.

`documents` has primary key `(source, source_id)`, title, source path,
source update time, Markdown, nullable `raw_json`/`raw_format`, SHA256 content/raw
hashes, and `indexed_at`. Amp IDs are thread IDs; Pi IDs encode host/relative path;
Hermes IDs encode host/profile/session ID. Other IDs are paths relative to their
source folder. `documents_fts` indexes title/Markdown through transactional
insert/update/delete triggers. Duplicate content does not update `indexed_at`;
mtime-only changes do not rewrite records. Raw-only edits do not rewrite FTS.

- Amp preserves native JSON bytes; Pi preserves native JSONL bytes, explicitly
  marked `raw_format=jsonl`. Hermes preserves every session/message column as
  `sqlite-json`, including tools, reasoning, and API fields, from one read snapshot
  per profile. BLOB cells are `{"$blob":"<lowercase hex>"}`; an empty BLOB has
  an empty hex string. Other SQLite cells retain their JSON scalar types, so a
  text value containing JSON remains a string. Decode the hex to recover the
  exact BLOB bytes. Cleaned Markdown uses the existing source renderers.
- ChatGPT and Claude sessions preserve their exact Markdown-only exports in the
  database; raw JSON is absent, not synthesized. The importer recognizes
  `ChatGPT Exports/`, `Claude Exports/`, and `Agent Sessions/` as session paths,
  not ordinary `notes` records. External media is not fetched;
  inline data in raw JSON/JSONL remains intact.
- Session rows survive upstream disappearance. Each row holds its latest
  captured state, not every historical revision. Original archives remain.

Session exporters upsert before advancing their manifests and share source locks
with manual imports. `knowledge-notes.timer` scans the vault every five minutes
under the sync lock. Missing ordinary notes are removed only after a complete,
successful scan; failed scans roll back the entire batch. Session rows are never
removed by note scans. Source update times are native Amp timestamps, Hermes
activity/message times, or filesystem mtimes for Pi/Markdown files.

Run `knowledge-import amp`, `pi`, `hermes`, or `notes` as `shardul` for full
reconciliation. `knowledge-import verify` checks SQLite integrity, FTS consistency,
and every stored content/raw hash, printing aggregate counts/bytes only.

`knowledge-backup.timer` makes daily SQLite backup-API snapshots under
`/var/lib/knowledge/backups/`, with integrity/hash verification and SHA256 sidecars.
Snapshots use DELETE journaling and need no WAL/SHM files. After a successful
default backup, timestamped snapshots strictly older than seven days by their UTC
filename are removed with their matching, verified checksum sidecars. Named
snapshots such as `initial-verified.sqlite3`, symlinks, incomplete or mismatched
pairs, and nested directories are excluded. Explicit-destination and custom-database
backup commands do not trigger pruning.
These local backups do not protect against disk loss.
Run `knowledge-import backup --destination /private/fresh/snapshot.sqlite3` for
an explicit snapshot. Restore into a fresh private directory and verify with
`knowledge-import verify --database /private/restore/archive.sqlite3` before
adopting it. Stop DB ingestion before a production restore; never replace a live
SQLite file while its writers or WAL/SHM files remain attached.

## Manual snapshots

Run these commands as `shardul`,
not root or `sharbox-deploy`.

```sh
amp-archive-all --workers 8
amp-archive capture T-00000000-0000-0000-0000-000000000000 # replace with a real ID
amp-archive index
amp-archive search 'query'
pi-backup turbogadget sharchy
session-backups-verify amp
session-backups-verify pi
```

Amp uses the existing authenticated `~/.amp/bin/amp`; `--amp` overrides it.
`--root` overrides each data root. For `amp-archive`, options precede the
subcommand. Run only one writer per backup root.
Verification is offline and read-only, checks latest snapshot hashes and
private permissions, and prints counts only. It does not validate an Amp restore.

## Retained formats and locations

- Amp: `~/.local/state/amp-archive-experiment/archive/`. Each thread directory has
  timestamped `thread.json`, `thread.md`, `metadata.json`, optional
  `references.json`, and a text `latest` pointer. Raw export bytes are retained.
  Bulk inventories and reports live in `runs/`; `search.sqlite3` is rebuildable.
- Pi: `~/.local/state/pi-backups/<host>/<UTC timestamp>/`. Each snapshot contains
  `sessions/`, `transfer.log`, `verification.log`, per-file SHA-256
  `manifest.json`, and `metadata.json`. `latest.json` selects the completed copy.
  Symlinks are recorded as links, not followed.

Pi reads `<host>:.pi/agent/sessions/` using Sharbox's existing SSH configuration,
key and known hosts. It runs rsync, then a read-only checksum comparison before
publishing. Source originals and historical snapshots are never deleted. Failed
Pi copies retain `.pending-*` and `in-progress`; inspect these privately before
moving the pointer aside to retry. Do not erase the retained copy blindly.

Files are owner-only, not encrypted. Logs, manifests, exports, probes, and search
indexes may contain secrets. Never add them to Git or the Nix store. The package
uses an explicit source allow-list; `.gitignore` excludes known data locations.
There is no off-host copy, attachment download, or orb filesystem backup.

Both tools read live sources, not transactional snapshots. Amp JSON and Markdown
are separate reads. Bulk discovery requires two matching paginated inventories;
it cannot recover deleted or inaccessible threads. Repeat runs retain snapshots.

## Verification

Pi uses private JSON modes, refuses an existing in-progress operation, and detects
source deletions with `--delete` only during the checksum dry run, never during transfer.

The deployment account cannot read private archives. Use the Sharbox runner
as `shardul` for post-deployment verification. Do not broaden deployment access or
copy private data into the orb.

```sh
nix build .#session-backups # runs unit tests and real local-rsync tests
nix shell nixpkgs#python3 nixpkgs#rsync -c python3 -B -m unittest discover -s tools/session-backups -v
```
