import datetime
import hashlib
import io
import json
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import knowledge
import session_export as export


class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.path = self.root / "archive.sqlite3"
        self.db = knowledge.connect(self.path)
        self.addCleanup(self.db.close)

    def row(
        self,
        source="amp",
        identity="same",
        body="orchard apples 雪",
        raw='{"tool":"complete output"}',
    ):
        return export.archive_record(
            [source, identity],
            {"title": "Title", "provenance": "/native", "updated": "2026-09-09"},
            body,
            raw,
            "json" if raw is not None else None,
        )

    def matches(self, word, db=None):
        return (
            (db or self.db)
            .execute(
                "SELECT count(*) FROM documents_fts WHERE documents_fts MATCH ?",
                (word,),
            )
            .fetchone()[0]
        )

    def test_upsert_identity_unicode_and_no_unchanged_rewrites(self):
        row = self.row()
        self.assertEqual(knowledge.ingest(self.db, [row])["upserted"], 1)
        before = tuple(self.db.execute("SELECT rowid,* FROM documents").fetchone())
        changes = self.db.total_changes
        self.assertEqual(knowledge.ingest(self.db, [row])["upserted"], 0)
        self.assertEqual(
            knowledge.ingest(
                self.db, [{**row, "source_updated_at": "mtime-only-change"}]
            )["upserted"],
            0,
        )
        self.assertEqual(self.db.total_changes, changes)
        self.assertEqual(
            tuple(self.db.execute("SELECT rowid,* FROM documents").fetchone()), before
        )
        knowledge.ingest(self.db, [self.row("pi"), self.row("hermes")])
        self.assertEqual(self.matches("orchard"), 3)
        self.assertEqual(self.matches("雪"), 3)
        a = export.archive_record(
            ["hermes", "host", "profile/a", "b"],
            {"provenance": "/db"},
            "one",
            "{}",
            "sqlite-json",
        )
        b = export.archive_record(
            ["hermes", "host", "profile", "a/b"],
            {"provenance": "/db"},
            "two",
            "{}",
            "sqlite-json",
        )
        self.assertNotEqual(a["source_id"], b["source_id"])

    def test_metadata_hash_lookup_uses_covering_index(self):
        row = self.row()
        knowledge.ingest(self.db, [row])
        self.assertEqual(knowledge.hashes(self.db, "amp"), {"same": row["raw_hash"]})
        plan = self.db.execute(
            "EXPLAIN QUERY PLAN SELECT source_id,raw_hash FROM documents WHERE source=?",
            ("amp",),
        ).fetchone()[3]
        self.assertIn("COVERING INDEX documents_source_hash", plan)

    def test_fts_content_updates_and_raw_only_updates_are_coupled(self):
        knowledge.ingest(self.db, [self.row()])
        knowledge.ingest(self.db, [self.row(body="harbor boats")])
        self.assertEqual(self.matches("orchard"), 0)
        self.assertEqual(self.matches("harbor"), 1)
        before = self.db.total_changes
        knowledge.ingest(
            self.db, [self.row(body="harbor boats", raw='{"tool":"changed output"}')]
        )
        self.assertEqual(self.db.total_changes - before, 1)
        self.assertEqual(self.matches("harbor"), 1)
        # Fail after the document update but before the transaction can commit.
        self.db.execute(
            "CREATE TRIGGER reject_update AFTER UPDATE ON documents BEGIN SELECT RAISE(ABORT,'synthetic failure'); END"
        )
        with self.assertRaises(sqlite3.IntegrityError):
            knowledge.ingest(self.db, [self.row(body="desert cactus")])
        self.assertEqual(self.matches("harbor"), 1)
        self.assertEqual(self.matches("desert"), 0)

    def test_failed_full_scan_preserves_notes_and_sessions(self):
        knowledge.ingest(
            self.db,
            [
                self.row("notes", "keep", raw=None),
                self.row("claude"),
                self.row("chatgpt"),
            ],
        )

        def failed():
            yield self.row("notes", "keep", "replacement", None)
            raise PermissionError("unreadable directory")

        with self.assertRaises(PermissionError):
            knowledge.ingest(self.db, failed(), complete_notes=True)
        self.assertEqual(self.matches("orchard"), 3)
        knowledge.ingest(self.db, [], complete_notes=True)
        self.assertEqual(self.matches("orchard"), 2)
        self.assertEqual(
            {r[0] for r in self.db.execute("SELECT source FROM documents")},
            {"claude", "chatgpt"},
        )

    def test_note_scan_excludes_generated_and_preserves_markdown_only_exports(self):
        vault = self.root / "vault"
        for relative in [
            "note.md",
            "ChatGPT Exports/export.md",
            "Claude Exports/export.md",
            "Agent Sessions/amp/generated.md",
            ".obsidian/private.md",
        ]:
            p = vault / relative
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b"# Title\r\n\r\nExact original Markdown.\r\n")
        records = list(knowledge.note_records(vault))
        self.assertEqual({r["source"] for r in records}, {"notes", "chatgpt", "claude"})
        self.assertTrue(all(r["raw_json"] is None for r in records))
        self.assertTrue(all("\r\n" in r["markdown"] for r in records))
        with self.assertRaises(ValueError):
            list(knowledge.note_records(self.root / "missing"))

    def test_pi_native_jsonl_keeps_tools_and_exact_bytes(self):
        path = self.root / "session.jsonl"
        data = [
            {"type": "session", "id": "雪", "timestamp": "now"},
            {"type": "message", "message": {"role": "user", "content": "hello"}},
            {
                "type": "message",
                "message": {"role": "toolResult", "content": "TOOL_PAYLOAD"},
            },
        ]
        raw = "\r\n".join(json.dumps(r, ensure_ascii=False) for r in data) + "\r\n"
        path.write_bytes(raw.encode())
        row = knowledge.pi_record(path, ("host", "project/session.jsonl", "capture"))
        self.assertEqual(row["raw_json"], raw)
        self.assertEqual(row["raw_format"], "jsonl")
        self.assertNotIn("TOOL_PAYLOAD", row["markdown"])
        self.assertIn("TOOL_PAYLOAD", row["raw_json"])

    def test_amp_selects_newest_source_timestamp_and_preserves_raw(self):
        identity = "T-00000000-0000-0000-0000-000000000001"
        directory = self.root / "agent-session-raw/amp" / identity
        directory.mkdir(parents=True)
        for stamp, body in [
            ("2026-09-09T10:00:00+00:00", "new"),
            ("2026-09-09T10:30:00+02:00", "old"),
        ]:
            raw = json.dumps(
                {
                    "id": identity,
                    "updatedAt": stamp,
                    "messages": [
                        {"role": "user", "content": body},
                        {"role": "tool", "content": "COMPLETE_RAW"},
                    ],
                }
            )
            (directory / (export.digest(raw) + ".json")).write_text(raw)
        records = list(knowledge.amp_records(self.root))
        self.assertEqual(len(records), 1)
        self.assertEqual(
            json.loads(records[0]["raw_json"])["messages"][0]["content"], "new"
        )
        self.assertIn("COMPLETE_RAW", records[0]["raw_json"])
        self.assertNotIn("COMPLETE_RAW", records[0]["markdown"])
        knowledge.ingest(self.db, records)
        broken = directory / ("a" * 64 + ".json")
        broken.write_text("{}")
        with self.assertRaises(ValueError):
            knowledge.ingest(self.db, knowledge.amp_records(self.root))
        self.assertEqual(
            self.db.execute("SELECT raw_hash FROM documents").fetchone()[0],
            records[0]["raw_hash"],
        )

    def test_incremental_amp_reads_fresh_raw_not_historical_versions(self):
        identity = "T-00000000-0000-0000-0000-000000000001"
        directory = self.root / "agent-session-raw/amp" / identity
        directory.mkdir(parents=True)
        (directory / "broken-history.json").write_text("invalid old archive")
        path = directory / "fresh.json"
        path.write_text(
            json.dumps(
                {"id": identity, "messages": [], "updatedAt": "2026-09-09T10:00:00Z"}
            )
        )
        row = knowledge.amp_record(path)
        result = {"current": {}, "changed": {identity + ".md": row["markdown"]}}
        import amp_refresh

        with (
            patch.object(amp_refresh, "scan", return_value=result),
        ):
            actual = export.run_scan("amp", self.root, "host", self.root, {}, self.db)
        self.assertEqual(actual["upserted"], 1)
        self.assertEqual(
            self.db.execute("SELECT raw_hash FROM documents").fetchone()[0],
            row["raw_hash"],
        )
        with patch.object(
            knowledge.archive,
            "latest_files",
            side_effect=AssertionError("unnecessary archive walk"),
        ):
            self.assertEqual(list(knowledge.amp_records(self.root, set())), [])

    def test_export_database_failure_does_not_advance_manifest(self):
        body = export.document(
            {"source": "hermes", "id": "session", "provenance": "/db"}, []
        )
        name = "session.md"
        root = self.root / "published"
        storage = self.root / "state"
        root.mkdir()
        storage.mkdir()
        current = {name: {"digest": export.digest(body)}}
        result = {
            "current": current,
            "changed": {name: body},
            "records": [self.row("hermes")],
        }
        with (
            patch.object(export, "remote_hermes", return_value=result),
            patch.object(
                knowledge, "ingest", side_effect=sqlite3.OperationalError("disk full")
            ),
        ):
            with self.assertRaises(sqlite3.OperationalError):
                export.run(storage, "hermes", self.root, "host", database=self.path)
        self.assertFalse((storage / ".state.json").exists())
        self.assertFalse((root / name).exists())

    def test_manifest_failure_retries_without_rewriting_committed_record(self):
        storage = self.root / "state"
        row = self.row("hermes")
        result = {
            "current": {"session.md": {"digest": row["content_hash"]}},
            "changed": {"session.md": row["markdown"]},
            "records": [row],
        }
        with patch.object(export, "remote_hermes", return_value=result):
            with patch.object(export, "atomic", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    export.run(storage, "hermes", self.root, "host", self.path)
            before = tuple(self.db.execute("SELECT * FROM documents").fetchone())
            self.assertFalse((storage / ".state.json").exists())
            retried = export.run(storage, "hermes", self.root, "host", self.path)
        self.assertEqual(retried["upserted"], 0)
        self.assertEqual(
            tuple(self.db.execute("SELECT * FROM documents").fetchone()), before
        )
        self.assertEqual(
            json.loads((storage / ".state.json").read_text()), result["current"]
        )
        self.assertEqual(list(storage.rglob("*.md")), [])

    def test_sqlite_blob_cell_encoding_is_lossless_and_deterministic(self):
        row = self.db.execute("""
            SELECT x'00FF80' AS blob, x'' AS empty, NULL AS nil, 42 AS number,
                '{"$blob":"00ff80"}' AS text
        """).fetchone()
        expected = '{"blob": {"$blob": "00ff80"}, "empty": {"$blob": ""}, "nil": null, "number": 42, "text": "{\\"$blob\\":\\"00ff80\\"}"}'
        actual = export.encoded(export.sqlite_row(row))
        self.assertEqual(actual, expected)
        self.assertEqual(
            export.encoded(export.sqlite_row(dict(reversed(dict(row).items())))),
            expected,
        )
        self.assertEqual(
            export.digest(actual), hashlib.sha256(expected.encode()).hexdigest()
        )
        self.assertEqual(
            bytes.fromhex(json.loads(actual)["blob"]["$blob"]), b"\x00\xff\x80"
        )

    def test_hermes_raw_rows_tool_edits_and_absence_retention(self):
        home = self.root / "hermes"
        home.mkdir()
        native = sqlite3.connect(home / "state.db")
        self.addCleanup(native.close)
        native.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE sessions (id TEXT,source TEXT,title TEXT,started_at REAL,ended_at REAL,parent_session_id TEXT,system_prompt TEXT);
            CREATE TABLE messages (id INTEGER,session_id TEXT,role TEXT,content TEXT,timestamp REAL,active INTEGER,compacted INTEGER,tool_calls TEXT);
            INSERT INTO sessions VALUES ('same','cli','title',1,NULL,NULL,'system');
            INSERT INTO messages VALUES (1,'same','user','question',2,1,0,NULL);
            INSERT INTO messages VALUES (2,'same','tool','TOOL_PAYLOAD',3,1,0,'original');
        """)
        first = export.hermes_scan(home, {}, {})
        knowledge.ingest(self.db, first["records"])
        row = self.db.execute("SELECT * FROM documents").fetchone()
        self.assertNotIn("TOOL_PAYLOAD", row["markdown"])
        self.assertEqual(len(json.loads(row["raw_json"])["messages"]), 2)
        same = export.hermes_scan(
            home, first["current"], knowledge.hashes(self.db, "hermes")
        )
        self.assertEqual(same["records"], [])
        native.execute("UPDATE messages SET tool_calls='edited' WHERE id=2")
        native.commit()
        changed = export.hermes_scan(
            home, first["current"], knowledge.hashes(self.db, "hermes")
        )
        self.assertEqual(changed["changed"], {})
        self.assertEqual(len(changed["records"]), 1)
        knowledge.ingest(self.db, changed["records"])
        native.execute("UPDATE sessions SET system_prompt=?", (b"\xfe\x00",))
        native.execute(
            "UPDATE messages SET tool_calls=? WHERE id=2", (b"\x00\xff\x80",)
        )
        native.commit()
        binary = export.hermes_scan(
            home, changed["current"], knowledge.hashes(self.db, "hermes")
        )
        self.assertEqual(binary["changed"], {})
        record = binary["records"][0]
        self.assertEqual(record["markdown"], changed["records"][0]["markdown"])
        self.assertEqual(
            json.loads(record["raw_json"])["session"]["system_prompt"],
            {"$blob": "fe00"},
        )
        self.assertEqual(
            json.loads(record["raw_json"])["messages"][1]["tool_calls"],
            {"$blob": "00ff80"},
        )
        knowledge.ingest(self.db, binary["records"])
        self.assertEqual(
            export.hermes_scan(
                home, binary["current"], knowledge.hashes(self.db, "hermes")
            )["records"],
            [],
        )
        self.assertEqual(
            native.execute("SELECT system_prompt FROM sessions").fetchone()[0],
            b"\xfe\x00",
        )
        native.execute("DELETE FROM sessions")
        native.commit()
        knowledge.ingest(
            self.db,
            export.hermes_scan(home, {}, knowledge.hashes(self.db, "hermes"))[
                "records"
            ],
        )
        self.assertEqual(
            self.db.execute("SELECT count(*) FROM documents").fetchone()[0], 1
        )

    def test_single_file_snapshot_restore_integrity_fts_and_hashes(self):
        knowledge.ingest(
            self.db,
            [
                self.row(source)
                for source in ["amp", "pi", "hermes", "notes", "chatgpt", "claude"]
            ],
        )
        snapshot = self.root / "backups/snapshot.sqlite3"
        expected = knowledge.backup(self.path, snapshot)
        restored = self.root / "restored.sqlite3"
        shutil.copyfile(snapshot, restored)
        connection = sqlite3.connect(restored)
        connection.row_factory = sqlite3.Row
        self.addCleanup(connection.close)
        self.assertEqual(knowledge.verify(connection), expected)
        self.assertEqual(self.matches("orchard", connection), 6)
        self.assertFalse(snapshot.with_name(snapshot.name + "-wal").exists())
        self.assertEqual(
            connection.execute("PRAGMA journal_mode").fetchone()[0], "delete"
        )
        self.assertEqual(
            [
                tuple(r)
                for r in connection.execute(
                    "SELECT source,content_hash,raw_hash FROM documents ORDER BY source"
                )
            ],
            [
                tuple(r)
                for r in self.db.execute(
                    "SELECT source,content_hash,raw_hash FROM documents ORDER BY source"
                )
            ],
        )

    def test_retention_boundary_and_unrelated_files(self):
        directory = self.root / "backups"
        now = datetime.datetime(2026, 9, 9, 12, tzinfo=datetime.timezone.utc)
        expired = "20260902T115959.999999Z.sqlite3"
        kept = [
            "20260902T120000.000000Z.sqlite3",
            "20260902T120000.000001Z.sqlite3",
            "initial-verified.sqlite3",
            "archive.sqlite3",
            "unrelated.sqlite3",
            "20260230T120000.000000Z.sqlite3",
        ]
        for name in [expired, *kept]:
            knowledge.backup(self.path, directory / name)
        missing = directory / "20260901T000000.000000Z.sqlite3"
        missing.write_bytes(b"no checksum")
        corrupt = directory / "20260901T000001.000000Z.sqlite3"
        knowledge.backup(self.path, corrupt)
        corrupt.write_bytes(b"checksum mismatch")
        external = self.root / "external.sqlite3"
        knowledge.backup(self.path, external)
        link = directory / "20260901T000002.000000Z.sqlite3"
        link.symlink_to(external)
        link.with_suffix(".sha256").write_bytes(
            external.with_suffix(".sha256").read_bytes().split()[0]
            + b"  "
            + link.name.encode()
            + b"\n"
        )
        linked_checksum = directory / "20260901T000004.000000Z.sqlite3"
        knowledge.backup(self.path, linked_checksum)
        checksum = linked_checksum.with_suffix(".sha256")
        checksum.rename(self.root / "external-checksum")
        checksum.symlink_to(self.root / "external-checksum")
        orphan = directory / "20260901T000003.000000Z.sha256"
        orphan.write_bytes(b"orphan")
        nested = directory / "nested"
        knowledge.backup(self.path, nested / expired)
        self.assertEqual(knowledge.prune_backups(directory, now), 1)
        self.assertFalse((directory / expired).exists())
        self.assertFalse((directory / expired).with_suffix(".sha256").exists())
        for name in kept:
            self.assertTrue((directory / name).exists())
            self.assertTrue((directory / name).with_suffix(".sha256").exists())
        self.assertTrue(
            all(
                p.exists()
                for p in (
                    self.path,
                    missing,
                    corrupt,
                    link,
                    linked_checksum,
                    checksum,
                    external,
                    orphan,
                    nested / expired,
                )
            )
        )

    def test_retention_only_after_successful_default_backup(self):
        with (
            patch.object(knowledge, "DEFAULT_DB", self.path),
            patch("sys.argv", ["knowledge-import", "backup"]),
            patch.object(knowledge, "prune_backups", return_value=0) as prune,
            patch("sys.stdout", new_callable=io.StringIO),
            patch("sys.stderr", new_callable=io.StringIO),
        ):
            with patch.object(
                knowledge, "verify", side_effect=ValueError("failed verification")
            ):
                with self.assertRaises(SystemExit):
                    knowledge.main()
            prune.assert_not_called()
            with patch.object(
                knowledge.export,
                "atomic",
                side_effect=OSError("failed sidecar publication"),
            ):
                with self.assertRaises(SystemExit):
                    knowledge.main()
            prune.assert_not_called()
            knowledge.main()
            prune.assert_called_once()
            prune.reset_mock()
            with patch(
                "sys.argv",
                [
                    "knowledge-import",
                    "backup",
                    "--destination",
                    str(self.root / "manual.sqlite3"),
                ],
            ):
                knowledge.main()
            prune.assert_not_called()
            with (
                patch(
                    "sys.argv",
                    [
                        "knowledge-import",
                        "backup",
                        "--database",
                        str(self.root / "other.sqlite3"),
                    ],
                ),
                patch.object(knowledge, "backup", return_value={}),
            ):
                knowledge.main()
            prune.assert_not_called()

    def test_failed_backup_does_not_publish_partial_snapshot(self):
        destination = self.root / "backup.sqlite3"
        with patch.object(knowledge, "verify", side_effect=ValueError("synthetic")):
            with self.assertRaises(ValueError):
                knowledge.backup(self.path, destination)
        self.assertFalse(destination.exists())
        self.assertEqual(list(self.root.glob(".snapshot-*")), [])


if __name__ == "__main__":
    unittest.main()
