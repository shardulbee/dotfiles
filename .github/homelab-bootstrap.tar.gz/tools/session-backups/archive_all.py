"""Archive every conversation returned by Amp CLI, with bounded parallelism."""

import argparse
import datetime
import hashlib
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import archive


def discover(amp, evidence, pass_number):
    found = set()
    offset = 0
    while True:
        raw = archive.cli(
            amp,
            "threads",
            "list",
            "--json",
            "--include-archived",
            "--limit",
            "500",
            "--offset",
            str(offset),
        )
        archive.write(evidence / f"list-{pass_number}-{offset}.json", raw)
        rows = json.loads(raw)
        if not isinstance(rows, list):
            raise RuntimeError("Unexpected list contract")  # noqa: TRY004 -- External CLI contract failure, not a caller type error.
        ids = {row["id"] for row in rows}
        if not all(archive.THREAD_ID.fullmatch(thread) for thread in ids):
            raise RuntimeError("Unexpected thread ID")
        if not rows:
            return found
        if ids <= found:
            raise RuntimeError("Pagination made no progress")
        found.update(ids)
        print(f"List pass {pass_number}: {len(found)} unique threads", flush=True)
        # Advance by requested page size, not result length. Extra pinned rows
        # must not cause ordinary rows to be skipped. Stop only on an empty page.
        offset += 500


def run(root, amp, workers):
    archive.private_dir(root)
    runs = root / "runs"
    archive.private_dir(runs)
    evidence = runs / datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y%m%dT%H%M%S.%fZ"
    )
    archive.private_dir(evidence)
    version = archive.cli(amp, "--version").decode().strip()
    found = set()
    previous = None
    # Two identical inventories establish a stable listing, not a transactional
    # server snapshot. Retain the union if threads disappear during discovery.
    for pass_number in range(1, 5):
        current = discover(amp, evidence, pass_number)
        found.update(current)
        if current == previous:
            break
        previous = current
    else:
        raise RuntimeError("Thread listing did not stabilize; raw pages retained")
    archive.write(evidence / "manifest.json", archive.encoded(sorted(found)))
    print(
        f"Stable inventory: {len(found)} threads. Exporting with {workers} workers.",
        flush=True,
    )
    results = {}
    pending = found
    for attempt in range(2):
        failed = set()
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(archive.capture, root, amp, thread, version, False): thread
                for thread in sorted(pending)
            }
            for future in as_completed(futures):
                thread = futures[future]
                try:
                    snapshot = future.result()
                    results[thread] = snapshot
                    archive.write(
                        evidence / f"{thread}.json",
                        archive.encoded({"snapshot": snapshot}),
                    )
                except Exception:  # noqa: BLE001 -- Worker errors may contain private export data.
                    # Never print private CLI output or exception payloads.
                    failed.add(thread)
                done = len(results) + len(failed)
                if done % 25 == 0 or done == len(found):
                    print(
                        f"Exported {len(results)}/{len(found)}; failures this pass {len(failed)}",
                        flush=True,
                    )
        pending = failed
        if not pending:
            break
        if attempt == 0:
            print(f"Retrying {len(pending)} failed read-only exports once", flush=True)
    for thread, snapshot in results.items():
        directory = root / thread / snapshot
        meta = json.loads((directory / "metadata.json").read_bytes())
        for name, digest in meta["sha256"].items():
            if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
                raise RuntimeError("Checksum verification failed")
    indexed = archive.rebuild(root)
    report = {
        "discovered": len(found),
        "exported": len(results),
        "failed": sorted(pending),
        "indexed": indexed,
        "verifiedChecksums": True,
        "attachments": "not collected",
        "scope": "All threads returned by two stable CLI listings, including archived",
    }
    archive.write(evidence / "report.json", archive.encoded(report))
    print(
        f"Done: {len(results)}/{len(found)} exported, {indexed} indexed, {len(pending)} failed.",
        flush=True,
    )
    print(f"Private run records: {evidence}", flush=True)
    return 1 if pending else 0


if __name__ == "__main__":
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=archive.DEFAULT_ROOT)
    parser.add_argument("--amp", default=str(Path.home() / ".amp/bin/amp"))
    parser.add_argument("--workers", type=int, choices=range(1, 9), default=6)
    args = parser.parse_args()
    try:
        raise SystemExit(run(args.root, args.amp, args.workers))
    except (RuntimeError, ValueError, OSError):
        parser.exit(
            1,
            "Full export stopped. Prior snapshots and private run records retained.\n",
        )
