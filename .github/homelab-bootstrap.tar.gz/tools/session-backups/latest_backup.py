"""Replace one scheduled backup only after a complete, verified capture."""

import argparse
import contextlib
import fcntl
import os
import shutil
import tempfile
from pathlib import Path

import archive
import archive_all
import pi_backup
import verify

DEFAULT_ROOT = Path.home() / ".local/state/session-backups"
SOURCES = ("amp", *pi_backup.HOSTS)


def run(root, source, amp):
    if source not in SOURCES:
        raise ValueError("Unsupported source")
    archive.private_dir(root)
    base = root / source
    archive.private_dir(base)
    with (base / ".lock").open("a") as lock:
        os.chmod(base / ".lock", 0o600)
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        stage = Path(tempfile.mkdtemp(prefix="generation-", dir=base))
        pointer = base / ".latest"
        try:
            with (stage / "run.log").open("w") as log, contextlib.redirect_stdout(log):
                if source == "amp":
                    data = stage / "archive"
                    if archive_all.run(data, amp, 8):
                        raise RuntimeError("Incomplete Amp export")
                    verify.verify_amp(data)
                else:
                    data = stage / "pi"
                    pi_backup.capture(data, source)
                    verify.verify_pi(data, (source,))
                log.flush()
                os.fsync(log.fileno())
            # rsync does not fsync copied files by default. Make the new tree
            # durable before publishing it and deleting the old generation.
            for path in sorted(stage.rglob("*"), reverse=True):
                if path.is_symlink():
                    continue
                if path.is_dir():
                    archive.sync_dir(path)
                elif path.is_file():
                    with path.open("rb") as stream:
                        os.fsync(stream.fileno())
            archive.sync_dir(stage)
            pointer.unlink(missing_ok=True)
            pointer.symlink_to(stage.name)
            os.replace(pointer, base / "latest")
            archive.sync_dir(base)
        finally:
            # A failed capture never changes latest. Also safe if publication
            # succeeded but the subsequent directory fsync failed.
            published = (base / "latest").is_symlink() and os.readlink(
                base / "latest"
            ) == stage.name
            if not published:
                shutil.rmtree(stage)
            pointer.unlink(missing_ok=True)
        # Only this dedicated root is pruned, never the historical archives.
        # This also removes abandoned generations from interrupted runs, but
        # only after a new complete backup has been published.
        for old in base.glob("generation-*"):
            if old != stage and old.is_dir() and not old.is_symlink():
                shutil.rmtree(old)
        archive.sync_dir(base)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", choices=SOURCES)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--amp", default=str(Path.home() / ".amp/bin/amp"))
    args = parser.parse_args()
    try:
        run(args.root.resolve(), args.source, args.amp)
    except Exception:  # noqa: BLE001 -- Do not expose private subprocess or file errors in the journal.
        parser.exit(1, "Backup failed; last successful backup retained.\n")
    print(args.source, "latest backup verified and replaced")


if __name__ == "__main__":
    main()
