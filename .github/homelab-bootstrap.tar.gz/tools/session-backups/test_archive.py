import hashlib
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import archive
import archive_all


class ArchiveTests(unittest.TestCase):
    def test_snapshot_retention_failure_and_rebuild(self):
        thread = "T-00000000-0000-0000-0000-000000000000"
        raw = ('{ "id": "' + thread + '", "messages": [] }\n').encode()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "archive"
            with patch.object(
                archive, "cli", side_effect=[raw, b"# unique_keyword\n", b"test"]
            ):
                first = archive.capture(root, "amp", thread)
            with patch.object(
                archive, "cli", side_effect=[raw, b"# changed\n", b"test"]
            ):
                second = archive.capture(root, "amp", thread)
            original = root / thread / first
            self.assertEqual((original / "thread.json").read_bytes(), raw)
            meta = json.loads((original / "metadata.json").read_bytes())
            self.assertEqual(
                meta["sha256"]["thread.json"], hashlib.sha256(raw).hexdigest()
            )
            for responses in [[raw, RuntimeError("missing remotely")], [b"not json"]]:
                with (
                    patch.object(archive, "cli", side_effect=responses),
                    self.assertRaises(RuntimeError),
                ):
                    archive.capture(root, "amp", thread)
                self.assertEqual((root / thread / "latest").read_text().strip(), second)
                self.assertTrue(original.is_dir())
            with (
                patch.object(
                    archive, "cli", side_effect=[raw, b"# interrupted\n", b"test"]
                ),
                patch.object(archive, "write", side_effect=OSError("disk full")),
                self.assertRaises(OSError),
            ):
                archive.capture(root, "amp", thread)
            self.assertEqual((root / thread / "latest").read_text().strip(), second)
            self.assertEqual(archive.rebuild(root), 1)
            (root / "search.sqlite3").unlink()
            self.assertEqual(archive.rebuild(root), 1)
            with sqlite3.connect(root / "search.sqlite3") as db:
                self.assertEqual(
                    db.execute(
                        "SELECT id FROM threads WHERE threads MATCH 'changed'"
                    ).fetchall(),
                    [(thread,)],
                )
            self.assertFalse(list(root.rglob(".pending-*")))
            for path in root.rglob("*"):
                self.assertEqual(path.stat().st_mode & 0o077, 0)

    def test_reference_inventory(self):
        refs = archive.references(
            {
                "image": {"sourcePath": "attachment://example"},
                "text": "file:///tmp/not-a-backup https://example.com/file.png",
            }
        )
        self.assertTrue(any(x["value"] == "attachment://example" for x in refs))
        self.assertTrue(any(x["value"] == "file:///tmp/not-a-backup" for x in refs))

    def test_no_unbounded_or_path_ids(self):
        with self.assertRaises(ValueError):
            archive.capture(Path("unused"), "amp", "../../bad")

    def test_bulk_skips_references_and_version_subprocess(self):
        thread = "T-00000000-0000-0000-0000-000000000000"
        raw = archive.encoded({"id": thread, "messages": []})
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with (
                patch.object(archive, "cli", side_effect=[raw, b"# thread"]),
                patch.object(
                    archive, "references", side_effect=AssertionError("not requested")
                ),
            ):
                snapshot = archive.capture(root, "amp", thread, "test", False)
            self.assertFalse((root / thread / snapshot / "references.json").exists())

    def test_bulk_discovery_deduplicates_and_waits_for_empty_page(self):
        first = "T-00000000-0000-0000-0000-000000000000"
        second = "T-00000000-0000-0000-0000-000000000001"
        pages = [[{"id": first}], [{"id": first}, {"id": second}], []]
        with tempfile.TemporaryDirectory() as temporary:
            with patch.object(
                archive, "cli", side_effect=map(archive.encoded, pages)
            ) as cli:
                self.assertEqual(
                    archive_all.discover("amp", Path(temporary), 1), {first, second}
                )
            self.assertEqual(
                [call.args[-1] for call in cli.call_args_list], ["0", "500", "1000"]
            )


if __name__ == "__main__":
    os.umask(0o077)
    unittest.main()
