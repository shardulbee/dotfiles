{
  lib,
  stdenvNoCC,
  python3,
  rsync,
  openssh,
  makeWrapper,
}:

stdenvNoCC.mkDerivation {
  pname = "session-backups";
  version = "1";
  # Never copy this directory wholesale: local backup/probe data is private.
  src = lib.fileset.toSource {
    root = ./.;
    fileset = lib.fileset.unions [
      ./archive.py
      ./archive_all.py
      ./pi_backup.py
      ./verify.py
      ./latest_backup.py
      ./session_export.py
      ./amp_refresh.py
      ./knowledge.py
      ./test_archive.py
      ./test_pi_backup.py
      ./test_latest_backup.py
      ./test_session_export.py
      ./test_amp_refresh.py
      ./test_knowledge.py
    ];
  };
  nativeBuildInputs = [ makeWrapper ];
  nativeCheckInputs = [
    python3
    rsync
  ];
  doCheck = true;
  checkPhase = ''
    runHook preCheck
    umask 077
    ${python3}/bin/python3 -B -m unittest discover -v
    runHook postCheck
  '';
  installPhase = ''
    runHook preInstall
    mkdir -p "$out/lib/session-backups" "$out/bin"
    cp archive.py archive_all.py pi_backup.py verify.py latest_backup.py session_export.py amp_refresh.py knowledge.py "$out/lib/session-backups/"
    for pair in amp-archive:archive.py amp-archive-all:archive_all.py pi-backup:pi_backup.py session-backups-verify:verify.py session-backup-latest:latest_backup.py agent-session-export:session_export.py knowledge-import:knowledge.py; do
      name="''${pair%%:*}"
      script="''${pair#*:}"
      makeWrapper ${python3}/bin/python3 "$out/bin/$name" \
        --add-flags "-B $out/lib/session-backups/$script" \
        --prefix PATH : ${
          lib.makeBinPath [
            rsync
            openssh
          ]
        }
    done
    runHook postInstall
  '';
  meta.description = "Verified Amp and Pi session backups";
}
