"""Read-only checks of latest private snapshots. Prints counts, never contents."""

import argparse
import hashlib
import json
import re
from pathlib import Path

import archive
import pi_backup


def private_tree(root):
    if not root.is_dir() or root.is_symlink():
        raise ValueError("Missing private backup directory")
    for path in [root, *root.rglob("*")]:
        if not path.is_symlink() and path.stat().st_mode & 0o077:
            raise ValueError("Non-private permissions")


def verify_amp(root):
    private_tree(root)
    count = 0
    for thread, snapshot in archive.latest_files(root):
        meta = json.loads((snapshot / "metadata.json").read_bytes())
        if meta["threadId"] != thread or meta["schemaVersion"] != 1:
            raise ValueError("Invalid Amp metadata")
        for name in ("thread.json", "thread.md"):
            with (snapshot / name).open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            if digest != meta["sha256"][name]:
                raise ValueError("Amp checksum mismatch")
        count += 1
    if not count:
        raise ValueError("No Amp snapshots found")
    return count


def verify_pi(root, hosts=pi_backup.HOSTS):
    private_tree(root)
    counts = {}
    for host in hosts:
        base = root / host
        name = json.loads((base / "latest.json").read_bytes())["snapshot"]
        if not re.fullmatch(r"\d{8}T\d{6}\.\d{6}Z", name):
            raise ValueError("Invalid Pi snapshot pointer")
        snapshot = base / name
        if not (snapshot / "sessions").is_dir():
            raise ValueError("Missing sessions directory")
        entries = pi_backup.manifest(snapshot / "sessions")
        if entries != json.loads((snapshot / "manifest.json").read_bytes()):
            raise ValueError("Pi manifest mismatch")
        meta = json.loads((snapshot / "metadata.json").read_bytes())
        count = sum(e["type"] == "file" for e in entries)
        if (
            meta["host"] != host
            or meta["source"] != "~/.pi/agent/sessions/"
            or meta["files"] != count
            or meta["bytes"] != sum(e.get("bytes", 0) for e in entries)
            or (snapshot / "verification.log").read_bytes()
        ):
            raise ValueError("Pi metadata or verification mismatch")
        counts[host] = count
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=("amp", "pi"))
    parser.add_argument("--root", type=Path)
    args = parser.parse_args()
    try:
        if args.kind == "amp":
            print(
                "Verified latest Amp snapshots:",
                verify_amp(args.root or archive.DEFAULT_ROOT),
            )
        else:
            for host, count in verify_pi(args.root or pi_backup.DEFAULT_ROOT).items():
                print(host, "verified files:", count)
    except (OSError, ValueError, KeyError, TypeError, RuntimeError):
        parser.exit(
            1, "Verification failed. Inspect backup files privately; nothing changed.\n"
        )


if __name__ == "__main__":
    main()
