"""Private SQLite session archive and refreshable Obsidian note snapshots."""

import argparse
import datetime
import fcntl
import hashlib
import json
import os
import re
import sqlite3
import tempfile
from contextlib import ExitStack
from pathlib import Path

import archive
import session_export as export

DEFAULT_DB = Path("/var/lib/knowledge/archive.sqlite3")
EXPORT_FOLDERS = {"ChatGPT Exports": "chatgpt", "Claude Exports": "claude"}


def connect(path):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    db = sqlite3.connect(path, timeout=60)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
            source TEXT NOT NULL, source_id TEXT NOT NULL,
            title TEXT NOT NULL, source_path TEXT NOT NULL,
            source_updated_at TEXT, markdown TEXT NOT NULL,
            raw_json TEXT, raw_format TEXT,
            content_hash TEXT NOT NULL, raw_hash TEXT,
            indexed_at TEXT NOT NULL,
            PRIMARY KEY (source, source_id)
        );
        CREATE INDEX IF NOT EXISTS documents_source_hash
            ON documents(source,source_id,raw_hash);
        CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(
            title, markdown, content='documents', content_rowid='rowid'
        );
        CREATE TRIGGER IF NOT EXISTS documents_insert AFTER INSERT ON documents BEGIN
            INSERT INTO documents_fts(rowid,title,markdown) VALUES(new.rowid,new.title,new.markdown);
        END;
        CREATE TRIGGER IF NOT EXISTS documents_delete AFTER DELETE ON documents BEGIN
            INSERT INTO documents_fts(documents_fts,rowid,title,markdown)
                VALUES('delete',old.rowid,old.title,old.markdown);
        END;
        CREATE TRIGGER IF NOT EXISTS documents_update AFTER UPDATE ON documents
        WHEN old.title IS NOT new.title OR old.markdown IS NOT new.markdown BEGIN
            INSERT INTO documents_fts(documents_fts,rowid,title,markdown)
                VALUES('delete',old.rowid,old.title,old.markdown);
            INSERT INTO documents_fts(rowid,title,markdown) VALUES(new.rowid,new.title,new.markdown);
        END;
    """)
    return db


def hashes(db, source):
    return dict(
        db.execute("SELECT source_id,raw_hash FROM documents WHERE source=?", (source,))
    )


def ingest(db, records, complete_notes=False):
    """One source transaction; incomplete iterators never authorize deletion."""
    seen, changed = set(), 0
    with db:
        for row in records:
            if export.digest(row["markdown"]) != row["content_hash"]:
                raise ValueError("Markdown checksum mismatch")
            raw = row["raw_json"]
            if (export.digest(raw) if raw is not None else None) != row["raw_hash"]:
                raise ValueError("Raw checksum mismatch")
            if row["source"] == "notes":
                seen.add(row["source_id"])
            changed += db.execute(
                """
                INSERT INTO documents VALUES (
                    :source,:source_id,:title,:source_path,:source_updated_at,
                    :markdown,:raw_json,:raw_format,:content_hash,:raw_hash,
                    strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                ON CONFLICT(source,source_id) DO UPDATE SET
                    title=excluded.title, source_path=excluded.source_path,
                    source_updated_at=excluded.source_updated_at,
                    markdown=excluded.markdown, raw_json=excluded.raw_json,
                    raw_format=excluded.raw_format, content_hash=excluded.content_hash,
                    raw_hash=excluded.raw_hash, indexed_at=excluded.indexed_at
                WHERE documents.title IS NOT excluded.title
                    OR documents.source_path IS NOT excluded.source_path
                    OR documents.content_hash IS NOT excluded.content_hash
                    OR documents.raw_hash IS NOT excluded.raw_hash
                    OR documents.raw_format IS NOT excluded.raw_format
            """,
                row,
            ).rowcount
        deleted = 0
        if complete_notes:
            for (identity,) in db.execute(
                "SELECT source_id FROM documents WHERE source='notes'"
            ).fetchall():
                if identity not in seen:
                    deleted += db.execute(
                        "DELETE FROM documents WHERE source='notes' AND source_id=?",
                        (identity,),
                    ).rowcount
    return {"upserted": changed, "notes_deleted": deleted}


def metadata(body):
    """Read only the JSON-valued frontmatter emitted by session_export."""
    header, _ = body.removeprefix("---\n").split("\n---\n", 1)
    return {
        key: json.loads(value)
        for key, value in (line.split(": ", 1) for line in header.splitlines())
    }


def amp_record(path):
    raw = path.read_bytes().decode("utf-8")
    if len(path.stem) == 64 and export.digest(raw) != path.stem:
        raise ValueError("Content-addressed Amp checksum mismatch")
    data = json.loads(raw)
    if not archive.THREAD_ID.fullmatch(data["id"]) or not isinstance(
        data["messages"], list
    ):
        raise ValueError("Invalid Amp archive")
    body = export.amp_body(data, {"provenance": str(path)})
    return export.archive_record(["amp", data["id"]], metadata(body), body, raw, "json")


def amp_records(state, only=None):
    if only is not None and not only:
        return
    candidates = {}
    for directory in sorted((state / "agent-session-raw/amp").glob("T-*")):
        if only is None or directory.name in only:
            candidates.setdefault(directory.name, []).extend(directory.glob("*.json"))
    for base in [
        state / "session-backups/amp/latest/archive",
        state / "amp-archive-experiment/archive",
    ]:
        for identity, snapshot in archive.latest_files(base):
            if only is None or identity in only:
                candidates.setdefault(identity, []).append(snapshot / "thread.json")
    if only is None and not candidates:
        raise ValueError("No Amp archives available")
    for identity, paths in candidates.items():
        if not paths:
            continue
        selected = None
        for path in paths:
            row = amp_record(path)
            if row["source_id"] != identity:
                raise ValueError("Amp archive identity mismatch")
            order = (
                datetime.datetime.fromisoformat(row["source_updated_at"]).timestamp(),
                path.stat().st_mtime_ns,
                str(path),
            )
            if selected is None or order > selected[0]:
                selected = order, row
        yield selected[1]


def pi_record(path, context):
    body = export.pi_document(path, context)
    host, relative, _ = context
    return export.archive_record(
        ["pi", host, relative],
        {**metadata(body), "updated": path.stat().st_mtime},
        body,
        path.read_bytes().decode("utf-8"),
        "jsonl",
    )


def note_records(vault):
    if not vault.is_dir() or vault.is_symlink():
        raise ValueError("Vault unavailable")

    def fail(error):
        raise error

    for directory, dirs, files in os.walk(vault, followlinks=False, onerror=fail):
        base = Path(directory)
        dirs[:] = [
            name
            for name in dirs
            if not name.startswith(".")
            and not (base / name).is_symlink()
            and not (base == vault and name == "Agent Sessions")
        ]
        for name in sorted(files):
            path = base / name
            if name.startswith(".") or path.suffix != ".md" or path.is_symlink():
                continue
            body = path.read_bytes().decode("utf-8")
            relative = path.relative_to(vault)
            source = EXPORT_FOLDERS.get(relative.parts[0], "notes")
            identity = (
                str(relative) if source == "notes" else str(Path(*relative.parts[1:]))
            )
            title = next(
                (
                    line[2:].strip()
                    for line in body.splitlines()
                    if line.startswith("# ")
                ),
                path.stem,
            )
            updated = datetime.datetime.fromtimestamp(
                path.stat().st_mtime, datetime.timezone.utc
            ).isoformat()
            yield export.archive_record(
                [source, identity],
                {"title": title, "provenance": str(path), "updated": updated},
                body,
                None,
                None,
            )


def verify(db):
    if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
        raise ValueError("SQLite integrity check failed")
    db.execute(
        "INSERT INTO documents_fts(documents_fts,rank) VALUES('integrity-check',1)"
    )
    counts = {}
    for row in db.execute("SELECT * FROM documents ORDER BY source,source_id"):
        if export.digest(row["markdown"]) != row["content_hash"]:
            raise ValueError("Stored Markdown checksum mismatch")
        raw = row["raw_json"]
        if (export.digest(raw) if raw is not None else None) != row["raw_hash"]:
            raise ValueError("Stored raw checksum mismatch")
        info = counts.setdefault(
            row["source"], {"count": 0, "markdown_bytes": 0, "raw_bytes": 0}
        )
        info["count"] += 1
        info["markdown_bytes"] += len(row["markdown"].encode())
        info["raw_bytes"] += len(raw.encode()) if raw is not None else 0
    return counts


def backup(path, destination):
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if destination.exists():
        raise FileExistsError("Backup destination exists")
    fd, name = tempfile.mkstemp(prefix=".snapshot-", dir=destination.parent)
    os.close(fd)
    stage = Path(name)
    try:
        source = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        target = sqlite3.connect(stage)
        try:
            source.backup(target)
            target.row_factory = sqlite3.Row
            target.execute("PRAGMA journal_mode=DELETE")
            counts = verify(target)
            target.commit()
        finally:
            target.close()
            source.close()
        with stage.open("rb") as stream:
            os.fsync(stream.fileno())
        os.link(stage, destination)
        archive.sync_dir(destination.parent)
        with destination.open("rb") as stream:
            checksum = hashlib.file_digest(stream, "sha256").hexdigest()
        export.atomic(
            destination.with_suffix(".sha256"),
            checksum + "  " + destination.name + "\n",
        )
        return counts
    finally:
        stage.unlink(missing_ok=True)


def prune_backups(directory, now):
    cutoff = now - datetime.timedelta(days=7)
    removed = 0
    for path in directory.iterdir():
        if not re.fullmatch(r"[0-9]{8}T[0-9]{6}\.[0-9]{6}Z\.sqlite3", path.name):
            continue
        try:
            captured = datetime.datetime.strptime(
                path.stem, "%Y%m%dT%H%M%S.%fZ"
            ).replace(tzinfo=datetime.timezone.utc)
        except ValueError:
            continue
        checksum = path.with_suffix(".sha256")
        if captured >= cutoff or any(
            p.is_symlink() or not p.is_file() for p in (path, checksum)
        ):
            continue
        with path.open("rb") as stream:
            expected = (
                hashlib.file_digest(stream, "sha256").hexdigest()
                + "  "
                + path.name
                + "\n"
            )
        if checksum.read_bytes() != expected.encode():
            continue
        path.unlink()
        checksum.unlink()
        removed += 1
    if removed:
        archive.sync_dir(directory)
    return removed


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "source", choices=["amp", "pi", "hermes", "notes", "verify", "backup"]
    )
    parser.add_argument("--database", type=Path, default=DEFAULT_DB)
    parser.add_argument("--state", type=Path, default=Path.home() / ".local/state")
    parser.add_argument("--vault", type=Path, default=Path("/var/lib/obsidian/vault"))
    parser.add_argument("--hermes-host", default="hermes@10.60.0.2")
    parser.add_argument("--destination", type=Path)
    parser.add_argument(
        "--export-state", type=Path, default=Path("/var/lib/agent-sessions")
    )
    args = parser.parse_args()
    locks = ExitStack()
    try:
        if args.source in ("amp", "pi", "hermes"):
            directory = args.export_state / args.source
            directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            lock = locks.enter_context((directory / ".lock").open("a"))
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.source == "backup":
            destination = args.destination or args.database.parent / "backups" / (
                datetime.datetime.now(datetime.timezone.utc).strftime(
                    "%Y%m%dT%H%M%S.%fZ"
                )
                + ".sqlite3"
            )
            result = backup(args.database, destination)
            if args.destination is None and args.database == DEFAULT_DB:
                result["snapshots_pruned"] = prune_backups(
                    destination.parent, datetime.datetime.now(datetime.timezone.utc)
                )
        else:
            if args.source == "verify" and not args.database.is_file():
                raise FileNotFoundError("Knowledge archive missing")
            db = connect(args.database)
            try:
                if args.source == "notes":
                    with (args.vault.parent / "state/vault.lock").open("r") as lock:
                        fcntl.flock(lock, fcntl.LOCK_SH)
                        result = ingest(
                            db, note_records(args.vault), complete_notes=True
                        )
                elif args.source == "amp":
                    result = ingest(db, amp_records(args.state))
                elif args.source == "pi":
                    result = ingest(
                        db,
                        (
                            pi_record(p, c)
                            for _, p, c in export.pi_documents(args.state)
                        ),
                    )
                elif args.source == "hermes":
                    result = ingest(
                        db,
                        export.remote_hermes(
                            args.hermes_host, {}, hashes(db, "hermes")
                        )["records"],
                    )
                else:
                    result = verify(db)
            finally:
                db.close()
    except Exception as error:
        parser.exit(
            1,
            f"Knowledge {args.source} failed ({type(error).__name__}, errno={getattr(error, 'errno', None)}); stored records retained.\n",
        )
    finally:
        locks.close()
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
