"""Manual Pi session snapshots from turbogadget and sharchy over SSH."""

import argparse
import datetime
import hashlib
import os
import subprocess
import tempfile
from pathlib import Path

from archive import encoded, private_dir, sync_dir, write

DEFAULT_ROOT = Path.home() / ".local/state/pi-backups"
HOSTS = ("turbogadget", "sharchy")


def manifest(sessions):
    entries = []
    for path in sorted(sessions.rglob("*")):
        name = str(path.relative_to(sessions))
        if path.is_symlink():
            entries.append(
                {"path": name, "type": "symlink", "target": os.readlink(path)}
            )
        elif path.is_file():
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            entries.append(
                {
                    "path": name,
                    "type": "file",
                    "bytes": path.stat().st_size,
                    "sha256": digest,
                }
            )
    return entries


def capture(root, host):
    if host not in HOSTS:
        raise ValueError("Unsupported source host")
    private_dir(root)
    base = root / host
    private_dir(base)
    # An interrupted transfer needs private inspection, not automatic deletion.
    if (base / "in-progress").exists():
        raise RuntimeError(
            "Incomplete snapshot retained; inspect in-progress privately"
        )
    stage = Path(tempfile.mkdtemp(prefix=".pending-", dir=base))
    write(base / "in-progress", (str(stage) + "\n").encode())
    for verify in (False, True):
        command = [
            "rsync",
            "-anrc" if verify else "-a",
            "--no-owner",
            "--no-group",
            "--chmod=Du=rwx,Dgo=,Fu=rw,Fgo=",
        ]
        if verify:
            # Dry-run deletion detection only: catch files removed mid-copy.
            command += ["--delete", "--out-format=%i"]
        command += [
            "-e",
            "ssh -o BatchMode=yes -o StrictHostKeyChecking=yes",
            f"{host}:.pi/agent/sessions/",
            str(stage / "sessions") + "/",
        ]
        log = stage / ("verification.log" if verify else "transfer.log")
        with log.open("xb") as stream:
            os.chmod(log, 0o600)
            subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
        if verify and log.stat().st_size:
            raise RuntimeError(
                "Source changed or checksum verification reported differences"
            )
    entries = manifest(stage / "sessions")
    now = datetime.datetime.now(datetime.timezone.utc)
    write(stage / "manifest.json", encoded(entries))
    write(
        stage / "metadata.json",
        encoded(
            {
                "host": host,
                "source": "~/.pi/agent/sessions/",
                "completedAt": now.isoformat(),
                "files": sum(e["type"] == "file" for e in entries),
                "bytes": sum(e.get("bytes", 0) for e in entries),
                "verification": "rsync read-only checksum comparison returned no differences",
                "consistency": "Live directory copy, not a transactional filesystem snapshot; later source changes are not included",
            }
        ),
    )
    sync_dir(stage)
    destination = base / now.strftime("%Y%m%dT%H%M%S.%fZ")
    os.rename(stage, destination)
    sync_dir(base)
    pointer = base / ".latest"
    write(pointer, encoded({"snapshot": destination.name}))
    os.replace(pointer, base / "latest.json")
    (base / "in-progress").unlink()
    sync_dir(base)
    return destination


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("hosts", nargs="+", choices=HOSTS)
    args = parser.parse_args()
    try:
        for host in args.hosts:
            print(host, "snapshot:", capture(args.root.resolve(), host))
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError):
        parser.exit(
            1,
            "Pi backup failed. Historical and incomplete snapshots retained. Inspect private logs and in-progress pointer.\n",
        )


if __name__ == "__main__":
    main()
