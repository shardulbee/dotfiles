import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import amp_refresh as refresh
import archive
import session_export as export


def row(number, updated="2026-09-09T01:00:00Z"):
    return {
        "id": f"T-00000000-0000-0000-0000-{number:012d}",
        "updatedAt": updated,
    }


class RefreshTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)

    def test_pagination_deduplicates_without_order_or_short_page_cutoff(self):
        old = row(1)
        new = row(1, "2026-09-09T02:00:00Z")
        pages = [[new], [old, row(2)], []]
        with patch.object(
            archive, "cli", side_effect=[json.dumps(p).encode() for p in pages]
        ) as cli:
            rows, calls = refresh.listing("amp")
        self.assertEqual(calls, 3)
        self.assertEqual(rows, {new["id"]: new, row(2)["id"]: row(2)})
        self.assertEqual([c.args[-1] for c in cli.call_args_list], ["0", "100", "200"])
        with patch.object(archive, "cli", side_effect=[json.dumps([old]).encode()] * 2):
            with self.assertRaises(ValueError):
                refresh.listing("amp")

    def test_changed_only_budget_failures_and_two_scan_retirement(self):
        rows = {r["id"]: r for r in [row(1), row(2), row(3)]}
        with (
            patch.object(refresh, "listing", return_value=(rows, 3)),
            patch.object(refresh, "fetch", return_value="body") as fetch,
        ):
            first = refresh.scan(self.root, {}, "amp", budget=2)
            self.assertEqual(fetch.call_count, 2)
            self.assertEqual(first["poll"]["deferred"], 1)
            second = refresh.scan(self.root, first["current"], "amp", budget=2)
            self.assertEqual(fetch.call_count, 3)
            self.assertEqual(second["poll"]["export_cli_calls"], 1)
            third = refresh.scan(self.root, second["current"], "amp")
            self.assertEqual(third["changed"], {})
        known = third["current"]
        # Search update time, unlike list user-last-interacted time, is the marker.
        rows[row(1)["id"]] = row(1, "2026-09-09T03:00:00Z")
        rows[row(2)["id"]] = row(2, "2026-09-09T04:00:00Z")
        with (
            patch.object(refresh, "listing", return_value=(rows, 3)),
            patch.object(refresh, "fetch", side_effect=RuntimeError("offline")),
        ):
            failed = refresh.scan(self.root, known, "amp")
        self.assertEqual(failed["poll"]["failed"], 2)
        self.assertEqual(failed["current"], known)
        with patch.object(refresh, "listing", return_value=({}, 1)):
            missing = refresh.scan(self.root, known, "amp")
            self.assertEqual(len(missing["current"]), 3)
            removed = refresh.scan(self.root, missing["current"], "amp")
            self.assertEqual(removed["current"], {})

    def test_daily_snapshot_reconciles_edit_with_unchanged_marker(self):
        r = row(1)
        base = self.root / "session-backups/amp"
        snapshot = base / "latest/archive" / r["id"] / "20260909T000000.000000Z"
        snapshot.mkdir(parents=True)
        (base / ".lock").touch()
        (snapshot.parent / "latest").write_text(snapshot.name)
        path = snapshot / "thread.json"
        name = export.filename(["amp", r["id"]])

        def write(body):
            data = {
                "id": r["id"],
                "updatedAt": r["updatedAt"],
                "messages": [{"role": "user", "content": body}],
            }
            path.write_text(json.dumps(data))
            (snapshot / "metadata.json").write_text(
                json.dumps(
                    {
                        "capturedAt": "time",
                        "sha256": {"thread.json": export.digest(path.read_text())},
                    }
                )
            )

        write("first")
        with (
            patch.object(refresh, "listing", return_value=({r["id"]: r}, 2)),
            patch.object(refresh, "fetch", side_effect=AssertionError("must seed")),
        ):
            first = refresh.scan(self.root, {}, "amp")
            write("edited same timestamp")
            second = refresh.scan(self.root, first["current"], "amp")
            retained = refresh.scan(
                self.root, second["current"], "amp", raw_root=self.root / "raw"
            )
            self.assertTrue(retained["current"][name]["raw_retained"])
            self.assertEqual(
                next((self.root / "raw").rglob("*.json")).read_bytes(),
                path.read_bytes(),
            )
            self.assertEqual(retained["poll"]["export_cli_calls"], 0)
        self.assertIn("edited same timestamp", second["changed"][name])
        self.assertEqual(second["poll"]["export_cli_calls"], 0)

    def test_stale_download_rejected_and_newer_download_allowed(self):
        r = row(1, "2026-09-09T02:00:00Z")
        for timestamp, stale in [
            ("2026-09-09T01:00:00Z", True),
            ("2026-09-09T03:00:00Z", False),
        ]:
            raw = json.dumps(
                {"id": r["id"], "updatedAt": timestamp, "messages": []}
            ).encode()
            with patch.object(archive, "cli", return_value=raw):
                if stale:
                    with self.assertRaises(ValueError):
                        refresh.fetch("amp", r)
                else:
                    self.assertIn(timestamp, refresh.fetch("amp", r))

    def test_raw_versions_precede_marker_and_failed_write_is_retried(self):
        r = row(1)
        raw = json.dumps(
            {
                "id": r["id"],
                "updatedAt": r["updatedAt"],
                "messages": [{"role": "tool", "content": "raw-only-雪"}],
            }
        ).encode()
        raw_root = self.root / "raw"
        with (
            patch.object(refresh, "listing", return_value=({r["id"]: r}, 2)),
            patch.object(archive, "cli", return_value=raw),
        ):
            with patch.object(export, "atomic", side_effect=OSError("disk full")):
                failed = refresh.scan(self.root, {}, "amp", raw_root=raw_root)
            self.assertEqual(failed["current"], {})
            self.assertEqual(failed["poll"]["failed"], 1)
            first = refresh.scan(self.root, {}, "amp", raw_root=raw_root)
            files = list(raw_root.rglob("*.json"))
            self.assertEqual(len(files), 1)
            self.assertEqual(files[0].read_bytes(), raw)
            self.assertNotIn("raw-only", next(iter(first["changed"].values())))
            second = refresh.scan(self.root, first["current"], "amp", raw_root=raw_root)
            self.assertEqual(second["poll"]["export_cli_calls"], 0)

    def test_reordered_pending_inventory_has_stable_tiebreaker(self):
        for order in [[9, 3, 8, 1], [8, 1, 9, 3]]:
            rows = {row(i)["id"]: row(i) for i in order}
            with (
                patch.object(refresh, "listing", return_value=(rows, 1)),
                patch.object(refresh, "fetch", return_value="body") as fetch,
            ):
                first = refresh.scan(self.root, {}, "amp", budget=2)
                self.assertEqual(
                    {c.args[1]["id"] for c in fetch.call_args_list},
                    {row(1)["id"], row(3)["id"]},
                )
                fetch.reset_mock()
                refresh.scan(self.root, first["current"], "amp", budget=2)
                self.assertEqual(
                    {c.args[1]["id"] for c in fetch.call_args_list},
                    {row(8)["id"], row(9)["id"]},
                )


if __name__ == "__main__":
    unittest.main()
