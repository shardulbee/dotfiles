import fcntl
import os
import subprocess
import tempfile
import unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import patch

import archive
import latest_backup
import verify


class LatestTests(unittest.TestCase):
    def setUp(self):
        mask = os.umask(0o077)
        self.addCleanup(os.umask, mask)
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / "scheduled"
        self.thread = "T-00000000-0000-0000-0000-000000000000"

    def export(self, root, amp, workers):
        with patch.object(
            archive,
            "cli",
            side_effect=[archive.encoded({"id": self.thread, "messages": []}), b"body"],
        ):
            archive.capture(root, amp, self.thread, "test")
        archive.rebuild(root)
        return 0

    def test_replaces_verified_generation_and_preserves_unrelated_history(self):
        historical = self.root.parent / "amp-archive-experiment"
        historical.mkdir()
        (historical / "original").write_text("keep")
        with patch.object(latest_backup.archive_all, "run", side_effect=self.export):
            latest_backup.run(self.root, "amp", "amp")
            first = (self.root / "amp/latest").resolve()
            latest_backup.run(self.root, "amp", "amp")
        latest = (self.root / "amp/latest").resolve()
        self.assertNotEqual(first, latest)
        self.assertFalse(first.exists())
        self.assertEqual(len(list((self.root / "amp").glob("generation-*"))), 1)
        self.assertEqual(verify.verify_amp(latest / "archive"), 1)
        self.assertEqual((historical / "original").read_text(), "keep")

    def test_partial_export_corruption_and_publish_failure_keep_latest(self):
        with patch.object(latest_backup.archive_all, "run", side_effect=self.export):
            latest_backup.run(self.root, "amp", "amp")
        first = (self.root / "amp/latest").resolve()
        replace = os.replace

        def fail_publish(src, dst):
            if dst == self.root / "amp/latest":
                raise OSError("disk")
            return replace(src, dst)

        for error in ("partial", "corrupt", "publish"):
            with self.subTest(error=error):
                with (
                    patch.object(
                        latest_backup.archive_all, "run", side_effect=self.export
                    ),
                    patch.object(
                        latest_backup.verify,
                        "verify_amp",
                        side_effect=ValueError("corrupt"),
                    )
                    if error == "corrupt"
                    else nullcontext(),
                    patch.object(latest_backup.archive_all, "run", return_value=1)
                    if error == "partial"
                    else nullcontext(),
                    patch.object(latest_backup.os, "replace", side_effect=fail_publish)
                    if error == "publish"
                    else nullcontext(),
                    self.assertRaises((RuntimeError, ValueError, OSError)),
                ):
                    latest_backup.run(self.root, "amp", "amp")
                self.assertEqual((self.root / "amp/latest").resolve(), first)
                self.assertEqual(verify.verify_amp(first / "archive"), 1)
                self.assertEqual(len(list((self.root / "amp").glob("generation-*"))), 1)

    def test_lock_prevents_concurrent_capture(self):
        base = self.root / "amp"
        base.mkdir(parents=True)
        with (base / ".lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            with self.assertRaises(BlockingIOError):
                latest_backup.run(self.root, "amp", "amp")
        self.assertFalse(list(base.glob("generation-*")))

    def test_post_publish_sync_failure_retains_both_until_successful_retry(self):
        with patch.object(latest_backup.archive_all, "run", side_effect=self.export):
            latest_backup.run(self.root, "amp", "amp")
        base = self.root / "amp"
        first = (base / "latest").resolve()
        sync = archive.sync_dir

        def fail_base(path):
            if path == base:
                raise OSError("sync failed")
            sync(path)

        with (
            patch.object(latest_backup.archive_all, "run", side_effect=self.export),
            patch.object(archive, "sync_dir", side_effect=fail_base),
            self.assertRaises(OSError),
        ):
            latest_backup.run(self.root, "amp", "amp")
        self.assertTrue(first.exists())
        self.assertEqual(verify.verify_amp((base / "latest").resolve() / "archive"), 1)
        with patch.object(latest_backup.archive_all, "run", side_effect=self.export):
            latest_backup.run(self.root, "amp", "amp")
        self.assertEqual(len(list(base.glob("generation-*"))), 1)

    def test_pi_independent_hosts_real_rsync_and_failed_retry(self):
        source = self.root.parent / "source"
        source.mkdir()
        (source / "session.jsonl").write_text("test")
        run = subprocess.run

        def local(command, **kwargs):
            return run([*command[:-2], str(source) + "/", command[-1]], **kwargs)

        with patch.object(latest_backup.pi_backup.subprocess, "run", side_effect=local):
            for host in ("turbogadget", "sharchy", "turbogadget"):
                latest_backup.run(self.root, host, "unused")
        before = (self.root / "turbogadget/latest").resolve()
        with (
            patch.object(
                latest_backup.pi_backup.subprocess,
                "run",
                side_effect=OSError("offline"),
            ),
            self.assertRaises(OSError),
        ):
            latest_backup.run(self.root, "turbogadget", "unused")
        self.assertEqual((self.root / "turbogadget/latest").resolve(), before)
        for host in ("turbogadget", "sharchy"):
            self.assertEqual(
                verify.verify_pi(
                    (self.root / host / "latest").resolve() / "pi", (host,)
                ),
                {host: 1},
            )
            self.assertEqual(len(list((self.root / host).glob("generation-*"))), 1)


if __name__ == "__main__":
    unittest.main()
