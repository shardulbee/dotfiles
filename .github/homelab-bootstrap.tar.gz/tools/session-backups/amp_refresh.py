"""Bounded changed-thread refresh, separate from the daily full backup."""

import datetime
import fcntl
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import archive
import session_export as export


def listing(amp):
    rows, offset, calls = {}, 0, 0
    while True:
        page = json.loads(
            archive.cli(
                amp,
                "threads",
                "search",
                "author:me",
                "--json",
                "--limit",
                "100",
                "--offset",
                str(offset),
                timeout=30,
            )
        )
        calls += 1
        if not isinstance(page, list):
            raise ValueError("Invalid listing")
        if not page:
            return rows, calls
        before = len(rows)
        for row in page:
            if not archive.THREAD_ID.fullmatch(row["id"]):
                raise ValueError("Invalid thread ID")
            # Compare exact ISO timestamps, not display age or page position.
            stamp = datetime.datetime.fromisoformat(row["updatedAt"])
            if stamp.tzinfo is None:
                raise ValueError("Invalid change marker")
            old = rows.get(row["id"])
            if old is None or stamp >= datetime.datetime.fromisoformat(
                old["updatedAt"]
            ):
                rows[row["id"]] = row
        if len(rows) == before:
            raise ValueError("Listing made no progress")
        offset += 100


def marker(row):
    return row["updatedAt"]


def backup_seeds(state, rows, known, raw_root=None):
    seeds, hashes = {}, {}
    base = state / "session-backups/amp"
    if not (base / ".lock").exists():
        return seeds, hashes
    with (base / ".lock").open("r") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            return seeds, hashes
        # Release before remote downloads, so refresh does not block the daily
        # publisher. The daily checksum also reconciles unchanged update markers.
        for thread, snapshot in archive.latest_files(
            (base / "latest/archive").resolve()
        ):
            if thread not in rows:
                continue
            meta = json.loads((snapshot / "metadata.json").read_bytes())
            checksum = meta["sha256"]["thread.json"]
            hashes[thread] = checksum
            old = known.get(export.filename(["amp", thread]), {})
            if (
                old.get("marker") == marker(rows[thread])
                and old.get("backup") == checksum
                and (raw_root is None or old.get("raw_retained"))
            ):
                continue
            path = snapshot / "thread.json"
            raw = path.read_text()
            data = json.loads(raw)
            if data.get("updatedAt") == marker(rows[thread]):
                if export.digest(raw) != checksum:
                    raise ValueError("Invalid archived checksum")
                body = export.amp_document(path, (thread, snapshot))
                if (
                    raw_root is not None
                    and not old.get("raw_retained")
                    and old.get("marker") == marker(rows[thread])
                    and old.get("digest") != export.digest(body)
                ):
                    # A newer live download can share an older listed marker.
                    # Raw initialization must not replace it with a daily seed.
                    continue
                if raw_root is not None:
                    target = raw_root / thread / (checksum + ".json")
                    if not target.exists():
                        export.atomic(target, raw)
                seeds[thread] = body
    return seeds, hashes


def fetch(amp, row, raw_root=None):
    raw = archive.cli(amp, "threads", "export", row["id"], timeout=30)
    data = json.loads(raw)
    if data.get("id") != row["id"] or not isinstance(data.get("messages"), list):
        raise ValueError("Invalid thread export")
    if datetime.datetime.fromisoformat(
        data["updatedAt"]
    ) < datetime.datetime.fromisoformat(marker(row)):
        raise ValueError("Export is older than listing")
    # Save the listed marker, not a newer export marker. A mutation between list
    # and download is picked up again on the next complete scan.
    provenance = "Amp threads export"
    if raw_root is not None:
        # Content-addressed versions retain raw tool/media data and prior edits.
        # Commit raw bytes before allowing the marker/derived text to advance.
        body = raw.decode() if isinstance(raw, bytes) else raw
        path = raw_root / row["id"] / (export.digest(body) + ".json")
        if not path.exists():
            export.atomic(path, body)
        provenance = str(path)
    return export.amp_body(
        data,
        {
            "captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "provenance": provenance,
            "listed_updated": marker(row),
        },
    )


def scan(state, known, amp, budget=16, raw_root=None):
    rows, calls = listing(amp)
    seeds, hashes = backup_seeds(state, rows, known, raw_root)
    current, changed, pending = {}, {}, []
    now = time.time()
    for thread, row in rows.items():
        name = export.filename(["amp", thread])
        old = dict(known.get(name, {}))
        old.pop("absent", None)
        if old:
            current[name] = old
        if (
            (raw_root is None or old.get("raw_retained"))
            and old.get("marker") == marker(row)
            and (thread not in hashes or old.get("backup") == hashes[thread])
        ):
            continue
        if thread in seeds:
            body = seeds[thread]
            current[name] = {
                "digest": export.digest(body),
                "marker": marker(row),
                "backup": hashes.get(thread),
                "refreshed": now,
                "raw_retained": raw_root is not None,
            }
            if old.get("digest") != export.digest(body):
                changed[name] = body
        else:
            pending.append(row)
    # Oldest refresh first gives deferred sessions a turn despite busy threads.
    pending.sort(
        key=lambda row: (
            known.get(export.filename(["amp", row["id"]]), {}).get("refreshed", 0),
            row["id"],
        )
    )
    failures = 0
    selected = pending[:budget]
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(fetch, amp, row, raw_root): row for row in selected}
        for future in as_completed(futures):
            row = futures[future]
            name = export.filename(["amp", row["id"]])
            try:
                body = future.result()
            except Exception:
                failures += 1
                continue
            current[name] = {
                "digest": export.digest(body),
                "marker": marker(row),
                "backup": hashes.get(row["id"]),
                "refreshed": now,
                "raw_retained": raw_root is not None,
            }
            changed[name] = body
    listed_names = {export.filename(["amp", thread]) for thread in rows}
    for name in known.keys() - listed_names:
        # Pagination is not a server snapshot. Require absence in two complete
        # scans before retiring a document, never a partial/failed listing.
        if not known[name].get("absent"):
            current[name] = {**known[name], "absent": True}
    return {
        "current": current,
        "changed": changed,
        "poll": {
            "listed": len(rows),
            "metadata_cli_calls": calls,
            "export_cli_calls": len(selected),
            "failed": failures,
            "deferred": len(pending) - len(selected),
        },
    }
