"""Incremental raw session capture and SQLite Markdown ingestion."""

import argparse
import datetime
import fcntl
import hashlib
import json
import os
import re
import shlex
import sqlite3
import subprocess
import sys
import tempfile
from itertools import chain
from pathlib import Path


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def filename(identity):
    # Hash the tuple, not a separator-joined string. IDs can contain separators.
    if identity[0] == "amp" and re.fullmatch(r"T-[0-9a-f-]{36}", identity[1]):
        return identity[1] + ".md"
    label = "-".join([*identity[1:-1], Path(identity[-1]).stem])
    label = re.sub(r"[^a-zA-Z0-9_-]+", "-", label).strip("-")[:120] or "session"
    return label + "-" + digest(encoded(identity))[:16] + ".md"


def text(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n\n".join(
            block["text"]
            for block in content
            if isinstance(block, dict)
            and block.get("type") == "text"
            and isinstance(block.get("text"), str)
        )
    return ""


def document(metadata, messages):
    # JSON values are valid YAML scalars; no interpolated frontmatter strings.
    header = "\n".join(f"{key}: {encoded(value)}" for key, value in metadata.items())
    parts = [
        "---\n" + header + "\n---\n",
        "# "
        + " ".join(
            str(metadata.get("title") or metadata.get("id") or "Session").splitlines()
        )
        + "\n",
        "User/assistant text only. Tool output, reasoning, and attachment bytes "
        "are omitted. Retained history can include abandoned branches or compacted turns.\n",
    ]
    for message in messages:
        if message.get("role") not in ("user", "assistant"):
            continue
        body = text(message.get("content"))
        if body:
            parts.append(
                "## "
                + message["role"]
                + "\n\n"
                + "Message metadata: "
                + encoded({k: v for k, v in message.items() if k != "content"})
                + "\n\n"
                + body
                + "\n"
            )
    return "\n".join(parts)


def atomic(path, body):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, name = tempfile.mkstemp(prefix=".export-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        Path(name).unlink(missing_ok=True)


def archive_record(identity, metadata, body, raw, raw_format):
    updated = metadata.get("updated")
    if isinstance(updated, (int, float)):
        updated = datetime.datetime.fromtimestamp(
            updated, datetime.timezone.utc
        ).isoformat()
    return {
        "source": identity[0],
        "source_id": identity[1] if len(identity) == 2 else encoded(identity[1:]),
        "title": str(metadata.get("title") or metadata.get("id") or identity[-1]),
        "source_path": metadata["provenance"],
        "source_updated_at": str(updated) if updated is not None else None,
        "markdown": body,
        "raw_json": raw,
        "raw_format": raw_format,
        "content_hash": digest(body),
        "raw_hash": digest(raw) if raw is not None else None,
    }


def sqlite_row(row):
    return {
        key: {"$blob": value.hex()} if isinstance(value, bytes) else value
        for key, value in dict(row).items()
    }


def hermes_scan(home, known, archived=None):
    """Run beside SQLite, using WAL-aware read transactions, never immutable=1."""
    databases = [("default", home / "state.db")]
    databases += [
        ("profiles/" + p.parent.name, p)
        for p in sorted((home / "profiles").glob("*/state.db"))
        if not p.parent.name.startswith(".")
    ]
    current, changed, records = {}, {}, []
    for profile, path in databases:
        db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA query_only=ON")
            db.execute("BEGIN")
            sessions = db.execute("SELECT * FROM sessions ORDER BY id")
            for session in sessions:
                metadata = {
                    key: session[key]
                    for key in (
                        "id",
                        "source",
                        "title",
                        "started_at",
                        "ended_at",
                        "parent_session_id",
                    )
                }
                identity = ["hermes", "hermes", profile, session["id"]]
                metadata.update(
                    source="hermes",
                    host="hermes",
                    profile=profile,
                    channel=session["source"],
                    provenance=str(path),
                    timestamp_unit="Unix seconds",
                    schema_version=1,
                )
                # No update clock covers edits, rewinds, or deletes. Hash selected
                # history inside this transaction, transfer only changed documents.
                raw_messages = [
                    dict(row)
                    for row in db.execute(
                        "SELECT * FROM messages WHERE session_id=? ORDER BY timestamp,id",
                        (session["id"],),
                    )
                ]
                messages = [
                    {
                        key: row[key]
                        for key in (
                            "id",
                            "role",
                            "content",
                            "timestamp",
                            "active",
                            "compacted",
                        )
                    }
                    for row in raw_messages
                    if row["role"] in ("user", "assistant")
                ]
                body = document(metadata, messages)
                name = filename(identity)
                current[name] = {"digest": digest(body)}
                if known.get(name, {}).get("digest") != digest(body):
                    changed[name] = body
                if archived is not None:
                    raw = encoded(
                        {
                            "session": sqlite_row(session),
                            "messages": [sqlite_row(row) for row in raw_messages],
                        }
                    )
                    if archived.get(encoded(identity[1:])) != digest(raw):
                        updated = dict(session).get("last_activity_at") or max(
                            (
                                m["timestamp"]
                                for m in raw_messages
                                if m["timestamp"] is not None
                            ),
                            default=None,
                        )
                        records.append(
                            archive_record(
                                identity,
                                {**metadata, "updated": updated},
                                body,
                                raw,
                                "sqlite-json",
                            )
                        )
            db.rollback()
        finally:
            db.close()
    return {
        "current": current,
        "changed": changed,
        "profiles": len(databases),
        "records": records,
    }


def remote_hermes(host, present, archived=None):
    command = "python3 -c " + shlex.quote(Path(__file__).read_text()) + " --hermes-scan"
    response = subprocess.run(
        [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "StrictHostKeyChecking=yes",
            "-o",
            "ConnectTimeout=15",
            host,
            command,
        ],
        input=encoded({"current": present, "archive": archived}),
        text=True,
        capture_output=True,
        timeout=240,
    )
    if response.returncode:
        raise RuntimeError("Hermes read failed")
    return json.loads(response.stdout)


def amp_document(path, context):
    session_id, snapshot = context
    data = json.loads(path.read_bytes())
    if data["id"] != session_id:
        raise ValueError("Amp identity mismatch")
    captured = json.loads((snapshot / "metadata.json").read_bytes())
    return amp_body(
        data, {"captured_at": captured["capturedAt"], "provenance": str(path)}
    )


def amp_body(data, provenance):
    return document(
        {
            "schema_version": 1,
            "source": "amp",
            "id": data["id"],
            "title": data.get("title"),
            "created": data.get("created"),
            "updated": data.get("updatedAt"),
            "url": "https://ampcode.com/threads/" + data["id"],
            **provenance,
        },
        [
            {
                "id": m.get("messageId"),
                "role": m.get("role"),
                "content": m.get("content"),
            }
            for m in data["messages"]
        ],
    )


def pi_documents(state):
    # Pick each host's newest completed snapshot.
    for host in ("sharchy", "turbogadget"):
        candidates = []
        scheduled = state / "session-backups" / host / "latest/pi" / host
        manual = state / "pi-backups" / host
        for base in (scheduled, manual):
            pointer = base / "latest.json"
            if pointer.exists():
                snapshot = (
                    base / json.loads(pointer.read_bytes())["snapshot"]
                ).resolve()
                meta = json.loads((snapshot / "metadata.json").read_bytes())
                candidates.append((meta["completedAt"], snapshot))
        if not candidates:
            raise ValueError("Missing Pi snapshot")
        captured, snapshot = max(candidates)
        for path in sorted((snapshot / "sessions").rglob("*.jsonl")):
            if path.is_symlink():
                continue
            relative = str(path.relative_to(snapshot / "sessions"))
            yield filename(["pi", host, relative]), path, (host, relative, captured)


def pi_document(path, context):
    host, relative, captured = context
    messages = []
    session = None
    with path.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("type") == "session":
                session = row
            elif row.get("type") == "message":
                m = row["message"]
                if m.get("role") in ("user", "assistant"):
                    messages.append(
                        {
                            "id": row.get("id"),
                            "parent_id": row.get("parentId"),
                            "timestamp": row.get("timestamp", m.get("timestamp")),
                            "role": m["role"],
                            "content": m.get("content"),
                        }
                    )
    if session is None:
        raise ValueError("Missing Pi session header")
    return document(
        {
            "schema_version": 1,
            "source": "pi",
            "host": host,
            "id": session["id"],
            "created": session.get("timestamp"),
            "cwd": session.get("cwd"),
            "parent_session": session.get("parentSession"),
            "source_path": relative,
            "captured_at": captured,
            "provenance": str(path),
        },
        messages,
    )


def local_scan(items, render, known):
    current, changed = {}, {}
    for name, path, context in items:
        stat = path.stat()
        stamp = [str(path), stat.st_size, stat.st_mtime_ns]
        old = known.get(name, {})
        if old.get("stamp") == stamp:
            current[name] = old
            continue
        body = render(path, context)
        current[name] = {"digest": digest(body), "stamp": stamp}
        if old.get("digest") != digest(body):
            changed[name] = body
    return {"current": current, "changed": changed}


def run(storage, source, state, hermes_host, database):
    import knowledge

    storage.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (storage / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest = storage / ".state.json"
        known = json.loads(manifest.read_bytes()) if manifest.exists() else {}
        db = knowledge.connect(database)
        try:
            return run_scan(source, state, hermes_host, storage, known, db)
        finally:
            db.close()


def run_scan(source, state, hermes_host, storage, known, db):
    import knowledge

    if source == "hermes":
        result = remote_hermes(hermes_host, known, knowledge.hashes(db, source))
        records = result["records"]
    elif source == "amp":
        import amp_refresh

        result = amp_refresh.scan(
            state,
            known,
            str(Path.home() / ".amp/bin/amp"),
            raw_root=state / "agent-session-raw/amp",
        )
        identities = set(knowledge.hashes(db, source))
        changed = {name[:-3] for name in result["changed"]}
        missing = {
            p.name for p in (state / "agent-session-raw/amp").glob("T-*")
        } - identities
        records = chain(
            (
                knowledge.amp_record(Path(knowledge.metadata(body)["provenance"]))
                for body in result["changed"].values()
            ),
            knowledge.amp_records(state, missing - changed),
        )
    else:
        items = list(pi_documents(state))
        result = local_scan(items, pi_document, known)
        identities = set(knowledge.hashes(db, source))
        records = (
            knowledge.pi_record(path, context)
            for name, path, context in items
            if name in result["changed"]
            or encoded([context[0], context[1]]) not in identities
        )
    # Commit archival content before advancing the exporter manifest. A DB
    # failure retries the same changed sessions on the next exporter run.
    imported = knowledge.ingest(db, records)
    if result["current"] != known:
        atomic(storage / ".state.json", encoded(result["current"]) + "\n")
    return {
        "sessions": len(result["current"]),
        "changed": len(result["changed"]),
        "missing": len(known.keys() - result["current"].keys()),
        **result.get("poll", {}),
        **imported,
    }


def main():
    os.umask(0o077)
    if sys.argv[1:] == ["--hermes-scan"]:
        request = json.load(sys.stdin)
        print(
            encoded(
                hermes_scan(
                    Path.home() / ".hermes", request["current"], request["archive"]
                )
            )
        )
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", choices=["hermes", "amp", "pi"])
    parser.add_argument(
        "--export-state", type=Path, default=Path("/var/lib/agent-sessions")
    )
    parser.add_argument("--state", type=Path, default=Path.home() / ".local/state")
    parser.add_argument("--hermes-host", default="hermes@10.60.0.2")
    parser.add_argument(
        "--database", type=Path, default=Path("/var/lib/knowledge/archive.sqlite3")
    )
    args = parser.parse_args()
    try:
        result = run(
            args.export_state / args.source,
            args.source,
            args.state,
            args.hermes_host,
            database=args.database,
        )
    except Exception as error:
        # Exception payloads may contain transcripts or auth. Preserve useful
        # operational category without echoing private subprocess stderr.
        detail = f"{type(error).__name__}, errno={getattr(error, 'errno', None)}"
        parser.exit(
            1, f"{args.source} session export failed ({detail}); originals retained.\n"
        )
    print(args.source, encoded(result))
    if result.get("failed"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
