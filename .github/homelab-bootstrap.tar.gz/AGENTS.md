# Homelab agent guidance

Format localized changes, inspect the diff, and run `git diff --check`.
Package checks live in the [workflow](.github/workflows/deploy.yml); follow
package-specific guidance under `packages/`. Reserve full orb-side NixOS builds
for broad or risky changes where they materially reduce deployment risk.

Ship only approved main pushes through Actions; do not deploy from an orb or
overlap a host switch with an app deployment. Verify only affected behavior.
Deployment contracts live beside the [Homelab](nixos/sharbox.nix),
[Hotbox](nixos/hotbox-deploy.nix), workstation `*-deploy.nix`, and
[Reader](nixos/services/reader/default.nix) helpers.
