# Homelab

NixOS and nix-darwin configuration for Sharbox, Hotbox, Sharchy, and TurboGadget.

- [`reader`](nixos/services/reader/): RSS and read-later app
- [`executor`](nixos/services/executor/): Executor and Fastmail MCP
- [`fastmail-mcp`](packages/fastmail-mcp/): local MCP package
- [Session backups](tools/session-backups/): daily Amp backups, manual Pi pulls, derived session Markdown
- [Workstation and home configuration](dotfiles/)
- [Tailnet policy](https://github.com/shardulbee/tailscale-policy)

The [workflow](.github/workflows/deploy.yml) checks pull requests and deploys
Sharbox, Hotbox, Sharchy, then TurboGadget sequentially from `main`.
Host entrypoint and bootstrap: [`sharbox.nix`](nixos/sharbox.nix).
